# /// script
# requires-python = ">=3.13"
# dependencies = ["pandas==3.1.1", "requests==2.32.5"]
# ///
"""Archive supplementary official indicators; retain raw responses and metadata.

Run once online. Existing responses are reused. Analysis runs entirely offline.
Core GDP/R&D and innovation inputs retain the original archive vintage.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import shutil
import pandas as pd
import requests

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "Data"
RAW = DATA / "raw_wb"
RAW.mkdir(parents=True, exist_ok=True)
SRC = ROOT.parent / "Archive/world-rd-income/figures/world-rd-income/data"
INDICATORS = {
    "population": ("SP.POP.TOTL", 2),
    "internet": ("IT.NET.USER.ZS", 2),
    "tertiary": ("SE.TER.ENRR", 2),
    "hci": ("HD.HCI.OVRL", 63),
    "gov_effect": ("GOV_WGI_GE.EST", 3),
    "rule_law": ("GOV_WGI_RL.EST", 3),
    "rents": ("NY.GDP.TOTL.RT.ZS", 2),
    "fixed_investment": ("NE.GDI.FTOT.ZS", 2),
    "credit": ("FS.AST.PRVT.GD.ZS", 2),
    "services_gdp": ("NV.SRV.TOTL.ZS", 2),
    "agriculture_gdp": ("NV.AGR.TOTL.ZS", 2),
    "trade": ("NE.TRD.GNFS.ZS", 2),
    "ip_payments_usd": ("BM.GSR.ROYL.CD", 2),
    "gdp_usd": ("NY.GDP.MKTP.CD", 2),
    "gni_usd": ("NY.GNP.MKTP.CD", 2),
    "employment_15plus": ("SL.EMP.TOTL.SP.ZS", 2),
    "real_ppp": ("NY.GDP.PCAP.PP.KD", 2),
}


def fetch_one(item):
    metric, (indicator, source) = item
    url = f"https://api.worldbank.org/v2/country/all/indicator/{indicator}?source={source}&date=2000:2023&format=json&per_page=20000&footnote=y"
    path = RAW / f"{metric}.json"
    provenance = RAW / f"{metric}.provenance.json"
    if not path.exists():
        res = requests.get(url, timeout=120)
        res.raise_for_status()
        obj = res.json()
        assert isinstance(obj, list) and len(obj) == 2 and isinstance(obj[1], list), obj
        assert obj[0]["pages"] == 1, obj[0]
        path.write_bytes(res.content)
        provenance.write_text(json.dumps(dict(url=url, retrieved_utc=datetime.now(timezone.utc).isoformat()), indent=2), encoding="utf-8")
    obj = json.loads(path.read_text(encoding="utf-8-sig"))
    metaurl = f"https://api.worldbank.org/v2/indicator/{indicator}?source={source}&format=json"
    metapath = RAW / f"{metric}.metadata.json"
    if not metapath.exists():
        res = requests.get(metaurl, timeout=120)
        res.raise_for_status()
        res.json()
        metapath.write_bytes(res.content)
    records = []
    for row in obj[1]:
        records.append(dict(iso3=row["countryiso3code"], economy=row["country"]["value"], year=int(row["date"]), metric=metric,
                            indicator=indicator, value=row["value"], obs_status=row.get("obs_status", ""),
                            footnote=row.get("footnote", ""), unit=row.get("unit", ""), source_id=source,
                            api_lastupdated=obj[0].get("lastupdated", ""), source_file=str(path.relative_to(ROOT))))
    print(metric, len(records), sum(r["value"] is not None for r in records), flush=True)
    return records


def main():
    records, errors = [], []
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = {key: pool.submit(fetch_one, (key, value)) for key, value in INDICATORS.items()}
        for key, future in futures.items():
            try:
                records.extend(future.result())
            except Exception as exc:
                errors.append(dict(metric=key, error=str(exc)))
    pd.DataFrame(records).to_csv(DATA / "supplement_annual.csv", index=False)
    (DATA / "collection_errors.json").write_text(json.dumps(errors, indent=2), encoding="utf-8")
    assert not errors, errors
    for source, dest in [
        (ROOT.parent / "Revision/Data/linked_countries_2022.csv", "input_linked_2022.csv"),
        (SRC / "innovation_annual.csv", "input_innovation_annual.csv"),
        (SRC / "selected_annual_rd.csv", "input_selected_annual_rd.csv"),
        (SRC / "rd_income_exports_annual.csv", "input_rd_income_exports_annual.csv"),
        (ROOT.parent / "Revision/Data/manufacturing_standardised_2022.csv", "input_manufacturing_standardised_2022.csv"),
        (ROOT.parent / "Revision/Data/research_group_joined_2022.csv", "input_research_group_joined_2022.csv"),
        (ROOT.parent / "Revision/Data/funding_performer_flows_2022.csv", "input_funding_performer_flows_2022.csv"),
    ]:
        shutil.copyfile(source, DATA / dest)
    inputs = [p for p in DATA.rglob("*") if p.is_file() and
              (RAW in p.parents or p.name in ["supplement_annual.csv", "collection_errors.json"] or
               (p.name.startswith("input_") and p.name != "input_manifest.csv"))]
    manifest = [dict(path=p.relative_to(ROOT).as_posix(), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                for p in sorted(inputs)]
    pd.DataFrame(manifest).to_csv(DATA / "input_manifest.csv", index=False)
    print("Supplement and frozen inputs archived.")


if __name__ == "__main__":
    main()
