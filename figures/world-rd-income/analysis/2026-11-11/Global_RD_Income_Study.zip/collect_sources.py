# /// script
# requires-python = ">=3.13"
# dependencies = ["requests==2.32.5", "pymupdf==1.26.7", "beautifulsoup4==4.14.3"]
# ///
"""Cache readable source versions; downloading never implies substantive reading."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import requests
import pymupdf
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "Sources"
OUT.mkdir(exist_ok=True)
SOURCES = {
    "Goni_Maloney_2014_WP": "https://documents.worldbank.org/curated/en/855681468326185477/pdf/WPS6811.pdf",
    "Comin_Mestieri_2013_verified_WP": "https://www.nber.org/system/files/working_papers/w19010/w19010.pdf",
    "Syverson_2010_verified_WP": "https://www.nber.org/system/files/working_papers/w15712/w15712.pdf",
    "Hsieh_Klenow_2007_WP": "https://www.nber.org/system/files/working_papers/w13290/w13290.pdf",
    "Hall_Jones_1998_WP": "https://www.nber.org/system/files/working_papers/w6564/w6564.pdf",
    "Coad_Vezzani_2017_WP": "https://publications.jrc.ec.europa.eu/repository/bitstream/JRC107579/JRC107579_01.pdf",
    "Ugur_et_al_2016_published": "https://gala.gre.ac.uk/id/eprint/15854/7/15854_Solomon_R%26D%20and%20productivity%20in%20OECD%20%28pub%20PDF%20OA%29%202016.pdf",
    "Mathieu_Pottelsberghe_2010": "https://www.sciedupress.com/journal/index.php/rwe/article/download/8/15",
    "Srholec_2007": "https://www.eastwestcenter.org/sites/default/files/fileadmin/stored/pics/0707_RWE_Srholec.pdf",
    "Bloom_management_2011_WP": "https://www.nber.org/system/files/working_papers/w16658/w16658.pdf",
    "Timmer_et_al_2014": "https://www.aeaweb.org/articles?id=10.1257/jep.28.2.99",
    "Timmer_et_al_2014_published": "https://www.aeaweb.org/articles/pdf/doi/10.1257/jep.28.2.99",
    "Catapult_2021_review": "https://assets.publishing.service.gov.uk/media/6065a7a9d3bf7f0c8d06b811/catapult-network-review-april-2021.pdf",
    "Catapult_2023_update": "https://assets.publishing.service.gov.uk/media/6503184897d3960014482f14/catapult-network-review-2023-update.pdf",
    "ASTAR_partnerships_2026": "https://www.a-star.edu.sg/enterprise/partnership-collaboration",
    "ASTAR_programmes_2026": "https://www.a-star.edu.sg/enterprise/innovation-offerings/programmes-for-smes",
    "Fraunhofer_funding_2026": "https://www.fraunhofer.de/en/about-fraunhofer/profile-structure/facts-and-figures/finances.html",
    "Coad_Vezzani_2017_record": "https://publications.jrc.ec.europa.eu/repository/handle/JRC107579",
    "Coad_Vezzani_2019_record": "https://publications.jrc.ec.europa.eu/repository/handle/JRC115792",
    "WB_researchers_metadata": "https://api.worldbank.org/v2/indicator/SP.POP.SCIE.RD.P6?format=json",
    "WB_publications_metadata": "https://api.worldbank.org/v2/indicator/IP.JRN.ARTC.SC?format=json",
    "WB_patents_metadata": "https://api.worldbank.org/v2/indicator/IP.PAT.RESD?format=json",
}


def get(item):
    key, url = item
    metadata = OUT / (key + ".provenance.json")
    if metadata.exists():
        result = json.loads(metadata.read_text(encoding="utf-8"))
        if result.get("status") == "ok":
            return result
    result = dict(id=key, url=url, retrieved_utc=datetime.now(timezone.utc).isoformat())
    try:
        res = requests.get(url, timeout=120)
        res.raise_for_status()
        content = res.content
        ispdf = content.startswith(b"%PDF")
        p = OUT / (key + (".pdf" if ispdf else ".html"))
        p.write_bytes(content)
        if ispdf:
            with pymupdf.open(p) as doc:
                text = "\n".join(f"\n=== PDF PAGE {i+1} ===\n" + page.get_text(sort=True) for i, page in enumerate(doc))
                result["pages"] = len(doc)
        else:
            soup = BeautifulSoup(res.text, "html.parser")
            for el in soup(["script", "style", "nav", "footer", "header"]):
                el.decompose()
            text = soup.get_text("\n", strip=True)
        (OUT / (key + ".txt")).write_text(text, encoding="utf-8")
        result.update(status="ok", path=str(p.relative_to(ROOT)), sha256=hashlib.sha256(content).hexdigest(), bytes=len(content), final_url=res.url)
    except Exception as exc:
        result.update(status="failed", error=str(exc))
    metadata.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(key, result["status"], flush=True)
    return result


if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=5) as pool:
        records = list(pool.map(get, SOURCES.items()))
    (OUT / "download_manifest.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
