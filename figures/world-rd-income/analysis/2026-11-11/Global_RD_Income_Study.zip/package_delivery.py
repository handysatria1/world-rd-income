# /// script
# requires-python = ">=3.13"
# dependencies = []
# ///
"""Package a self-contained global analysis, documents and source provenance."""
from pathlib import Path
import hashlib
import json
from zipfile import ZipFile, ZIP_DEFLATED

ROOT=Path(__file__).resolve().parent
assert (ROOT/"Data/global_validation.json").exists(), "Run validation first."
assert json.loads((ROOT/"Policy_Brief/Data/validation.json").read_text())["passed"], "Validate the policy brief and methods guide first."
files=[]
wrong=("Comin_Mestieri_2013_WP", "Syverson_2009_WP")
for p in sorted(ROOT.rglob("*")):
    if not p.is_file():
        continue
    rel=p.relative_to(ROOT)
    if "__pycache__" in rel.parts or p.suffix in [".zip",".pyc"] or p.name=="Delivery_Manifest.json":
        continue
    if rel.parts[:2]==("Policy_Brief","PDF_Review"):
        # Keep the honest reading/provenance record; full source extracts and thumbnails stay in the workspace.
        if p.name not in ["Inventory.csv","Inventory_summary.json","Reading_Ledger.md","Reading_Ledger.csv"] and not p.name.startswith("Screen_"):
            continue
    if rel.parts[0]=="Sources":
        if p.name.startswith(wrong):
            continue
        official=p.name.startswith(("ASTAR_","Catapult_","Fraunhofer_","WB_"))
        if p.suffix not in [".json",".md"] and not (official and p.suffix in [".html",".txt"]):
            continue
    files.append(p)
records=[dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
manifest=dict(format=2,scope="Global study plus nine-page policy brief, ten-page methods guide, workbooks, frozen data, code and reading provenance",files=records)
(ROOT/"Delivery_Manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
target=ROOT/"Global_RD_Income_Study.zip"
with ZipFile(target,"w",ZIP_DEFLATED,compresslevel=7) as z:
    for p in [*files,ROOT/"Delivery_Manifest.json"]:
        z.write(p,p.relative_to(ROOT).as_posix())
print(json.dumps(dict(package=str(target),files=len(files)+1,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest()),indent=2))
