# Source-reading and version notes

**Date:** 9 November 2026.  
**Scope:** Targeted search for descriptive-statistics and cross-country chart-writing precedents for the R&D–income project. No study was independently replicated.

## Access and inspection record

| Source | Version obtained | Material inspected | Access/interpretation notes |
|---|---|---|---|
| Cirera & Maloney (2017) | Official World Bank book PDF, previously downloaded for the R&D–income study | Chapter contents; pp. 25–29, especially p. 26 explanation and Figures 2.7 and 2.9; Figure 2.7 also rendered and visually inspected | Figure 2.7(a) is the closest chart match. Its income axis uses constant-US-dollar GDP per capita, not the slide’s 2025 current-dollar measure. Figure 2.9 measures firm-survey R&D intensity and incidence. |
| Dietrich et al. (2024) | Published eight-page EconPol Forum article from ifo | Full eight-page article, including all five figures, Table 1 and policy implications; p. 33 visually inspected | Correct first author is Anita Dietrich, despite a download filename beginning with “dorn”. Article pp. 32–39. Corporate Scoreboard data and territorial GERD/BERD have different coverage. |
| Carvalho (2022) | ERC Insight Paper, full PDF from Universidade de Évora repository | Abstract, introduction, definitions, data and methods; composition discussion and Figure 1; Table 2 and Figures 5–6 discussion; full conclusion/limitations | Main narrative spans pp. 5–35, followed by references and a large appendix. The ERC landing page returned “Page not found”; the university PDF was accessible. Appendix tables were not all audited. |
| Dosi et al. | LEM Working Paper 2005/02, not the 2006 journal typesetting | Official abstract; Section 5’s science/R&D comparisons; Table 1, Figures 5–9 and Table 2; Sections 6–7 | Published article’s title and citation were checked against indexed journal metadata. Detailed figure/section claims in the guide refer explicitly to the working version. Do not transfer these page numbers to the Research Policy version. |
| Mathieu & van Pottelsberghe de la Potterie (2010) | Published Research in World Economy PDF | Full substantive text, charts, regressions and descriptive-statistics tables; p. 62 visually inspected | Mixed descriptive/econometric study. Figure numbering and sample reporting have inconsistencies; see below. |
| IMF (2016) | Advance Copy Chapter 2, hosted at static.politico.com | Contents and chapter opening; printed pp. 29–34, including Figures 2.1–2.4; chapter structure and annex descriptions; official IMF publication page and substantial IMF-hosted text | Direct official PDF download returned HTTP 403. The full inspected PDF is explicitly marked “Advance Copy Chapter 2”. Its printed pagination starts at 29; printed p. 33 is PDF p. 9. Official web text was supplementary, not the basis for figure-layout claims. |

## Precise locator crosswalk

| Source and item | Printed page | PDF-viewer page in the saved file |
|---|---:|---:|
| Cirera & Maloney, Figure 2.7 | 27 | 55 |
| Cirera & Maloney, Figure 2.9 | 29 | 57 |
| Dietrich et al., Figures 1–2 | 33 | 2 |
| Dietrich et al., Figure 3 | 34 | 3 |
| Dietrich et al., Figures 4–5 | 35 | 4 |
| Dietrich et al., Policy Implications | 38 | 7 |
| Carvalho, Figure 1 | 12 | 12 |
| Carvalho, Table 2 | 19 | 19 |
| Carvalho, Figure 6 | 21 | 21 |
| Dosi et al., working-paper Table 1 | 17 | 18 |
| Dosi et al., working-paper Figure 5 | 23 | 24 |
| Dosi et al., working-paper Table 2 | 26 | 27 |
| Mathieu & van Pottelsberghe, two descriptive charts | 62 | 7 |
| Mathieu & van Pottelsberghe, Figure 5 descriptive tables | 65 | 10 |
| IMF, Figure 2.4 | 33 | 9 |

## Specific reporting issues relevant to using these as models

### Mathieu and van Pottelsberghe (2010)

- The abstract reports 21 industrial sectors, 18 countries and five years.
- The introduction refers to 2001–2004, while the methods and descriptive-statistics tables refer to 2000–2004.
- The methods text reports 5,735 observations; regression tables report 5,726 for the main specifications. A simple 21 × 18 × 5 country-industry-year panel contains at most 1,890 unique cells, so the observation count cannot be reconciled from the stated dimensions alone. No resolution was established here.
- Both chart captions on p. 62 say “Figure 1”; the body refers to the country-comparison chart as Figure 2.
- Tables of regression results and descriptive statistics are labelled as figures.
- These issues make the paper useful for its research question and analytical progression, but less suitable as a precise reporting template. The guide does not rely on its reported observation count.

### Carvalho (2022)

- The methods say 47 industry categories are analysed; the specific Figure 6 discussion refers to 45 industries. Use figure-specific coverage rather than assuming a constant N throughout.
- Latest available years differ across countries/industries. Five-year averages are not uniformly 2015–2019; the report documents exceptions.
- The report identifies substantial prospective revisions to UK BERD on p. 5. Historical values should not be treated as the latest UK data.
- Figure 5’s 0–100 scaling is sensitive to extreme values; the author discusses this. Table 2 and the raw intensity measures are clearer starting models for this project.
- The guide recommends the broad research structure, not adopting every policy conclusion or reproducing every presentation choice.

### Cirera and Maloney (2017)

- Figure 2.7(a) is labelled “Country level from UNESCO”; the bottom source line names Orbis and Enterprise Survey data, and the figure note details panel (b). The surrounding text explicitly distinguishes UNESCO aggregate data from enterprise-survey data.
- The exact time coverage and observation structure of panel (a) are not established by the inspected caption. The guide therefore does not state that there is exactly one observation per country or claim it uses the same sampling design as the user’s slide.
- The printed note says the line represents a smoothing linear fit; the guide calls it a fitted curve and does not infer a particular polynomial, bandwidth or estimation procedure.

### Dietrich et al. (2024)

- The article is partly based on the Fuest et al. (2024) policy report. These are not counted as two independent studies.
- Figure 2 uses the top 2,500 companies, while Figure 4 uses the top 500. National GERD series and the corporate samples should not be conflated.
- Table 1 explicitly notes that Amazon’s R&D rank is an estimate based on broader “Technology and Content” reporting. The guide does not use that estimate as a verified spending observation.

## Other leads

- **Coad & Vezzani (2019), “Three cheers for industry: Is manufacturing linked to R&D, exports, and productivity growth?”** The JRC metadata and abstract confirm non-parametric plots and regressions. A usable full text was not obtained in this search, so it is not included among the six full-text-inspected examples. DOI: https://doi.org/10.1016/j.strueco.2019.04.006. Record: https://publications.jrc.ec.europa.eu/repository/handle/JRC115792.
- **Fuest et al. (2024), EconPol Policy Report 50:** full PDF retrieved; title, abstract and the relationship to the Dietrich et al. article checked. It is provided as related reading, not counted separately or described as fully audited.

## Local source files

PDFs are saved in `Sources/`. The original download and extracted-text working files are in `C:\Users\s2551183\AppData\Local\Temp\opencode\descriptive-examples`; the World Bank book and its extracted text are in `C:\Users\s2551183\AppData\Local\Temp\opencode\rd-income-research`.

The guide’s paragraph model, suggested titles, outline and recommended figure sequence are original suggestions for the user’s project, not quotations or findings reported by the cited publications.
