# Research and data audit

**Paper:** *R&D and Prosperity: Conditional, Not Automatic*  
**Research vintage:** 11 November 2026  
**Purpose:** Distinguish retrieved evidence, independently checked transformations, descriptive calculations and literature-supported interpretations.

## 1. Scope and relationship to the earlier draft

This paper develops the R&D–income argument from the user's draft and previous literature review. It adds a full national-data reconstruction, robustness checks and a matched-year manufacturing decomposition. It retains absorptive capacity, commercialisation, intermediaries and non-R&D innovation as substantive themes.

This is a targeted critical narrative review and reproducible descriptive study. It is not an exhaustive systematic review, meta-analysis or replication of the cited causal studies. Search and reading prioritised original research, official statistical documentation and evidence that could either strengthen or qualify the draft's argument. Research favourable to R&D was retained.

Earlier manuscripts are separate historical outputs. Their statements that the website's underlying observations were unavailable are superseded by the new analysis. The earlier presentation's approximately 0.25 R² has **not** been independently reproduced as that exact presentation regression. The website static model has been reproduced: nominal R² 0.3588110747; PPP R² 0.2673957281. Similarity to the old slide does not establish identity.

## 2. Archive identity and vintage

| Item | Recorded value |
|---|---|
| Dashboard | https://handysatria1.github.io/world-rd-income/ |
| Downloaded archive | https://handysatria1.github.io/world-rd-income/world-rd-income.zip |
| Local archive | `Archive/world-rd-income.zip` |
| Size | 306,578,962 bytes |
| SHA-256 | `5094ee093f0abd22a335ccaaf5d0da8c8ba5fa0e453244ad6023877901ddc9eb` |
| National build | `2026-11-11T11:48:34+00:00` |
| Sixteen-group industry build | `2026-11-11T17:27:52.299245+00:00` |
| WDI response update | `2026-10-08` |
| Contemporary repository HEAD | `d3d98d45318581a7fb0d561cc60b02760209cf17` |
| HEAD commit timestamp | `2026-11-11T18:07:47Z` |
| Verification report | `Data/archive_verification.json` |

The contemporary HEAD is preserved as contextual repository metadata, **not** asserted to be the precise archive-build commit. The release listing for `snapshot-2026-11-11-unified-dashboard` reports an archive asset size of 306,559,980 bytes, different from the actual downloaded file. The paper identifies its input by the downloaded file's hash rather than claiming exact release-asset identity.

The frozen `Sources/live_view-national.html` contains the national observations consumed by `analyse_national.py`; its SHA-256 is recorded in `Data/national_validation.json`. Its country data, year bounds, source metadata and national build match the extracted archive's `explorer_history.json`. The unused `sectorField` and `breakdowns` metadata differ between those objects, so equality of the entire embedded payload is not claimed. Decompressed live `research_group_joined.csv.gz` and `income_classifications.csv` also match the extracted archive byte for byte.

The initial download manifest records five literature-PDF requests alongside repository and website metadata. Subsequent Comin and supplemental-table acquisitions have separate manifests. Two attempted convenience URLs, `rd_economy_joined.csv.gz` and `rd_industry_coverage.csv.gz`, returned errors; the required uncompressed tables were obtained from the complete archive. These failed URLs do not represent missing inputs in the completed analysis.

## 3. What was independently verified

### 3.1 Original-file integrity

`verify_archive.py` recomputes and checks 114 file hashes against the archived manifests in `raw`, `broad_sector_raw`, `rd_industry_raw`, `sector_economy_raw` and `income_raw`. The file-level results are in `Data/verified_source_hashes.csv`.

Hash checks establish that retained files agree with the archive's recorded source responses. They do not establish that the original provider's statistical estimates are error-free, or that every extraction and classification is independently correct.

### 3.2 National values and sample replication

The normalised national observations were compared directly with the archived responses:

| Source response | Nonmissing observations checked |
|---|---:|
| WDI R&D history | 2,212 |
| WDI nominal GDP per capita history | 5,428 |
| WDI PPP GDP per capita history | 5,130 |
| OECD MSTI GERD/GDP history | 1,077 |
| **Total** | **13,847** |

WDI pagination and nonmissing coverage were checked; national observations were screened against the provider's aggregate-country codes. OECD frequency, measure, unit and multiplier were checked. Basque source extraction was not independently reimplemented.

The Python-selected static sample was compared with the archive's supplied `world_2025_ppp.csv`, checking economy membership, R&D values, both income measures and contributing-year counts. Agreement is at numerical precision. For each of sixteen national specifications and both income metrics, OLS coefficients and R² were checked through separate statsmodels and SciPy calculations. The package retains sample and exclusion files rather than only regression summaries.

### 3.3 Industry arithmetic

`analyse_sectors.py` checks:

- 6,243 nonmissing published BERD/GVA ratios against the joined monetary values, requiring complete numerator and denominator coverage.
- 153 numeric GVA/BERD signed source-term sums for the six selected economies in 2022, including available partial allocations. The check uses the original units before comparing the converted joined amounts.
- Unique economy/year/group keys and complete selected GVA groups.
- Complete five-group manufacturing data for 19 economies.
- Common manufacturing weights summing to one.
- Exact reconciliation of each midpoint-decomposition group and its total before rounding.

These checks do not amount to rebuilding all 355,809 source terms or independently validating every class-set mapping. Official extraction, the complete concordance and Basque native-source treatment also rely on the upstream project's documented validations. `Data/sector_validation.json` states this boundary.

## 4. National selection rules

1. The catalogue contains 219 economies/regions. Territories are retained as economies. Basque Country is a separately identified overlapping region and is excluded from national fits; aggregate OECD/EU points are not fitted observations.
2. The static baseline uses available R&D/GDP observations in 2020–2024 and 2025 nominal and PPP income. Both income measures are required for the common sample.
3. One provider is chosen for each economy/window by observation count, following the dashboard's provider priority on ties (OECD before WDI for national series). Missing provider years are not filled from another provider.
4. R&D averaging is the arithmetic mean of available annual ratios, not a ratio of summed expenditures to summed GDP. No missing observation is treated as zero or carried forward.
5. The baseline contains 105 fitted economies plus an eligible Basque comparator. Only 56 fitted economies have all five R&D years. The number and actual years used are explicit fields in every sample.
6. The latest-usable rule searches backward from 2025 for R&D and both income measures in the same year. It yields 149 fitted economies, with years from 2002 to 2025; 41 are before 2020.
7. Same-year fits use exact observations in the specified year. The paired 2019/2023 cohort retains one provider across both endpoints and the same 78 economies.
8. The WDI-only sensitivity keeps the baseline economy sample but can alter R&D-year coverage and values. It is a provider-and-coverage check, not a pure revision-only experiment.
9. Fits are unweighted OLS with an intercept: R&D intensity in percentage points on natural-log income. No population-weighted, GDP-weighted, causal or out-of-sample prediction model is reported.
10. Spearman correlation uses income and R&D ranks; pairwise discordance is calculated directly. The PPP baseline has 1,403 discordant pairs out of 5,460, with no ties.
11. HC3 standard errors and approximate 95% intervals are conditional model diagnostics. They do not solve endogenous R&D, selection, cross-economy dependence or data-revision uncertainty.
12. Source flags are retained. An empty flag is not interpreted as a guarantee of finality. Completeness of years does not demonstrate consistency of survey methods across them.

The FY2027 income-group split is exploratory, using `classification_current.xlsx`. The historical workbook duplicates FY2027 classifications, so it is not merged a second time. Fixed classifications are not historical classifications at each R&D date, and the four-observation low-income subgroup supports no general inference.

## 5. Industry definitions and interpretation

### 5.1 Five manufacturing groups

| ID | Group | ISIC Rev. 4 target |
|---|---|---|
| 03 | General manufacturing | C10–18, C31–33 |
| 04 | Chemicals and non-metallic | C19–23 |
| 05 | Transport equipment | C29–30 |
| 06 | Computer, electronic and optical | C26 |
| 07 | Electrical, machinery and metals | C24–25, C27–28 |

The full sixteen groups cover A–T without overlap. Group 16 is R–T; missing/confidential U is not assumed zero. Broad technology-intensity classifications and the six-group dashboard classification cannot be interchanged with this partition using fixed allocation shares.

GVA and employment shares use the complete A–T denominator. Assigned BERD shares use reported industry R&D totals, which may include U and unallocated activities. Published complete ratios require exact economy/year/group joins. Employment is persons, not researchers, hours or full-time equivalents. GVA is current-price basic-price value added, not turnover.

BERD is classified by the performer's main activity. A research-services business can therefore be located outside manufacturing even if it undertakes work for manufacturers. GVA covers the whole industry, while BERD has a business-performer scope. The paper preserves rather than erases this institutional mismatch.

### 5.2 Focal comparison limitations

- **UK:** 2022 BERD retains `OBS_STATUS=B`. A matched year avoids temporal mismatch but not a methodological break or revision.
- **Singapore:** The source scope is science-and-technology business R&D, excluding social sciences and humanities. The 2022 detailed split is absent. Native 2023 labels provide partial allocations, not complete coverage of the common groups. Neither absent nor partial data are used as whole-manufacturing ratios.
- **Basque Country:** Research scope is companies plus private non-profit institutions. Seven 2022 research groups have partial allocations and none is treated as a complete common BERD group. Regional PPP income uses Spain's national factor.
- **China:** Six BERD groups are complete in 2022, including all five manufacturing groups. This supports the manufacturing comparison, not a complete sixteen-group economy decomposition.
- **United States and Korea:** Complete manufacturing does not imply that every nonmanufacturing group is complete. The analysis uses the five complete manufacturing groups explicitly.

### 5.3 Two different accounting exercises

The **midpoint decomposition** uses industry shares of **total economy GVA**. Its object is manufacturing BERD / total GVA. The composition component includes manufacturing's overall size as well as the mix within manufacturing. The within-group component can include narrower product-mix differences and is not a pure firm-behaviour effect. A component can exceed the net gap when the other component is negative.

The **standardisation** uses industry shares of **manufacturing GVA**. The reference is the unweighted average mix across the 19 complete-data economies. It computes a hypothetical common-mix ratio, not an attainable policy counterfactual. Neither calculation explains the national GERD/GDP gap or GDP-per-capita gap. The 70.4% Korea–UK figure must always retain this denominator and manufacturing-contribution qualification.

## 6. Literature reading and verification scope

“Examined” means the specified passages were read, not that every page or appendix was reviewed. Prior source-reading audits are retained in `Sources/Prior_Audits/`. Sources were accessed through official publication pages, institutional repositories, original/author manuscripts and downloaded PDFs. Search-result summaries were used for discovery rather than as substitutes for inspected evidence.

| Source | Version and passages examined | Use and boundary |
|---|---|---|
| Cohen & Levinthal (1990) | Published article PDF; opening pp. 128–129 | Prior knowledge and recognition/assimilation/application of external knowledge. Conceptual mechanism, not a country-level causal estimate. |
| Teece (1986) | Published article PDF; introduction and §3.3, pp. 288–289 | Complementary assets, commercialisation and distribution of returns. National extension is interpretive, not directly estimated by this paper. |
| Howells (2006) | Published article PDF; p. 720/Table 2, case-method discussion and pp. 725–726 limitations | Ten-function intermediary framework and 22 exploratory organisations. No quantitative average treatment effect inferred. |
| Huang, Arundel & Hollanders (2010) | UNU-MERIT WP 2010-027; sample/data discussion pp. 20–21, opening and summary passages | 14,931 innovative firms, 15 countries, 1998–2000; weighted 46% neither performed nor contracted R&D. Not a current global percentage. Working-paper status checked in Maastricht's repository. |
| OECD/Eurostat (2018) | Oslo Manual; §§3.9–3.18 and 4.8–4.17 | Innovation requires implementation, includes adoption/non-R&D activity, and need not achieve commercial success. |
| Comin et al. (2019) | ZEW DP 19-006; introduction and identification discussion, pp. 12–16 | Fraunhofer firm links and heteroscedasticity-based IV. Abstract results distinguished from identifying assumptions; long-run/macroeconomic scenarios not treated as directly observed outcomes. |
| Cirera & Maloney (2017) | Official World Bank book; executive summary pp. xix–xxiv; prior descriptive reading pp. 26–29 | Complementary capabilities, catch-up and R&D–income charts. No full-book review claimed. |
| Carvalho (2022) | ERC Insight Paper; prior reading §§2–3, pp. 6–10; Figure 1 p. 12; Table 2 p. 19; Figure 6 p. 21; conclusion pp. 32–35 | Precedent for industry benchmarking and explicit coverage. Its historical UK estimates are not transplanted into the revised 2022 dataset. |
| Hall, Mairesse & Mohnen (2010) | NBER WP 15622, November 2009; pp. 3–6, 20, 33–34; final chapter metadata checked | Positive/heterogeneous returns, stocks, simultaneity and historical manufacturing concentration. Working paper and chapter count as one study. |
| Griffith, Redding & Van Reenen (2004) | IFS W00/02, August 2001; opening, pp. 10–12, 27–28, 32–33; final metadata checked | Innovation and absorptive capacity in a historical twelve-country industry panel. Detailed methods refer to the working version. |
| Moretti, Steinwender & Van Reenen (2025) | Accepted manuscript; pp. 9–14 and 30–33; published abstract/metadata | Government-financed business R&D, crowding-in and productivity. Weak French/productivity-spillover first stages retained as limitations. Related versions are one study. |
| Fieldhouse & Mertens (2026) | Dallas Fed WP 2305, revised November 2024; opening results, pp. 3–4 and 9–12; final AER record/abstract checked again on 11 November 2026 | Narrative appropriation shocks and delayed productivity. Final citation is AER 116(11), 3959–4002. Final abstract verifies 140–210% implied returns; details of all final revisions were not independently audited. |
| Bloom et al. (2020) | Published AER PDF; pp. 1104–1107, 1136–1139 | Increasing effort and declining measured research productivity; accounting/selection limitations retained. Not a universal return-decline estimate. |
| Dechezleprêtre et al. (2023) | Published AEA abstract and metadata | Policy-threshold evidence on R&D/patenting and spillovers. Full robustness analysis was not independently read. |
| Bloom, Van Reenen & Williams (2019) | Published AEA abstract and metadata | Broad policy-mix synthesis. Not an additional independently examined causal study. |
| OECD GERD definition | Official indicator definition | Domestic performance, funding boundaries and measure definition. |
| Irish CSO (2026) | Annual National Accounts 2025, Tables 2.1–2.2 and GNI* explanation | GDP/resident-income distinction. The new paper uses the mechanism without constructing a mixed-source GNI* per-capita series. |
| Eurostat (2026) | Relative GDP volumes, consumption and methodology discussion | PPP, commuters, multinational IP and GDP versus consumption. No unverified commuter-share number used. |

The earlier Fieldhouse–Mertens 2025 review was background to the prior manuscript, not additional independent evidence in the new paper. No original econometric study was re-estimated. Complete publication/download URLs appear in `Paper.md`, the prior audits, and the download manifests.

## 7. Claims the dashboard does not identify

- The causal return to an additional percentage point of GERD/GDP.
- The shares of income dispersion caused by absorption, commercialisation, intermediary quality, foreign technology or industrial policy.
- Which of the focal national research systems is most efficient.
- A universal optimal GERD target or industrial structure.
- Real growth from changes in current-dollar or current-PPP income.
- A complete six-economy industry R&D decomposition when Singapore and Basque coverage is partial.
- Population-representative or globally representative results from the available-country sample.

The paper's policy discussion follows from the combination of descriptive diagnosis and literature, rather than treating the scatter or decomposition as a programme evaluation.

## 8. Output traceability

| Paper item | Primary output |
|---|---|
| Figure 1 and baseline model | `sample_static_2020_24_income_2025.csv`, `model_statistics.csv` |
| Figure 2 | `latest_year_distribution.csv`, `sample_latest_usable.csv` |
| Figure 3 and Table 3 | `sector_cases_2022.csv`, `sector_summary_2022.csv` |
| Table 1 and matched case values | `selected_economies_all_windows.csv` |
| Table 2 | `model_statistics.csv` |
| Pairwise discordance | `pairwise_rank_discordance.csv` |
| Influence | `static_ppp_influence.csv`, `leave_one_out_ppp.csv` |
| Table 4 | `manufacturing_decomposition_totals.csv`, group-level decomposition CSV |
| Common-manufacturing-mix results | `manufacturing_standardization_19_economies.csv`, `manufacturing_standard_weights.csv` |
| Exploratory development groups | `income_group_descriptives.csv`, `static_sample_with_FY2027_income_group.csv` |
| Original-source checks | `archive_verification.json`, `verified_source_hashes.csv` |

All table paths in this section are relative to `Data/`. Monetary comparisons are rounded for presentation; calculations use unrounded values. Percentage differences and percentage-point differences are kept distinct.

## 9. Manuscript and document checks

`validate_paper.py` checks all 97 numerical table cells against the analytical CSVs, together with key prose values for the fitted equation, uncertainty diagnostics, matched country cases, pairwise discordance, leave-one-out results, income groups and manufacturing standardisation. It also confirms the reported source-verification counts and the presence and equality of the editable Word tables.

The final PDF contains 19 pages; all pages have text, and its page layouts were visually inspected using rendered thumbnails. The three figures were also inspected separately. Word contains four editable tables and three embedded figures. Figures are grouped on landscape pages before the references in Word/PDF, preserving the discussion sequence without introducing sparsely filled pages around individual figure insertions. Markdown retains figures near their discussion.

PDF is independently typeset from the same Markdown as Word, rather than exported by Word. The editable Word structure and numerical content were checked; its pagination is application-dependent and is not asserted to be identical to the PDF. A Microsoft Word automation export stalled; the dedicated automation processes were closed, and the delivered PDF was produced using the included portable ReportLab renderer. No PDF output from the interrupted export is used.

The word-count report includes 6,788 words before the references, counting the abstract, tables, captions and data statement. The manuscript has twenty references. `Data/document_validation.json` records numerical and document checks; `Delivery_Manifest.json` identifies files included in the compact ZIP by SHA-256.
