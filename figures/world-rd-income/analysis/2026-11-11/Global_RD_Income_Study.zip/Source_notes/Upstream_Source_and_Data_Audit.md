# R&D and GDP per capita: source-reading and data audit

**Date:** 9 November 2026.  
**Manuscript:** [Does More R&D Make a Country Richer?](../Myth_RnD_and_GDP_per_Capita_Deep_Research.md)

## 1. Research scope

This is a targeted critical narrative review and chart audit, not an exhaustive systematic review, meta-analysis or replication of the cited econometric studies. Searches sought evidence on R&D returns, productivity, absorptive capacity, research productivity, industrial composition and national-income measurement. Original publication records, accessible original manuscripts and official statistical sources were prioritised. Positive evidence was retained alongside limitations.

The dedicated web-search integration returned no results. Browser-based Google searches were used for discovery, followed by direct inspection of original sources. Search snippets and AI-generated search summaries were not used as evidence. Several direct OECD/AEA downloads returned HTTP 403; accessible official browser pages, author-hosted PDFs and institutional repositories supplied the cited material.

## 2. What was substantively examined

“Text examined” below means the specified sections were read, not that every page, appendix or cited reference was assessed. Pagination refers to the inspected version. Text-extraction line numbers are working locators, not publication page citations.

| Source | Access and version | Substantive examination | Use and boundary |
|---|---|---|---|
| Hall, Mairesse & Mohnen (2010) | Full NBER WP 15622 PDF, November 2009; final chapter metadata checked | Introduction and conceptual framework, printed pp. 3–6; simultaneity discussion, p. 20; conclusions, pp. 33–34. Extracted lines 95–339, 975–1031, 1595–1653 | Positive and heterogeneous returns; stocks, depreciation, endogeneity and manufacturing-heavy coverage. The final chapter is not separately counted as evidence. |
| Griffith, Redding & Van Reenen (2004) | IFS W00/02, August 2001 text; final journal metadata checked | Opening argument; data discussion, printed pp. 10–12; measurement-error/IV robustness, pp. 27–28; conclusion, pp. 32–33. Extracted lines 1–140, 507–591, 1305–1394, 1545–1606 | Innovation and absorptive capacity; twelve-country historical industry panel. Exact sample/method details refer to the inspected WP, not an assertion that all details are unchanged in the final article. |
| Guellec & van Pottelsberghe (2004) | Published abstract and metadata via RePEc | Abstract only | Sixteen-country, 1980–1998 evidence on business/public/foreign R&D and institutional heterogeneity. Full specification and robustness not independently assessed. |
| Cirera & Maloney (2017) | Full official World Bank book PDF | Executive summary, printed pp. xix–xxiv; extracted lines 555–837. Keyword searches used to locate material | Complementary inputs, managerial and government capabilities, limits of raw GERD benchmarking. Not represented as a full-book review or a separately identified causal estimate. |
| Moretti, Steinwender & Van Reenen (2025) | LSE accepted manuscript; published abstract/metadata checked | Identification and data, printed pp. 9–14; productivity and conclusions, pp. 30–33. Extracted lines 495–739 and 1510–1712 | Crowding-in and OECD productivity effects. Important qualifications: government-funded business R&D is not all public research; French productivity IV first stages and international productivity-spillover first stages are weak. Research-investment spillovers and productivity spillovers are not equated. |
| Fieldhouse & Mertens original study, published 2026 | Dallas Fed WP 2305 revised November 2024; November 2026 AER record and abstract checked | Introduction and key results; narrative shock construction and identification, printed pp. 3–4 and 9–12. Extracted lines 95–174 and 360–529; supplementary reading via the 2025 review | Long-run nondefense productivity evidence; historical appropriations, research stocks, infrastructure adjustment and identification limits. Published abstract verifies 140–210% implied returns and a one-fifth TFP-growth contribution; the latter is not re-estimated here. Detailed discussion explicitly attributes the inspected WP version. |
| Fieldhouse & Mertens (2025), review/application | NBER WP 33780, May 2025; NBER confirms 2026 chapter publication | Opening 630 extracted lines, including §§1–2 and warnings about return comparability/extrapolation | Context and qualification for their original study. No independent replication claimed. CHIPS scenarios are conditional projections and not used as observed outcomes. |
| Dechezleprêtre et al. (2023) | Official AEA published record | Abstract only | Tax-relief eligibility threshold, R&D and patenting, persistence up to seven years and technologically close-firm spillovers. No national GDP effect or independent robustness verification claimed. |
| Bloom et al. (2020) | Published AER PDF hosted by Charles Jones at Stanford | Introduction, pp. 1104–1107; selection/measurement and conclusion, pp. 1136–1139. Extracted lines 1–177 and 2045–2187 | Increasing research effort and declining measured research productivity; counterfactual interpretation and measurement limitations. No universal country-specific decline rate inferred. |
| Bloom, Van Reenen & Williams (2019) | Official AEA record | Abstract only | Broad policy-toolkit conclusions about funding, tax incentives and human-capital supply. Not treated as an additional causal study. |
| OECD GERD indicator | Official OECD page | Full indicator definition | Domestic performance versus funding, including foreign funding and excluding domestic funds for research abroad. |
| OECD R&D industry taxonomy (2016) | Official OECD page and bibliographic record | Abstract only | R&D/value-added taxonomy; distinction from overall knowledge intensity and technology use. Sector decomposition in the manuscript is an accounting identity, not an estimated OECD result for the six cases. |
| Irish CSO (2026) | Official Annual National Accounts 2025 page | Tables 2.1–2.2 and GNI* explanatory text | 2025 GDP €602,440.920m; GNI* €333,971.190m; official rounded share 55.4%; three stated adjustments. 2025 values preliminary. |
| Eurostat (2026) | Official Statistics Explained page | Relative GDP volumes, consumption and methodology sections | PPP, cross-border workers, multinational IP ownership and GDP versus AIC. No current numerical commuter share asserted. |
| Supplied presentation | Local PDF extraction | PDF pp. 14–15, extracted P8-compact.txt lines 433–530 | Axis definitions, reported R², country labels, source notes, reported R&D intensities and available-year averaging. Full regression/data not obtained. |

The two downloaded Moretti versions are one study. Hall and Griffith working papers and published articles are likewise one study each. The Fieldhouse review and chapter repeat/apply the underlying appropriations analysis; they are not counted as independent confirmation.

## 3. Observations, calculations and interpretations

### Presentation-reported, not independently replicated

- Average R&D/GDP: Korea 4.81%, United States 3.45%, Singapore 1.98%.
- The companion slide also reports UK 2.82%, China 2.50% and Basque Country 2.10%; these are not independently reconstructed in this project.
- Chart's logarithmic R²: approximately 0.25.
- Nominal comparison window: R&D intensity 2020–2024; GDP per capita 2025.
- Companion slide's average-of-available-observations rule; chart's separate WIPO citation for Indonesian GERD in 2020.

### Independently retrieved official observations

Two World Bank API responses are archived without changing their contents:

1. `WorldBank_GDP_per_capita_2024_2025.json`: NY.GDP.PCAP.CD for Korea, Singapore, the US, Ireland and Luxembourg, 2024–2025.
2. `WorldBank_GDP_per_capita_PPP_2025.json`: NY.GDP.PCAP.PP.CD for Korea, Singapore and the US, 2025.

Both responses report `lastupdated: 2026-10-08`. Retrieval date is 9 November 2026. These are source-vintage observations, not a guarantee that values will never be revised. An empty `obs_status` field is not interpreted as an explicit guarantee of finality.

| Economy | GDP per capita, 2025, current US$ | GDP per capita, 2025, PPP current international $ |
|---|---:|---:|
| Korea | 36,226.9663637512 | 63,124.9152183625 |
| United States | 90,026.5163005744 | 90,026.5163005744 |
| Singapore | 98,813.9788172877 | 163,353.990260152 |
| Ireland | 131,592.462547877 | Not retrieved |
| Luxembourg | 147,252.179121515 | Not retrieved |

“Not retrieved” is not a zero and does not imply that a source observation is unavailable. These five countries are selected checks, not the full scatter dataset. The companion CSV leaves uncollected values blank and supplies status fields.

### Independent arithmetic

- Korea/Singapore reported intensity ratio: 4.81 / 1.98 = 2.4292929293.
- Korea minus Singapore reported intensity: 2.83 percentage points.
- Singapore/Korea nominal GDP-per-capita ratio: 2.7276360329.
- Singapore/Korea PPP GDP-per-capita ratio: 2.5877894599.
- Irish GNI*/GDP from CSO chart values: 333,971.190281729 / 602,440.9204605 × 100 = 55.4363389%, consistent with the official rounded 55.4%.

The CSO ratio is calculated wholly within the CSO dataset. It is not applied to World Bank GDP per capita to construct a supposedly observed Irish GNI* per capita. Differences in source vintage or population definitions would need to be reconciled first.

### Analytical interpretations, not estimated findings

- The logarithmic trendline is interpreted conditionally as R&D intensity = a + b ln(GDP per capita), based on the displayed axes. The underlying specification remains unverified.
- Under a one-regressor, unweighted OLS model with an intercept and positive slope, R² = 0.25 implies correlation about +0.50 for intensity and log income. No regression was independently run here.
- Shared GDP denominators, industrial composition, accumulated research, complementary capabilities, foreign knowledge and accounting boundaries are mechanisms supported by definitions or literature. Their relative contribution to the supplied scatter has not been estimated.
- The hypothetical $20,000/4% and $80,000/2% example is an accounting illustration, not country data.
- The panel equation and causal-design proposals are recommendations, not implemented analyses.

## 4. Unresolved chart issues

1. Complete unrounded observations and original regression workbook.
2. Included countries and any selection criteria.
3. Whether EU/OECD aggregate points enter the fit.
4. Whether and how the Basque observation enters the fit alongside national observations.
5. Annual availability, survey breaks and provisional flags for each R&D average.
6. Exact average definition, fit weights, intercept and logarithmic transformation.
7. Definition of the OECD reference line: aggregate ratio, country mean or another calculation.
8. Comparability and currency conversion for Basque income data.
9. Full-sample PPP, influence, weighting and pre-pandemic sensitivity analyses.

The paper does not claim to have resolved these issues. Its selected ranking check and literature synthesis are valid within the stated scope, while a publication presenting a replicated regression would require the underlying data.

## 5. Research workspace and access links

Downloaded PDFs and searchable extractions used during drafting are retained in:

`C:\Users\s2551183\AppData\Local\Temp\opencode\rd-income-research`

The raw API responses relevant to the manuscript are also retained in this project folder. Publication and download URLs are supplied in the manuscript references. Local PDFs are working research copies; their existence does not imply that every page was read.

### Suggested wording for the original chart

**Main finding:** Countries with higher R&D intensity do not consistently have higher GDP per capita.

**Evidence:** Korea's reported R&D intensity exceeds Singapore's, while Singapore has higher GDP per capita at both market exchange rates and PPP. The selected comparison illustrates differing rankings; it does not estimate research efficiency or causal returns.

**Statistical note:** With the displayed axes, the reported logarithmic R² describes the fit of R&D intensity to log income. It is not the percentage of GDP or growth caused by R&D.

**Research conclusion:** Studies of policy-induced R&D changes find positive innovation and productivity effects in several settings. Their magnitude and timing depend on funding design, research type, capabilities and spillovers.
