# Global R&D and income study

## New: policy brief and supervisor-ready methods

- **[Policy brief — PDF](Policy_Brief/Policy_Brief.pdf)** · [Word](Policy_Brief/Policy_Brief.docx) · [Markdown](Policy_Brief/Policy_Brief.md)
- **[Methods guide — PDF](Methods/Methods_Guide.pdf)** · [Word](Methods/Methods_Guide.docx) · [Worked Excel example](Methods/Worked_Example.xlsx)
- [Policy evidence workbook](Policy_Brief/Policy_Brief_Evidence.xlsx) · [Patterns tested globally](Policy_Brief/Patterns_and_Hypotheses.md)
- [PDF reading ledger](Policy_Brief/PDF_Review/Reading_Ledger.md) · [Comparability notes](Policy_Brief/Comparability.md)

The nine-page brief adds the requested Basque Country–Singapore, Korea–UK and US–China comparisons while keeping the global evidence central. The ten-page methods guide explains partial correlations, actual calculations, Excel formulas, industry accounting and likely supervisor questions. The eight presentation texts were read; wider-library reading depth is recorded individually for 78 unique PDFs from 92 paths. Follow [Policy_Brief/README.md](Policy_Brief/README.md) for the additional offline commands.

## Read the results

- **[Paper — PDF](Paper.pdf)** · **[Editable Word](Paper.docx)** · [Markdown](Paper.md)
- **[Key findings](Key_Findings.md)**
- **[Analysis workbook](Global_Analysis.xlsx)**
- **[Deep literature review and reading ledger](Literature_Review.md)**
- **[How leading papers structure the argument](Journal_Argument_Guide.md)**
- [Research audit](Research_Audit.md) · [Data dictionary](Data_Dictionary.md)
- **[Portable delivery ZIP](Global_RD_Income_Study.zip)**

The study starts with 83 matched 2022 economies and selects examples from all 120 eligible near-intensity pairs. It develops capability, industrial-accounting and income-source explanations, then evaluates research outputs, funding/focus, intermediaries, diffusion and timing. The main manuscript contains seven tables, five figures and 24 references. The deeper companion review records 22 academic works and official institutional material, with actual reading depth and versions.

## Reproduce offline calculations

From this directory, using [uv](https://docs.astral.sh/uv/):

```powershell
uv run --python 3.13 analyse_global.py
uv run --python 3.13 render_paper.py
uv run --python 3.13 build_deliverables.py
uv run --python 3.13 validate_global.py
```

All analytical inputs are included. The large original project archive and sibling `Revision/` directory are not required for these four commands. The scripts make no network requests; uv may need internet to install the exact dependencies declared in each script header. Once cached, add `--offline` to the uv commands. Source acquisition helpers are separate from the offline reproduction path.

`analyse_global.py` generates the country table, correlations, 17 models, pair selections, timing diagnostics, five figures and 17-sheet workbook. `render_paper.py` resolves the template's numeric values and data tables. `build_deliverables.py` independently typesets PDF and Word from the same Markdown. `validate_global.py` recomputes arithmetic with independent linear algebra and checks document contents/layout bounds.

## Verify the package

```powershell
uv run --python 3.13 package_delivery.py
uv run --python 3.13 verify_delivery.py
```

The verifier extracts into a new temporary directory, checks the delivery manifest, runs ten offline steps covering the global study, methods example, reading ledger and policy brief, and compares regenerated CSV outputs and all three PDFs' text. It records `Data/portable_reproduction.json`. Repackage after adding that report, then use `verify_delivery.py --integrity-only` to check the final ZIP. The full reproduction run needs the pinned dependencies already cached.

## Files and evidence

| Location | Purpose |
|---|---|
| `Data/input_*.csv`, `supplement_annual.csv`, `raw_wb/` | Frozen analytical inputs and raw supplementary responses |
| `Data/input_manifest.csv` | Input hashes and file sizes |
| `Data/*.csv` | Derived results, sample membership and manuscript values |
| `Data/global_validation.json` | Independent numerical and document checks |
| `Data/portable_reproduction.json` | Isolated offline rebuild report |
| `Figures/` | Five full-resolution figures |
| `Source_notes/` | Extract provenance and inherited upstream audit reports |
| `Sources/` | Source URLs, retrieval/hashes, bibliographic/identity audit and institutional/statistical metadata |
| `PDF_contact_sheet.jpg` | Visual overview of the final PDF |
| `Delivery_Manifest.json` | Hashes of the delivered payload |
| `Policy_Brief/` | New global policy brief, six-case profiles, hypotheses, sources, frozen inputs and code |
| `Methods/` | Supervisor guide, worked example, Excel formulas, residuals and checked calculations |

Full literature PDFs and extracted texts are retained in the original research workspace; the portable bundle contains the review, reading ledger and source provenance. Wrong-paper exploratory downloads are excluded. Online helpers `collect_data.py`, `collect_sources.py` and `audit_bibliography.py` are historical acquisition tools; `prepare_inputs.py` copies additional upstream validation extracts and requires the original project layout. They are not needed to regenerate the included results.

## Important interpretation

Observation years are matched where available: main analysis 2022, HCI 2020, and rents 2021 for 80 economies / 2020 for Kuwait and Syria / unavailable for Turkmenistan. Samples change with coverage, so model improvements are compared within fixed samples. Associations and accounting counterfactuals are not causal returns. Current R&D flows, scientific counts, national income, domestic value-added trade and intermediary effectiveness are different measures.

Original archive SHA-256: `5094ee093f0abd22a335ccaaf5d0da8c8ba5fa0e453244ad6023877901ddc9eb`. See the audit for attribution to the explorer and underlying official providers, source vintages and verification scope.
