# Global findings: similar R&D intensity, different prosperity

**Main conclusion:** higher R&D intensity is associated with higher income globally, but the spending share alone is an incomplete measure of an economy's capacity to generate and use knowledge.

## What the data show

- **83 economies, matched in 2022:** Spearman correlation between GERD/GDP and PPP GDP per capita is **0.701**. A linear model of log income on intensity has **R² = 0.285**; nonlinear specifications reach 0.390–0.414.
- **120 comparable-intensity pairs:** both an absolute gap ≤0.15 percentage points and a relative gap ≤10% are required. Median income ratio: **1.57×**; **47 pairs** differ by at least twofold. Pairs overlap and are not independent causal comparisons.
- **The data choose the examples:** the largest gaps within four intensity bands are Kenya–Saudi Arabia (**12.23×**), Egypt–Luxembourg (**8.38×**), Greece–Ireland (**3.51×**) and China–Iceland (**3.33×**). These are selected extremes, not typical effects.

## Three supported explanations—with different evidence

### 1. Capabilities and knowledge use

Conditional on R&D intensity, income is strongly associated with government effectiveness (**r = 0.835**), internet use (**0.736**) and human capital measured in 2020 (**0.688**). On the same 79 economies, these capability indicators reduce held-out log-income prediction error from **0.615 to 0.303**.

Research capacity and scientific output also matter descriptively. On the same 70 economies, conditional correlations are **0.777 for articles**, **0.612 for researchers** and **0.258 for resident patent applications**. These signals overlap with capabilities and cannot be added as independent causal contributions.

**Example:** China and Iceland devote **2.495% and 2.558%** of GDP to R&D, but have PPP GDP per person of **$23,028 and $76,592**. Iceland has more researchers and articles per resident; China has more resident patent applications. Patent volume alone does not rank their incomes.

### 2. Industrial composition changes the benchmark

Aggregate intensity mixes sector weights with research intensity within sectors. Holding within-group intensity fixed and imposing common manufacturing weights changes Türkiye's manufacturing BERD/GVA from **2.67% to 6.15%**, Finland's from **7.18% to 5.87%**, and the US value from **13.20% to 10.60%**.

This directly supports an **accounting explanation of the spending benchmark**. Broad manufacturing, export and funding shares provide weak additional income prediction on their smaller common sample; the paper reports this adverse result explicitly.

### 3. Income has sources and boundaries beyond current domestic R&D

Kenya–Saudi Arabia illustrates the relevance of resources: their **2021** resource-rent shares are **1.23% and 25.57%** of GDP. Ireland, Luxembourg and Singapore illustrate the production–resident-income distinction: their **2022 GNI/GDP ratios are 68.35%, 64.71% and 80.63%**.

These observations help interpret extreme contrasts. They do not quantify how much of each income gap is caused by resources, multinational production or cross-border income flows.

## Additional mechanisms examined

- **Diffusion and non-R&D innovation:** firms can improve through adoption, engineering and organisational changes.
- **Management and resource allocation:** knowledge creates more value when firms can implement it and productive firms can expand.
- **Commercialisation and value capture:** inventors, producers and owners of complementary assets need not capture the same returns; gross exports are not domestic value added.
- **Knowledge stocks and timing:** current spending is a flow, while income reflects accumulated investments. Exploratory growth estimates are positive after controlling initial income, but all three HC3 intervals include zero.
- **Intermediaries:** Fraunhofer, Catapults and A*STAR illustrate distinct organisational mechanisms. National funding shares do not measure their effectiveness. Business-funded university R&D has no robust positive conditional income association here.

## What this changes in the argument

The strongest claim is **“research contributes to prosperity through capabilities, production and knowledge use”**, supported by the broader literature and consistent with the global evidence. The study does not identify causal shares of national income gaps.

The paper is accompanied by a mechanism-led review of **22 academic works**, an explicit reading/access ledger, official intermediary evidence, and a guide to argument structures in leading economics and innovation papers. The review is targeted rather than exhaustive.

## Read next

- [Manuscript PDF](Paper.pdf) · [Editable Word](Paper.docx)
- [Global analysis workbook](Global_Analysis.xlsx)
- [Deep literature review](Literature_Review.md)
- [Journal argument guide](Journal_Argument_Guide.md)
- [Research audit](Research_Audit.md)
