# /// script
# requires-python = ">=3.13"
# dependencies = ["numpy==2.5.4", "pandas==3.1.1", "scipy==1.18.1", "python-docx==1.2.0", "pymupdf==1.26.7", "pillow==12.0.0", "openpyxl==3.1.5"]
# ///
"""Independent arithmetic, source joins, model diagnostics and document checks.

Uses NumPy linear algebra and PRESS rather than importing the analysis routines.
No network access or upstream project directory is required.
"""
from pathlib import Path
from itertools import combinations
import hashlib
import json
import re
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from docx import Document
import pymupdf
from PIL import Image, ImageDraw
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parent
D = ROOT / "Data"
checks = {}
def read(name):
    return pd.read_csv(D / (name + ".csv"),low_memory=False)
def same(a,b):
    assert np.allclose(np.asarray(a,dtype=float),np.asarray(b,dtype=float),rtol=1e-8,atol=1e-9,equal_nan=True), (a,b)
def model(q,xs,y="log_ppp"):
    X=np.column_stack([np.ones(len(q)),q[xs].to_numpy(float)])
    yv=q[y].to_numpy(float)
    inv=np.linalg.pinv(X)
    beta=inv@yv
    residual=yv-X@beta
    h=np.einsum("ij,ji->i",X,inv)
    cov=inv@np.diag((residual/(1-h))**2)@inv.T
    se=np.sqrt(np.diag(cov))
    critical=student_t.ppf(.975,len(q)-X.shape[1])
    return dict(beta=beta, residual=residual, r2=1-residual@residual/np.sum((yv-yv.mean())**2),
                rmse=np.sqrt(np.mean((residual/(1-h))**2)), se=se, low=beta-critical*se, high=beta+critical*se)
def partial(q,x,controls,y="log_ppp"):
    a=model(q,controls,x)["residual"]
    b=model(q,controls,y)["residual"]
    return np.corrcoef(a,b)[0,1]

manifest=read("input_manifest")
for r in manifest.itertuples():
    p=ROOT/r.path.replace("\\","/")
    assert p.stat().st_size==r.bytes and hashlib.sha256(p.read_bytes()).hexdigest()==r.sha256,r.path
checks["frozen_input_hashes"]=len(manifest)
d=read("global_countries_2022").set_index("iso3")
assert len(d)==83 and d.index.is_unique and "ES-PV" not in d.index
core=read("input_sample_same_year_2022").set_index("iso")
assert set(core.index)==set(d.index)
for col in ["rd","ppp","nominal"]:
    same(d[col],core.loc[d.index,col])
assert core.gdp_year.eq(2022).all()
same(d.log_ppp,np.log(d.ppp));same(d.log_nominal,np.log(d.nominal))
same(d.log_population,np.log(d.population));same(d.log1p_rd,np.log1p(d.rd));same(d.rd_squared,d.rd**2)
checks["core_economies_and_years"]=83

sup=read("supplement_annual")
sup=sup.loc[sup.iso3.isin(d.index)]
inn=read("input_innovation_annual")
inn=inn.loc[inn.iso3.isin(d.index)]
assert not sup.duplicated(["iso3","metric","year"]).any()
assert not inn.duplicated(["iso3","metric","year"]).any()
raw_count=0
for metric,q in sup.groupby("metric"):
    obj=json.loads((D/"raw_wb"/(metric+".json")).read_text(encoding="utf-8-sig"))
    assert obj[0]["pages"]==1
    raw={(r["countryiso3code"],int(r["date"])):r for r in obj[1] if r["countryiso3code"] in d.index}
    assert len(raw)==len(q)
    for row in q.itertuples():
        r=raw[(row.iso3,row.year)]
        same([row.value],[np.nan if r["value"] is None else r["value"]])
        assert ("" if pd.isna(row.obs_status) else str(row.obs_status))==r.get("obs_status","")
        raw_count+=1
    if q.year.eq(2022).any():
        same(d[metric],q.loc[q.year.eq(2022)].set_index("iso3").value.reindex(d.index))
    else:
        assert metric not in d.columns
for metric,q in inn.loc[inn.metric.ne("rd")].groupby("metric"):
    same(d[metric],q.loc[q.year.eq(2022)].set_index("iso3").value.reindex(d.index))
same(d.hci_2020,sup.loc[sup.metric.eq("hci")&sup.year.eq(2020)].set_index("iso3").value.reindex(d.index))
for name,source in [("rents",sup),("researchers",inn)]:
    q=source.loc[source.metric.eq(name)&source.year.between(2020,2022)&source.value.notna()].sort_values("year").groupby("iso3").tail(1).set_index("iso3").reindex(d.index)
    same(d[name+"_prior"],q.value);same(d[name+"_prior_year"],q.year)
assert d.rents_prior_year.eq(2021).sum()==80
assert set(d.index[d.rents_prior_year.eq(2020)])=={"KWT","SYR"}
assert set(d.index[d.rents_prior_year.isna()])=={"TKM"}
for metric in ["publications","patents","patentsNonresident"]:
    same(d[metric+"_pm"],d[metric]/d.population*1e6)
for metric in ["researchers","publications_pm","patents_pm","researchers_prior"]:
    same(d["log_"+metric],np.log1p(d[metric]))
same(d.rd_per_person_ppp_scaled,d.rd*d.ppp/100)
same(d.ip_payments_gdp,100*d.ip_payments_usd/d.gdp_usd)
same(d.gni_gdp,100*d.gni_usd/d.gdp_usd)
assert d.boundary_flag.equals(pd.Series(d.index.isin(["IRL","LUX"]),index=d.index)|d.rents_prior.ge(10))
assert d.internet.isna().sum()==3
checks["supplement_raw_records_values_and_status"]=raw_count
checks["year_joins_missingness_and_transforms"]=True

b=read("input_rd_breakdown_annual")
f=read("input_rd_sector_field_annual")
assert b.year.eq(2022).all() and f.year.eq(2022).all()
assert b.basis.eq("XDC_V").all() and f.basis.eq("XDC_V").all()
assert not b.duplicated(["iso3","breakdown","sector_code","category_code"]).any()
assert not f.duplicated(["iso3","sector_code","field_code"]).any()
scaled=0
for source in [b,f]:
    q=source.dropna(subset=["amount","source_value","source_unit_multiplier"])
    assert np.allclose(q.amount,q.source_value*10.0**q.source_unit_multiplier,rtol=1e-10,atol=.02)
    scaled+=len(q)
def share(iso,cube,sector,category,den_sector=None,den_cat="_T"):
    z,code=(f,"field_code") if cube=="field" else (b.loc[b.breakdown.eq(cube)],"category_code")
    n=z.loc[z.iso3.eq(iso)&z.sector_code.eq(sector)&z[code].eq(category)]
    den=z.loc[z.iso3.eq(iso)&z.sector_code.eq(sector if den_sector is None else den_sector)&z[code].eq(den_cat)]
    if len(n)!=1 or len(den)!=1 or pd.isna(n.amount.iloc[0]) or not den.amount.iloc[0]>0:
        return np.nan
    joined=pd.concat([n,den])
    flags={str(v) for c in joined if "STATUS" in c or c=="source_status" for v in joined[c].dropna()}
    return np.nan if flags&{"S2","V2"} else 100*n.amount.iloc[0]/den.amount.iloc[0]
share_count=0
for iso in d.index:
    for col in d.columns:
        args=None
        if re.fullmatch(r"fund_(BES|GOV|HES|PNP|ROW)",col):
            args=("funding","_T",col[5:])
        elif re.fullmatch(r"perform_(BES|GOV|HES|PNP|BES_PNP)",col):
            args=("funding",col[8:],"_T","_T")
        elif re.fullmatch(r"flow_[A-Z]+_to_[A-Z]+_(gerd|recipient|funder)",col):
            _,funder,_,performer,den=col.split("_")
            args=("funding",performer,funder,"_T" if den!="recipient" else performer,funder if den=="funder" else "_T")
        elif col.startswith(("research_","field_")) and not col.endswith("_classified"):
            cube,performer,category=col.split("_",2)
            args=(cube,"_T" if performer=="ALL" else performer,category)
        if args:
            same([d.loc[iso,col]],[share(iso,*args)]);share_count+=1
checks["source_unit_scalings"]=scaled
checks["funding_focus_shares_including_missingness"]=share_count

g=read("input_research_group_joined_2022")
br=read("input_rd_economy_joined")
industry_count=0
for iso in d.index:
    q=g.loc[g.iso3.eq(iso)].set_index("group_id")
    mg=q.loc[q.index.isin(range(3,8))]
    if len(q)==16 and q.gva_coverage.eq("complete").all():
        same([d.loc[iso,"gva_mfg"]],[100*mg.gva_assigned_usd.sum()/q.gva_assigned_usd.sum()])
        industry_count+=1
    for r in br.loc[br.iso3.eq(iso)&br.group.isin(["MHT","LMT","KIS","LIS"])].itertuples():
        same([d.loc[iso,"gva_"+r.group]],[r.gva_share_percent])
        eligible=r.group_complete and r.gva_usd>0 and r.coverage_status not in ["negative_reconciliation_remainder","nonpositive_reported_total"]
        expected=100*r.group_rd_total_usd/r.gva_usd if eligible else np.nan
        same([d.loc[iso,"berd_gva_"+r.group]],[expected]);industry_count+=2
mg=g.loc[g.group_id.between(3,7)&g.berd_coverage.eq("complete")&g.gva_coverage.eq("complete")&g.berd_percent_gva.notna()&g.iso3.ne("ES-PV")].copy()
valid=mg.groupby("iso3").size().loc[lambda x:x.eq(5)].index
mg=mg.loc[mg.iso3.isin(valid)]
mg["weight"]=mg.gva_assigned_usd/mg.groupby("iso3").gva_assigned_usd.transform("sum")
weights=mg.groupby("group_id").weight.mean()
same([weights.sum()],[1])
std=read("manufacturing_standardisation").set_index("iso3")
assert set(valid)==set(std.index) and len(std)==19
for iso,q in mg.groupby("iso3"):
    q=q.set_index("group_id")
    observed=100*q.berd_assigned_usd.sum()/q.gva_assigned_usd.sum()
    standard=np.sum(weights.reindex(q.index)*q.berd_percent_gva)
    same([observed,standard],[std.loc[iso,"observed"],std.loc[iso,"common_structure"]])
    same([d.loc[iso,"berd_gva_mfg"]],[observed])
assert np.isnan(d.loc["SGP","berd_gva_mfg"]) and np.isnan(d.loc["PRT","berd_gva_mfg"])
raw=read("input_btige_products_2022")
assert raw.TIME_PERIOD.eq(2022).all() and raw.UNIT_MEASURE.eq("USD").all()
raw["amount"]=raw.OBS_VALUE*10.0**raw.UNIT_MULT
export_count=0
for iso,q in raw.groupby("REF_AREA"):
    codes=[f"CPA_2_1_C{i}" for i in [20,21,26,27,28,29,30]]
    q=q.set_index("PRODUCT")
    if iso in d.index and pd.notna(d.loc[iso,"export_MHT"]) and set(["_T",*codes])<=set(q.index):
        same([d.loc[iso,"export_MHT"]],[100*q.loc[codes,"amount"].sum()/q.loc["_T","amount"]]);export_count+=1
checks["industry_ratio_and_share_checks"]=industry_count
checks["manufacturing_standardisations"]=19
checks["raw_product_export_shares"]=export_count

pairs=read("all_near_intensity_pairs")
expected={}
for a,bcode in combinations(d.index,2):
    ra,rb=d.loc[a,"rd"],d.loc[bcode,"rd"]
    gap=abs(ra-rb)
    if gap<=.15 and 2*gap/(ra+rb)<=.10:
        lo,hi=sorted([a,bcode],key=lambda x:d.loc[x,"ppp"])
        expected[(lo,hi)]=d.loc[hi,"ppp"]/d.loc[lo,"ppp"]
assert set(expected)==set(zip(pairs.low,pairs.high)) and len(expected)==120
for r in pairs.itertuples():
    same([r.income_ratio],[expected[(r.low,r.high)]])
    mean=(d.loc[r.low,"rd"]+d.loc[r.high,"rd"])/2
    assert r.band==["<0.5%","0.5–<1.5%","1.5–<2.5%","2.5%+"][sum(mean>=v for v in [.5,1.5,2.5])]
selected=read("selected_country_pairs")
for r in selected.itertuples():
    q=pairs.loc[pairs.band.eq(r.band)]
    if "excluding" in r.selection:
        q=q.loc[~q.boundary_pair]
    assert (r.low,r.high)==tuple(q.sort_values("income_ratio",ascending=False).iloc[0][["low","high"]])
large=read("pairs_large_economy_sensitivity")
for r in large.itertuples():
    eligible=set(d.index[(d.population>=1e6)&~d.boundary_flag])
    q=pairs.loc[pairs.band.eq(r.band)&pairs.low.isin(eligible)&pairs.high.isin(eligible)]
    assert (r.low,r.high)==tuple(q.sort_values("income_ratio",ascending=False).iloc[0][["low","high"]])
checks["near_intensity_pairs_and_extreme_selection"]=len(pairs)

c=read("income_correlations")
for r in c.itertuples():
    q=d.loc[r.countries.split(";")]
    assert len(q)==r.n and set(q.index)==set(d.index[d[r.metric].notna()])
    same([r.pearson,r.spearman],[np.corrcoef(q[r.metric],q.log_ppp)[0,1],np.corrcoef(q[r.metric].rank(),q.log_ppp.rank())[0,1]])
    for col,controls,y in [("partial_rd",["rd"],"log_ppp"),("partial_logrd",["log1p_rd"],"log_ppp"),("partial_quadratic",["rd","rd_squared"],"log_ppp"),("partial_nominal",["rd"],"log_nominal"),("partial_rd_population",["rd","log_population"],"log_ppp")]:
        same([getattr(r,col)],[partial(q,r.metric,controls,y)])
    ranks=q[[r.metric,"rd","log_ppp"]].rank()
    same([r.partial_rank],[partial(ranks,r.metric,["rd"])])
    same([r.partial_no_boundary],[partial(q.loc[~q.boundary_flag],r.metric,["rd"])])
    df=len(q)-3
    p=2*student_t.sf(abs(r.partial_rd*np.sqrt(df/(1-r.partial_rd**2))),df)
    same([r.partial_p],[p])
    z=np.arctanh(r.partial_rd);ci=np.tanh(z+np.array([-1,1])*1.96/np.sqrt(len(q)-4))
    same([r.ci_low,r.ci_high],ci)
    leave=[partial(q.drop(index=i),r.metric,["rd"]) for i in q.index]
    same([r.loo_min,r.loo_max],[min(leave),max(leave)])
order=np.argsort(c.partial_p)
adjusted=np.minimum.accumulate((c.partial_p.to_numpy()[order]*len(c)/np.arange(1,len(c)+1))[::-1])[::-1].clip(0,1)
same(c.bh_q.to_numpy()[order],adjusted)
common=read("common_sample_correlations")
for family,rows in common.groupby("family"):
    eligible=d.dropna(subset=rows.metric.tolist())
    for r in rows.itertuples():
        assert set(r.countries.split(";"))==set(eligible.index) and r.n==len(eligible)
        same([r.partial_rd],[partial(eligible,r.metric,["rd"])])
checks["conditional_correlations_and_sensitivities"]=len(c)
checks["common_sample_correlations"]=len(common)
models=read("income_models")
coefs=read("income_model_coefficients")
samples=read("income_model_samples")
for family,rows in models.groupby("family"):
    needed=set(" + ".join(rows.predictors).split(" + "))
    q=d.dropna(subset=list(needed))
    assert set(q.index)==set(samples.loc[samples.family.eq(family),"iso3"])
    for r in rows.itertuples():
        xs=r.predictors.split(" + ")
        result=model(q,xs)
        assert len(q)==r.n
        same([r.r2,r.loo_rmse],[result["r2"],result["rmse"]])
        cs=coefs.loc[coefs.model.eq(r.model)].set_index("term").loc[["const",*xs]]
        for col,key in [("coefficient","beta"),("hc3_se","se"),("ci_low","low"),("ci_high","high")]:
            same(cs[col],result[key])
checks["models_coefficients_HC3_and_PRESS"]=len(models)
baseline_specs={"PPP linear":(d,["rd"],"log_ppp"),"PPP log1p intensity":(d,["log1p_rd"],"log_ppp"),
                "PPP quadratic intensity":(d,["rd","rd_squared"],"log_ppp"),"Nominal linear":(d,["rd"],"log_nominal"),
                "PPP excluding boundary":(d.loc[~d.boundary_flag],["rd"],"log_ppp"),
                "PPP excluding Israel":(d.drop(index="ISR"),["rd"],"log_ppp")}
for r in read("baseline_sensitivity").itertuples():
    q,xs,y=baseline_specs[r.specification]
    result=model(q,xs,y)
    assert r.n==len(q)
    same([r.r2,r.loo_rmse,r.spearman],[result["r2"],result["rmse"],np.corrcoef(q.rd.rank(),q[y].rank())[0,1]])
checks["baseline_sensitivity_models"]=len(baseline_specs)
annual=read("input_rd_income_exports_annual")
for r in read("temporal_cross_sections").itertuples():
    if r.year==2022:
        q=d
    else:
        q=annual.loc[annual.year.eq(r.year)&annual.iso3.isin(d.index)].copy()
        q["rd"]=q.rd_percent_gdp_ons.combine_first(q.rd_percent_gdp_oecd).combine_first(q.rd_percent_gdp_wdi)
        q["log_ppp"]=np.log(q.gdp_per_capita_current_ppp)
        q=q.dropna(subset=["rd","log_ppp"])
    assert len(q)==r.n
    same([r.r2,r.spearman],[model(q,["rd"])["r2"],np.corrcoef(q.rd.rank(),q.log_ppp.rank())[0,1]])
checks["temporal_cross_sections"]=4
timing=read("timing_growth_diagnostics")
for r in timing.itertuples():
    h=inn.loc[inn.metric.eq("rd")&inn.year.eq(r.start)].set_index("iso3").value.rename("rd_start")
    real=sup.loc[sup.metric.eq("real_ppp")].pivot(index="iso3",columns="year",values="value")
    q=real[[r.start,r.end]].join(h).dropna()
    q["log_start"]=np.log(q[r.start]);q["growth"]=100*np.log(q[r.end]/q[r.start])/(r.end-r.start)
    result=model(q,["rd_start","log_start"],"growth")
    assert len(q)==r.n
    same([r.rd_coefficient,r.ci_low,r.ci_high,r.r2],[result["beta"][1],result["low"][1],result["high"][1],result["r2"]])
checks["timing_models_reconstructed"]=len(timing)
summary=json.loads((D/"summary.json").read_text())
same([summary["r2"],summary["median_pair_income_ratio"]],[model(d,["rd"])["r2"],np.median(list(expected.values()))])
assert summary["pairs_ratio_ge2"]==sum(v>=2 for v in expected.values())

text=(ROOT/"Paper.md").read_text(encoding="utf-8")
template=(ROOT/"Paper.template.md").read_text(encoding="utf-8")
assert "{{" not in text and "nan" not in text.lower().split()
tables=[]
for block in re.findall(r"(?:^\|.*\|\s*\n)+",text,re.M):
    rows=[[cell.strip() for cell in line.strip().strip("|").split("|")] for line in block.strip().splitlines()]
    tables.append([rows[0],*rows[2:]])
assert len(tables)==7
# Check numerical table contents against independently verified source/result cells.
cells_checked=0
def rowcheck(actual,expected):
    global cells_checked
    assert actual==expected,(actual,expected)
    cells_checked+=len(expected)
for actual,r in zip(tables[0][1:],selected.loc[selected.selection.eq("largest gap per band")].itertuples()):
    rowcheck(actual[2:],[f"{r.rd_low_income:.3f} / {r.rd_high_income:.3f}",f"{r.ppp_low:,.0f} / {r.ppp_high:,.0f}",f"{r.income_ratio:.2f}×"])
metrics=["gov_effect","internet","hci_2020","log_publications_pm","log_researchers","log_patents_pm","gva_mfg","gva_MHT","gva_KIS","export_MHT","perform_BES","fund_BES","flow_BES_to_HES_recipient"]
ci=c.set_index("metric")
for actual,key in zip(tables[1][1:],metrics):
    r=ci.loc[key];rowcheck(actual[1:],[str(int(r.n)),f"{r.partial_rd:.3f}",f"{r.partial_rank:.3f}","<0.001" if r.bh_q<.001 else f"{r.bh_q:.3f}"])
mi=models.set_index("model")
ids=["capability_0","capability_3","outputs_0","outputs_1","outputs_2","outputs_3","outputs_4","joint_1","joint_3","structure_0","structure_3"]
for actual,key in zip(tables[2][1:],ids):
    r=mi.loc[key];rowcheck(actual[1:],[str(int(r.n)),f"{r.r2:.3f}",f"{r.loo_rmse:.3f}"])
profile=[("rd",".3f"),("ppp",",.0f"),("rd_per_person_ppp_scaled",",.0f"),("researchers",",.0f"),("publications_pm",",.0f"),("patents_pm",",.0f"),("internet",".1f")]+[(v,".2f") for v in ["gva_mfg","gva_MHT","gva_KIS","export_MHT","berd_gva_mfg","perform_BES","fund_BES","fund_ROW","flow_BES_to_HES_recipient","research_ALL_BR","research_ALL_ED","field_ALL_FORD2","gni_gdp"]]
for actual,(metric,spec) in zip(tables[3][1:],profile):
    rowcheck(actual[1:],["—" if pd.isna(d.loc[iso,metric]) else format(d.loc[iso,metric],spec) for iso in ["CHN","ISL","PRT","SGP"]])
for actual,iso in zip(tables[4][1:],["TUR","FIN","USA","JPN","CHN","ISL"]):
    rowcheck(actual[1:],[f"{std.loc[iso,col]:.2f}" for col in ["observed","common_structure","change_pp"]])
for actual,r in zip(tables[6][1:],timing.itertuples()):
    rowcheck(actual,[f"{r.start}–{r.end}",str(r.n),f"{r.rd_coefficient:.3f}",f"[{r.ci_low:.3f}, {r.ci_high:.3f}]"])
claims=read("manuscript_numeric_claims")
frames={"country":d,"corr":ci,"model":mi,"industry":std,"baseline":read("baseline_sensitivity").set_index("specification"),"common":common.set_index(["family","metric"])}
for r in claims.itertuples():
    parts=r.token.split(":")
    if parts[0]=="summary":
        value=summary[parts[1]]
    else:
        key=tuple(parts[1].split("/")) if parts[0]=="common" else parts[1]
        value=frames[parts[0]].loc[key,parts[2]]
    same([value],[r.value]);assert format(value,parts[-1])==str(r.rendered)
    assert "{{"+r.token+"}}" in template and str(r.rendered) in text
checks["numerical_table_cells"]=cells_checked
checks["linked_prose_occurrences"]=len(claims)
doc=Document(ROOT/"Paper.docx")
assert len(doc.tables)==7 and len(doc.inline_shapes)==5
for expected,actual in zip(tables,doc.tables):
    assert expected==[[c.text for c in row.cells] for row in actual.rows]
checks["word_tables_and_figures"]=True
def compact(value):
    return re.sub(r"\s+","",value)
prose=[]
for line in text.splitlines():
    if not line.strip() or line.startswith(("|","![")):
        continue
    line=re.sub(r"^(?:#{1,3}|>) ","",line)
    line=re.sub(r"\*\*(.+?)\*\*",r"\1",line)
    line=re.sub(r"(?<!\w)\*(?!\*)(\S.*?)\*(?!\w)",r"\1",line)
    prose.append(re.sub(r"`([^`]+)`",r"\1",line))
wordtext=compact("\n".join(p.text for p in doc.paragraphs))
for line in prose:
    assert compact(line) in wordtext, f"Word prose missing: {line[:100]}"
checks["word_prose_blocks"]=len(prose)
book=load_workbook(ROOT/"Global_Analysis.xlsx",read_only=True)
assert len(book.sheetnames)==17
workbook_cells=0
csv_paths={p.stem[:31]:p for p in D.glob("*.csv")}
for sheet in book:
    source=pd.read_csv(csv_paths[sheet.title],low_memory=False)
    values=list(sheet.values)
    assert list(values[0])==source.columns.tolist() and len(values)==len(source)+1
    for actual,expected in zip(values[1:],source.itertuples(index=False,name=None)):
        for a,e in zip(actual,expected):
            if pd.isna(e):
                assert a is None
            elif isinstance(e,(float,int,np.number)):
                same([a],[e])
            else:
                assert a==e,(sheet.title,a,e)
            workbook_cells+=1
checks["workbook_sheets"]=len(book.sheetnames)
checks["workbook_cells_against_CSVs"]=workbook_cells
book.close()
pdf=pymupdf.open(ROOT/"Paper.pdf")
pages,thumbs=[],[]
for i,page in enumerate(pdf):
    txt=page.get_text()
    body=txt.replace("GLOBAL R&D AND INCOME  |  EMPIRICAL RESEARCH DRAFT","").strip()
    assert len(body)>40 and "\ufffd" not in txt, f"Empty or malformed page {i+1}"
    for x0,y0,x1,y1,*_ in page.get_text("blocks"):
        assert x0>=0 and y0>=0 and x1<=page.rect.width+.5 and y1<=page.rect.height+.5,(i+1,x0,y0,x1,y1)
    pages.append(dict(page=i+1,width=page.rect.width,height=page.rect.height,words=len(txt.split()),images=len(page.get_images())))
    pix=page.get_pixmap(matrix=pymupdf.Matrix(.55,.55),alpha=False)
    thumb=Image.frombytes("RGB",[pix.width,pix.height],pix.samples);thumb.thumbnail((386,390))
    canvas=Image.new("RGB",(400,420),"#E1E6EA");canvas.paste(thumb,((400-thumb.width)//2,8));ImageDraw.Draw(canvas).text((12,402),f"Page {i+1}",fill="black");thumbs.append(canvas)
montage=Image.new("RGB",(1600,((len(thumbs)+3)//4)*420),"white")
for i,thumb in enumerate(thumbs):
    montage.paste(thumb,((i%4)*400,(i//4)*420))
montage.save(ROOT/"PDF_contact_sheet.jpg",quality=90)
assert sum(p["width"]>p["height"] for p in pages)==5
pdftext="\n".join(page.get_text().replace("GLOBAL R&D AND INCOME  |  EMPIRICAL RESEARCH DRAFT","") for page in pdf)
pdftext=compact(re.sub(r"(?m)^\d+\s*$","",pdftext))
for line in prose:
    assert compact(line) in pdftext, f"PDF prose missing: {line[:100]}"
checks["pdf_prose_blocks"]=len(prose)
checks["pdf_pages"]=len(pdf)
checks["landscape_figure_pages"]=5
checks["pdf_text_inside_page_bounds"]=True
checks["scope"]="Frozen-source joins, units, linked arithmetic, complete pair selection, independent correlations/OLS/HC3/PRESS, timing and manuscript/document checks. Does not re-extract every original official workbook, validate every concordance or identify causal effects. Word structure checked; PDF visually reviewed separately."
pd.DataFrame(pages).to_csv(D/"pdf_page_audit.csv",index=False)
(D/"global_validation.json").write_text(json.dumps(checks,indent=2),encoding="utf-8")
print(json.dumps(checks,indent=2))
