# /// script
# requires-python = ">=3.13"
# dependencies = []
# ///
"""Freeze upstream validation extracts and record their immediate provenance."""
from pathlib import Path
import csv
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
D = ROOT / "Data"
S = ROOT / "Source_notes"
S.mkdir(exist_ok=True)
records = []
for name in ["input_sample_same_year_2022.csv", "input_rd_breakdown_annual.csv",
             "input_rd_sector_field_annual.csv", "input_rd_economy_joined.csv",
             "input_sector_exports.csv", "input_btige_products_2022.csv"]:
    src = ROOT.parent / "Revision/Data" / name
    dst = D / name
    shutil.copyfile(src, dst)
    records.append(dict(source=src.relative_to(ROOT.parent).as_posix(), destination=dst.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(dst.read_bytes()).hexdigest()))
for rel in ["Research_Audit.md", "Data/archive_verification.json", "Data/sector_validation.json",
            "Data/national_validation.json", "Revision/Data/revision_validation.json",
            "Sources/download_manifest.json", "Sources/Comin_download_manifest.json",
            "Sources/supplement_download_manifest.json", "Sources/Prior_Audits/Source_Reading_Notes.md",
            "Sources/Prior_Audits/Source_and_Data_Audit.md"]:
    src = ROOT.parent / rel
    if src.exists():
        dst = S / ("Upstream_" + src.name)
        shutil.copyfile(src, dst)
        records.append(dict(source=rel, destination=dst.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(dst.read_bytes()).hexdigest()))
(S / "extract_provenance.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
inputs = [p for p in D.rglob("*") if p.is_file() and
          ("raw_wb" in p.parts or p.name in ["supplement_annual.csv", "collection_errors.json"] or
           (p.name.startswith("input_") and p.name != "input_manifest.csv"))]
with (D / "input_manifest.csv").open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["path", "bytes", "sha256"])
    writer.writeheader()
    for p in sorted(inputs):
        writer.writerow(dict(path=p.relative_to(ROOT).as_posix(), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
print(f"Frozen {len(inputs)} input files; {len(records)} immediate provenance records.")
