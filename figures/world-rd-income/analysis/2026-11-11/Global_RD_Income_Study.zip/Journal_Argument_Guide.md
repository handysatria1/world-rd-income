# How strong journal papers build this argument

This guide analyses leading economics/innovation papers and the closest topical precedents. Actual versions inspected are listed in `Literature_Review.md`; a working-paper version may differ from the final journal article. The lesson is to borrow the logic of an argument, not imitate causal authority that our design does not have.

## 1. Six particularly useful models

### Hall and Jones: distinguish the puzzle, accounting and deeper determinants

**Opening:** establish a large, economically meaningful output-per-worker difference. **Framework:** partition it into physical capital, human capital and productivity. **Deeper argument:** ask why those proximate components differ, then study social infrastructure. **Identification:** confront reverse causality using proposed instruments. **Contribution:** explain which part is accounting and which is an empirical claim about deeper determinants.

**Application here:** start with the global distribution of income at comparable GERD/GDP. Define GDP per person, GERD/GDP and BERD/GVA before discussing mechanisms. Place the industry identity in a separate subsection from the conditional-income regressions. Do not interpret the unexplained residual as commercialisation failure.

### Griffith, Redding and Van Reenen: make mechanisms yield different observable predictions

**Opening:** R&D can innovate and help absorb frontier technology. **Framework:** separate direct R&D and R&D × frontier-gap terms. **Measurement:** construct comparable industry productivity and research measures. **Results:** the interaction tests a specific channel; skills and trade provide alternative explanations. **Contribution:** an observable distinction between two roles of R&D.

**Application here:** formulate mechanism-specific implications before looking at case names. Capabilities predict income variation conditional on spending; industrial composition predicts changes in intensity after standardisation; value-capture/production-boundary mechanisms predict differences between GDP and resident-income measures. Our data do not identify the causal interaction between R&D and absorptive capacity, so that remains a hypothesis supported indirectly.

### Bloom et al. (2020): use one transparent organising equation repeatedly

**Opening:** increasing research effort coexists with less impressive growth. **Framework:** growth is related to effort and research productivity. **Evidence:** repeat the logic across semiconductors, agriculture, health and firms, while discussing comparable effort and output. **Contribution:** triangulate a broad pattern rather than letting one graph carry the claim.

**Application here:** use the chain “resources → research capacity and knowledge → adoption/value added → income”. Different indicators test different links. Repeat comparisons across all economies and transparent subsets. Avoid a scalar “innovation efficiency” score assembled from incompatible counts.

### Comin and Mestieri: split an apparently single concept into distinct margins

**Opening:** technology arrives faster everywhere, yet incomes diverge. **Framework:** adoption timing differs from intensity of use. **Estimation:** fit diffusion curves with separate shifts and connect them to a growth model. **Contribution:** resolve an apparent contradiction by improving the measurement of the mechanism.

**Application here:** equal GERD/GDP is not equal research resources per resident, and invention is not diffusion. Researcher density, digital use and papers capture different margins. A higher-income country can spend the same GDP share and still commit several times the resources per person. That arithmetic is an interpretation aid, not an independent causal regressor.

### Bloom et al. (management) and Moretti et al.: define a treatment and a counterfactual

**Management paper:** an explicit consulting intervention, random assignment among participants, measured changes in practices and production, then mechanisms and constraints on adoption. **Defense-R&D paper:** plausibly external shifts in public funding, differential industry exposure, private-research responses, productivity and spillovers. Both connect input changes to outcomes using a defined source of variation.

**Application here:** explain why an intermediary section needs programme evaluation, not just a national funding share. For a future causal paper, specify eligibility, treatment timing, untreated firms, spillovers, exclusion restrictions and outcomes before estimating effects. The current global paper can establish patterns and compare institutional mechanisms without presenting its OLS as an intervention effect.

### Coad and Vezzani: test each policy claim separately and retain inconvenient results

**Opening:** manufacturing is claimed to support research, exports and productivity. **Design:** use separate outcomes rather than assuming the three move together. **Results:** support is clearer for R&D than for the other outcomes; problematic dynamic-panel diagnostics are acknowledged. **Contribution:** identify which parts of a popular policy narrative survive scrutiny.

**Application here:** distinguish “business performance share predicts GERD/GDP” from “business performance share predicts income at a given GERD/GDP”. Report that funding/industrial models worsen held-out prediction on the common sample. Do not bury this result because industrial structure was an initial preferred explanation.

## 2. Recommended paper architecture, implemented in Paper.md

| Section | Question it must answer | Evidence that earns the claim |
|---|---|---|
| Introduction | What precisely is puzzling, and why should readers care? | Positive global association plus substantial conditional dispersion; short result preview |
| Framework and literature | Which mechanisms could generate that dispersion? | Closest precedents; distinct input, output, adoption, production and income concepts |
| Data and design | What population, period and estimand are being studied? | 83 matched economies; missingness; equal weights; descriptive conditional associations |
| Global patterns | Is the puzzle broad or selected from anecdotes? | All eligible near-intensity pairs, distribution and explicit extreme-case rule |
| Capabilities and outputs | Which measured correlates survive controls and common samples? | Partial/rank correlations, 36-test adjustment, fixed-sample models and held-out errors |
| Structure and income boundaries | What does aggregate intensity conceal? | Industry identity, 19-economy standardisation, GVA/export profiles, rents and GNI/GDP |
| Funding, focus and intermediaries | What do organisational data establish? | Funding/performer cubes; weak associations; documented functions and evaluation evidence |
| Robustness and timing | What alternative interpretations remain? | Nonlinear controls, population sensitivity, boundary exclusions, years and real-growth windows |
| Discussion and conclusion | What follows, and what evidence would change the answer? | Mechanism-specific policy questions and a credible future identification design |

## 3. Introduction: a five-paragraph blueprint

**Paragraph 1 — economic puzzle.** R&D supports innovation, but national intensity is not a sufficient statistic for prosperity. Introduce the 83-economy matched-year pattern and conditional dispersion. Country names come after the global fact.

**Paragraph 2 — conceptual distinction.** Separate causal benefits from the deterministic ranking proposition. Explain why equal GDP shares are unequal resources per person and why income levels reflect more than current invention.

**Paragraph 3 — closest literature.** Position against Goñi–Maloney, Coad–Vezzani and the innovation/adoption literature. State the gap as a harmonised, multi-stage descriptive assessment, not an unqualified first discovery.

**Paragraph 4 — design and headline findings.** Define the dependent variable, sample year, indicator families and validation. State both the strong capability/output associations and the weak common-sample funding/structure results.

**Paragraph 5 — contribution and scope.** Explain how transparent case selection and linked accounting improve interpretation. State that the analysis cannot allocate percentages of an income gap to causal mechanisms.

## 4. How individual results paragraphs should work

Use **claim → estimate → comparison/robustness → mechanism → boundary of inference**.

Example: “Research capacity differs substantially among economies with similar R&D shares. On the 70-economy common sample, researcher density has an R&D-adjusted correlation of .612 with income, compared with .258 for resident patent applications. Publications provide a stronger descriptive signal and improve held-out prediction more. These patterns are consistent with differences in accumulated capability and scientific systems, but also with richer economies financing larger systems. They do not measure the causal return to an additional researcher or patent.”

Avoid converting that into “researchers explain 61.2% of income”: a correlation is not a contribution percentage. Likewise, an increase in R² is not a causal share of national income.

## 5. What would make a stronger next-stage journal contribution?

**A longitudinal mechanism test:** comparable research stocks and scientific/patent quality, pre-period capabilities, within-industry productivity, and foreign-knowledge exposure. Specify whether the target is an effect on productivity levels or growth, and whether the effect is local or social.

**An intermediary evaluation:** linked firm-level contracts/eligibility, pre-treatment trends, employee movements, project functions, adoption, productivity and value-added exports. A credible discontinuity, phased rollout or randomised offer would be more informative than country funding shares.

**A production-network/value-capture test:** domestic value added embodied in exports, ownership of intellectual property, inward/outward income flows and service trade. This would distinguish domestic scientific production from domestic income capture.

**A disciplined scope:** the present paper is an evidence-led comparative study suitable for development into an innovation-policy or structural-change article. Journal ambition should be matched to the design and contribution. Adding more regressors or a more elaborate title does not supply causal identification.
