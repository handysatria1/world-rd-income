# Similar R&D intensity, different prosperity: global patterns, capabilities and economic structure

**A matched-year study of 83 economies, with data-selected comparisons and a critical evidence review**

Research draft | 11 November 2026 | Main reference year: 2022

## Abstract

Research and development supports technological progress, yet a national R&D spending share is an incomplete guide to prosperity. This paper examines why economies with similar gross domestic expenditure on R&D relative to GDP have different GDP per capita. Using a frozen, harmonised 2022 sample of 83 economies, we find a positive rank association of 0.701, alongside substantial dispersion: 120 economy pairs satisfy both absolute and relative R&D-intensity calipers, and 47 have at least a twofold income difference. We select examples by an explicit rule rather than beginning with a preferred country. Three explanatory domains receive different forms of support. First, human capital, digital access, institutional capability and scientific capacity are strongly associated with income conditional on R&D; their signals overlap. Second, sector composition changes the meaning of aggregate intensity: common manufacturing weights materially alter BERD/GVA benchmarks, although broad industrial and funding shares provide weak additional income prediction. Third, resource income and the distinction between domestic production and resident income help interpret several extreme contrasts. Research outputs, technology diffusion, complementary assets and intermediary organisation connect these findings to the literature. Current national funding shares do not identify intermediary effectiveness, and the analysis does not causally apportion income gaps. The evidence supports a conditional account of the benefits of research rather than either a deterministic spending–income ranking or the conclusion that research is economically unproductive.

**Keywords:** R&D intensity; GDP per capita; absorptive capacity; industrial structure; innovation intermediaries; research funding; technology diffusion.

## 1. Introduction

Why can economies devote similar shares of GDP to research and development yet have markedly different income levels? The question matters because policy discussions often use a national spending target as a shorthand for innovation ambition and future prosperity. A global comparison supports part of that intuition: economies with higher research intensity are generally richer. It also exposes its limits. In the matched 2022 sample examined here, a linear regression of log PPP GDP per capita on R&D intensity has an R² of 0.285. Among pairs meeting a deliberately narrow definition of comparable intensity, the median higher-to-lower income ratio is 1.57. Understanding the dispersion requires more than identifying exceptions to an upward-sloping relationship.

The proposition that more R&D can raise productivity is different from the proposition that countries can be ranked by income using their current R&D shares alone. Research expenditure is an annual flow; income reflects accumulated capital, skills, production organisation, access to external knowledge, natural resources and past innovation. Equal shares also represent unequal research resources per resident when income differs. A cross-sectional spending ratio therefore neither identifies a causal return to research nor measures the whole innovation system.

This question has important precedents. Goñi and Maloney [1] examine why poorer countries do relatively little R&D and relate heterogeneous estimated returns to missing complements. Coad and Vezzani [2] test manufacturing's links to research, exports and productivity separately, finding stronger support for some propositions than others. Huang, Arundel and Hollanders [3] show why innovation cannot be reduced to in-house R&D. The contribution here is an integrated, auditable comparison connecting national income to research personnel and outputs, funding–performer structure, research focus, industrial GVA, within-industry BERD/GVA and goods exports. It is a descriptive comparative contribution, rather than a claim to discover the puzzle for the first time.

Our design makes income the outcome, selects country examples from the global data, and compares models on fixed samples. Capability measures and scientific publications provide strong conditional signals. Patent applications are less informative, and industrial/funding models perform poorly in held-out prediction. Meanwhile, accounting standardisation shows why the same aggregate intensity can describe different productive structures. Resource-rich economies and financial or multinational-production centres appear among the largest near-intensity gaps, making the income concept itself important.

The paper consequently develops three principal explanations with explicit evidence boundaries: differences in capabilities and knowledge use; differences in the sectoral composition of research and production; and differences in income sources and production–residency boundaries. Scientific outputs, intermediary organisation, knowledge stocks and value capture refine these explanations. They are not estimated as independent, additive causal contributions.

## 2. Framework and related evidence

### 2.1 From spending to knowledge, adoption and income

A useful organising sequence is research resources → research capacity and knowledge → adoption and commercial use → value added → income. Each step contains additional inputs and possible leakages. R&D can generate inventions, train people and improve an organisation's ability to use external ideas. Cohen and Levinthal [4] formalise that absorptive-capacity mechanism; Griffith, Redding and Van Reenen [5] distinguish direct innovation from research-assisted catch-up in an OECD-industry panel. Cirera and Maloney [6] emphasise the production, managerial and institutional capabilities needed to use innovation policy effectively.

The distinction between invention and diffusion is especially important for a global comparison. Comin and Mestieri [7] separate the arrival of technology from its intensity of use. Access can converge without use converging. Management is another complement: Bloom et al.'s experiment in participating Indian textile firms [8] shows that changing production practices can improve performance. These studies establish mechanisms at different levels and under different identification assumptions. They do not imply that a broad national governance coefficient is a causal measure of firm management or technology adoption.

Research outputs are also heterogeneous. Scientific articles measure one aspect of knowledge production; resident patent applications reflect a particular appropriation route and legal reporting system. Neither directly measures commercial value. Some innovations are unpatented, and article and application counts differ in coverage, quality, costs and lags. We therefore examine them separately and avoid interpreting output divided by contemporaneous expenditure as innovation efficiency.

### 2.2 Production structure and the income concept

GDP per person combines labour productivity with employment and demographic composition. It is not total factor productivity, household disposable income or a welfare index. Hall and Jones [9] distinguish proximate production-accounting components from deeper institutional explanations. Hsieh and Klenow [10] show, within a structural model, how allocation across plants can change aggregate productivity even with given plant technologies. Syverson [11] details further roles for management, input quality, competition and measurement. These mechanisms provide additional reasons for income differences, although our aggregate indicators cannot identify their individual contributions.

For a complete industry partition, aggregate business R&D relative to value added is a weighted average:

> BERD / GVA = Σⱼ (GVAⱼ / GVA) × (BERDⱼ / GVAⱼ).

An economy can thus have a high aggregate business intensity because it specialises in research-intensive industries, because its firms spend more within those industries, or both. Mathieu and van Pottelsberghe [12] motivate comparing intensity at a common industrial structure. GERD/GDP adds further distinctions: GERD includes research performed outside business, and GDP differs from basic-price GVA by net taxes on products. We keep the denominators separate throughout.

Finally, creating knowledge and capturing its income need not occur in the same firm or country. Teece [13] identifies appropriability and complementary assets as central to returns from innovation. Srholec [14] shows why gross high-tech exports can reflect fragmented production and imported components. Royalties, ownership, cross-border production and income flows therefore matter alongside domestic scientific output. These are reasons to improve measurement, not to infer a country's value capture from a single export share.

### 2.3 Intermediaries and the timing of benefits

Howells [15] describes intermediation as a set of functions extending beyond introductions: diagnosis, search, knowledge combination, testing, validation, intellectual-property assistance and commercialisation. Research organisations may supply laboratories, contract research, demonstrators or embedded personnel. Comin et al.'s Fraunhofer evaluation [16] connects contracts to subsequent firm outcomes under a generated-instrument identification strategy. This is more informative about a mechanism than a national university-funding share, although it does not compare national intermediary systems experimentally.

Annual research effort also differs from accumulated knowledge. Bloom et al. [17] examine increasing effort and declining measured research productivity across multiple settings; Ugur et al.'s meta-analysis [18] documents positive but heterogeneous average R&D estimates and important measurement and identification problems. Moretti, Steinwender and Van Reenen [19] use defense-related funding variation to investigate additional private research and productivity. Together with the measurement framework in Hall, Mairesse and Mohnen [24], this literature cautions against interpreting a contemporaneous country scatter as either a social return estimate or a verdict against research.

## 3. Data and empirical design

### 3.1 Coverage, sources and comparability

The main universe is the 83 economies with harmonised same-year R&D intensity and PPP income in 2022 in the frozen Worldwide R&D and income explorer [23]. Each economy receives equal weight; overlapping aggregates and the Basque regional comparator are excluded. This is a broad international sample, not a census or a random sample of all countries. Availability of comparable R&D statistics favours better-documented economies. We use “income” as shorthand for GDP per capita while retaining its production-based meaning.

National GDP and R&D values, research outputs and linked industrial/funding inputs retain the archive's vintage and provider-selection rules. Supplementary World Bank histories were retrieved on 11 November 2026. The analysis records both vintages rather than silently refreshing the core. Population-normalised output counts use the supplementary population series; GDP per capita is retained from the frozen core. Main associations use 2022 values except the explicitly labelled Human Capital Index for 2020 and resource rents selected as the latest available observation in 2020–2022. Rent observations are from 2021 for 80 economies and from 2020 for Kuwait and Syria; Turkmenistan has no eligible observation. Prior researcher observations are retained separately and are not substituted into the principal same-year researcher analysis.

GERD is gross domestic expenditure on R&D; BERD is expenditure performed in the business-enterprise sector, regardless of who funds it. Funding shares identify the source of money; performer shares identify where work is carried out. Funding × performer, research type × performer and field × performer are separate statistical cubes. They cannot identify funding source × research type. Basic-research and development percentages use the research cube's reported total, including any separately reported capital/unclassified categories; field shares use the field total. Flagged unrevised/nonadditive shares are excluded under the inherited rules, and missing values remain missing.

Industrial GVA shares use the complete A–T partition in the linked accounts. The custom medium/high-technology manufacturing group (MHT) comprises ISIC 20, 21 and 26–30. The custom knowledge-intensive-services group (KIS) comprises J, K, M and P; it is not a claim to cover every knowledge-intensive activity or an interchangeable official Eurostat definition. Manufacturing BERD/GVA is calculated only with complete assigned manufacturing coverage. Gross goods-export shares use the corresponding product grouping and a goods denominator; they exclude services and are not domestic value-added export shares.

### 3.2 Comparable-intensity pairs and conditional associations

Two economies form an eligible pair when the absolute GERD/GDP difference is no more than 0.15 percentage points and the symmetric relative difference is no more than 10%. The latter equals twice the absolute difference divided by the sum of the two intensities. Requiring both prevents a small absolute gap at very low intensity from representing a large relative disparity. Pairs are grouped by their mean intensity into bands below 0.5%, 0.5–<1.5%, 1.5–<2.5% and at least 2.5%. Within each band, the largest PPP income ratio supplies an illustrative contrast. These are deliberately selected extremes; the complete pair distribution is also reported. Pairs share economies and are not independent observations or matched causal treatment–control units.

The principal outcome is natural-log PPP GDP per capita. We estimate a baseline with linear GERD/GDP and report residual correlations between income and each additional indicator after removing the same intensity control from both. Researcher, article and patent densities enter as log(1 + density). Sensitivities use nonlinear intensity controls, ranks, nominal income, log population and specified boundary exclusions. The exclusion rule flags Ireland, Luxembourg and economies with available resource rents of at least 10% of GDP; it does not identify all unusual economies.

For 36 exploratory primary correlations, we report Benjamini–Hochberg adjusted q-values, descriptive uncertainty intervals and leave-one-economy-out ranges. Nonrandom sampling, interdependence between economies, measurement uncertainty and data-guided specification limit inferential interpretation. For multiple regression, each family uses the same complete-case sample across its specifications. HC3 intervals describe coefficient uncertainty, and explicit leave-one-economy-out refits assess predictive error in log-income units. These internal checks are not a new-country external validation or evidence of causal mediation; model families were not preregistered.

## 4. The global pattern and data-selected examples

The overall relationship is positive. Spearman's rank correlation is 0.701, and the linear log-income model explains 0.285 of observed log-income variation. A log(1 + intensity) specification raises R² to 0.390, and a quadratic raises it to 0.414. Thus the exact proportion is sensitive to functional form, but substantial dispersion remains. R² is a descriptive fit statistic, not the fraction of national income caused by research.

![Global research intensity and income](Figures/01_global_scatter.png)
*Figure 1. All 83 matched economies in 2022. Income uses a logarithmic scale; point colour records internet use, with grey points retaining economies lacking that indicator. The fitted line is a linear relationship in log income. Selected labels follow the pair-selection rule, with Japan and the United States added for the population sensitivity.*

There are 120 eligible near-intensity pairs, with median income ratio 1.57; 47 ratios are at least two. Table 1 identifies the largest gap in each band. The high-band example is China–Iceland: their mean intensity lies above 2.5%, although China's own value is slightly below that threshold. This illustrates why the band definition matters.

**Table 1. Largest income gap within each mean-intensity band**

| Mean-intensity band | Data-selected pair | GERD/GDP (%) | PPP income ($) | Income ratio |
| --- | --- | --- | --- | --- |
| <0.5% | Kenya / Saudi Arabia | 0.407 / 0.414 | 5,882 / 71,957 | 12.23× |
| 0.5–<1.5% | Egypt, Arab Rep. / Luxembourg | 1.020 / 1.065 | 17,524 / 146,919 | 8.38× |
| 1.5–<2.5% | Greece / Ireland | 1.483 / 1.533 | 39,448 / 138,465 | 3.51× |
| 2.5%+ | China / Iceland | 2.495 / 2.558 | 23,028 / 76,592 | 3.33× |

*Notes: Both calipers must hold. Income is current international dollars at PPP, not nominal US dollars. Values are rounded only for presentation. Selected extremes should not be interpreted as typical effects.*

The first three contrasts make resource income and production boundaries immediately relevant. Removing the specified boundary cases changes the selected pairs to Kenya–Macao, Namibia–Cyprus, Portugal–Singapore and China–Iceland. Also requiring at least one million residents changes them to Kenya–North Macedonia, Namibia–Cyprus, Portugal–Singapore and Japan–United States. This sensitivity prevents a small-economy contrast from being the sole basis for the argument. It also demonstrates that the boundary rule is incomplete: Macao and Singapore remain economically distinctive. Every eligible pair and all selection variants are retained in the workbook.

![Selected extremes and complete pair distribution](Figures/03_selected_pairs.png)
*Figure 2. Selected contrasts alongside the distribution of all eligible pairs. Pair counts are descriptive because the same economy can occur repeatedly. The long right tail motivates reporting both the median and deliberately selected extreme cases.*

## 5. Explanation I: capabilities, research capacity and knowledge use

### 5.1 The strongest measured signals

At a given linear R&D intensity, government effectiveness, internet access, human capital, scientific publications and researcher density are strongly associated with income. Table 2 presents the principal comparisons and contrasts them with weaker industrial and funding measures. The broad pattern is consistent with complementary capabilities: research is more useful when workers and firms can absorb knowledge, organise production, implement projects and diffuse technology. It is also consistent with reverse causality, since richer societies can finance these capabilities.

**Table 2. Associations with log PPP income after controlling for R&D intensity**

| Indicator | n | Partial r | Rank partial r | BH q |
| --- | --- | --- | --- | --- |
| Government effectiveness | 83 | 0.835 | 0.770 | <0.001 |
| Internet users | 80 | 0.736 | 0.774 | <0.001 |
| Human capital (2020) | 80 | 0.688 | 0.551 | <0.001 |
| Articles/million (log1p) | 81 | 0.760 | 0.718 | <0.001 |
| Researchers/million (log1p) | 76 | 0.658 | 0.599 | <0.001 |
| Resident patents/million (log1p) | 77 | 0.345 | 0.277 | 0.006 |
| Manufacturing GVA share | 55 | -0.166 | -0.332 | 0.361 |
| MHT GVA share | 55 | 0.157 | -0.219 | 0.368 |
| Custom KIS GVA share | 55 | 0.516 | 0.439 | <0.001 |
| MHT goods export share | 79 | 0.353 | 0.175 | 0.004 |
| Business performer share | 40 | 0.301 | -0.092 | 0.126 |
| Business funding share | 34 | 0.209 | 0.106 | 0.366 |
| Business funding / university R&D | 35 | -0.271 | -0.133 | 0.219 |

*Notes: Partial r controls linear intensity; rank partial r residualises ranked indicators and ranked income on ranked intensity. q adjusts the 36 primary tests, not just the rows shown. Most indicators are 2022; HCI is 2020. Different row samples should not be interpreted as a clean ranking of predictor quality.*

On the same 79 economies, adding internet use, HCI and government effectiveness increases R² from 0.286 to 0.841 and reduces held-out RMSE from 0.615 to 0.303. The point is not that these variables causally explain that fraction of income. It is that the research share leaves out powerful correlates of economic development. WGI measures are perception-based, HCI concerns expected human capital rather than the skills of today's entire workforce, and internet use measures connectivity rather than firms' actual adoption of frontier production techniques.

![Conditional income associations](Figures/02_conditional_correlations.png)
*Figure 3. Conditional associations under linear and log-transformed intensity controls. Intervals are descriptive Fisher-transformation intervals, not simultaneous causal confidence statements. Indicator coverage varies, so the common-sample checks in Table 3 are essential.*

### 5.2 Research outputs provide different, overlapping information

On the common 70-economy research-indicator sample, the conditional correlation is 0.777 for scientific articles, 0.612 for researchers and 0.258 for resident patent applications. All are population-normalised and log-transformed. The publication model lowers held-out RMSE from 0.584 to 0.379. Adding all three indicators yields 0.397, illustrating that more regressors need not improve prediction.

Capabilities and publications are not separate causal quantities that can be added together. On 77 common economies, adding publications to the capability model changes held-out RMSE from 0.307 to 0.296. Much of the information is shared. Publications can reflect universities, scientific specialisation, international collaboration and accumulated prosperity; researcher density is an input rather than a research output in the strict sense. The analysis treats these as related indicators of a research system, not a single conversion-efficiency index.

**Table 3. Fixed-sample model comparisons**

| Model (compare within sample) | n | R² | Held-out RMSE |
| --- | --- | --- | --- |
| Capabilities: R&D only | 79 | 0.286 | 0.615 |
| R&D + internet + HCI + governance | 79 | 0.841 | 0.303 |
| Research indicators: R&D only | 70 | 0.352 | 0.584 |
| R&D + researchers | 70 | 0.595 | 0.486 |
| R&D + articles | 70 | 0.744 | 0.379 |
| R&D + resident patents | 70 | 0.395 | 0.577 |
| R&D + all three research indicators | 70 | 0.746 | 0.397 |
| Joint sample: R&D + capabilities | 77 | 0.838 | 0.307 |
| R&D + capabilities + articles | 77 | 0.859 | 0.296 |
| Structure/funding: R&D only | 34 | 0.139 | 0.435 |
| R&D + structure + funding | 34 | 0.258 | 0.549 |

*Notes: Outcome: natural-log PPP GDP per capita. RMSE uses explicit leave-one-economy-out refits. Capability models use internet, HCI and government effectiveness; structure/funding models use MHT and KIS GVA shares, MHT export share, business performer share and business funding share. Compare improvements within each family, not RMSE levels across different samples. All models include an intercept.*

### 5.3 China–Iceland and Portugal–Singapore

Table 4 integrates research, production and funding evidence for two rule-selected contrasts. China and Iceland have close GERD/GDP ratios but PPP incomes of $23,028 and $76,592. Iceland has substantially higher researcher and article densities. China has many more resident patent applications per million. Patent volume therefore does not order this pair's income, and calling the difference “patent efficiency” would require information on quality, fields, legal practices and the subsequent use of inventions.

**Table 4. Linked profiles for two data-selected contrasts**

| Measure (2022 unless specified) | China | Iceland | Portugal | Singapore |
| --- | --- | --- | --- | --- |
| GERD / GDP (%) | 2.495 | 2.558 | 1.691 | 1.808 |
| PPP GDP per person ($) | 23,028 | 76,592 | 45,250 | 144,418 |
| PPP-scaled R&D per person ($) | 574 | 1,959 | 765 | 2,611 |
| Researchers per million | 1,849 | 6,864 | 5,687 | 8,782 |
| Scientific articles per million | 627 | 1,955 | 1,745 | 2,200 |
| Resident applications per million | 1,037 | 97 | 67 | 303 |
| Internet users (%) | 75.6 | 97.6 | 84.5 | 96.0 |
| Manufacturing / GVA (%) | 28.87 | 12.58 | 14.93 | 20.64 |
| MHT / GVA (%) | 11.38 | 1.33 | 3.48 | 17.21 |
| Custom KIS / GVA (%) | 16.05 | 20.48 | 20.06 | 25.79 |
| MHT / goods exports (%) | 58.75 | 6.20 | 37.73 | 67.26 |
| Manufacturing BERD/GVA (%) | 5.56 | 4.26 | — | — |
| Business performer / GERD (%) | 77.57 | 72.30 | 62.23 | 64.16 |
| Business funding / GERD (%) | 79.02 | 52.48 | 56.56 | 59.19 |
| Foreign funding / GERD (%) | 0.17 | 17.67 | 6.14 | 5.30 |
| Business funding / university R&D (%) | 32.32 | 2.04 | 1.95 | 6.76 |
| Basic research / research total (%) | 6.57 | 16.66 | 16.86 | 23.61 |
| Development / research total (%) | 82.11 | 49.93 | 44.57 | 46.58 |
| Engineering / field total (%) | — | — | 49.83 | 62.79 |
| GNI / GDP (%) | 99.16 | 98.82 | 98.19 | 80.63 |

*Notes: “—” denotes unavailable/comparability-excluded data. PPP-scaled R&D per person equals GERD/GDP × PPP GDP per person / 100 and is an arithmetic approximation using economy-wide PPP, not an R&D-specific cost comparison. Research type and field have separate source totals. Gross exports and GVA shares have different denominators. Singapore's detailed 2022 industry BERD is unavailable; Portugal also lacks complete manufacturing BERD coverage for this calculation.*

Equal shares do not imply equal resources per resident. The implied PPP-scaled R&D amounts are $574 in China and $1,959 in Iceland. These values are useful arithmetic, but cannot be used as an independent explanation in the income regression because income is part of their construction. Research personnel and output densities offer additional, though still endogenous, information about scale and accumulated capacity.

Portugal–Singapore remains selected after the boundary and population restrictions. Their business performer shares are 62.23% and 64.16%, and business funding shares are 56.56% and 59.19%. Similar financial structure coexists with very different income. Singapore has higher researcher density and a different industrial/export profile, while its GNI/GDP ratio is lower. These combined observations justify a multi-mechanism investigation. They do not identify a single national institution as the cause of the gap.

## 6. Explanation II: sector composition changes what intensity measures

### 6.1 A supported accounting explanation

The manufacturing calculation holds each economy's within-group BERD/GVA fixed and replaces its manufacturing GVA weights with the unweighted mean of the weights across the 19 complete economies. Five mutually exclusive manufacturing groups are used. Both observed and standardised ratios are relative to manufacturing GVA, rather than total-economy GVA or GDP. This accounting exercise isolates how the benchmark changes with composition; it does not model the effects of shifting workers, investment or markets between industries.

**Table 5. Selected manufacturing benchmarks under common industry weights**

| Economy | Observed (%) | Common mix (%) | Change (pp) |
| --- | --- | --- | --- |
| Turkiye | 2.67 | 6.15 | 3.48 |
| Finland | 7.18 | 5.87 | -1.31 |
| United States | 13.20 | 10.60 | -2.60 |
| Japan | 10.56 | 9.96 | -0.59 |
| China | 5.56 | 5.35 | -0.21 |
| Iceland | 4.26 | 4.37 | 0.10 |

*Notes: The full 19-economy calculation is shown in Figure 5 and the workbook. Common weights sum to one within manufacturing. Changes are percentage points of manufacturing BERD/GVA. These examples illustrate different directions and sizes of adjustment, rather than a causal ranking of industrial policies.*

Türkiye's benchmark rises from 2.67% to 6.15%, whereas Finland's falls from 7.18% to 5.87%. The United States falls from 13.20% to 10.60%. These movements establish that aggregate intensity can conceal substantial differences in sector mix. Standardisation is therefore valuable before judging whether an economy is unusually research-intensive relative to peers.

### 6.2 Why composition is not a universal income explanation

The income results are less supportive of a simple manufacturing explanation. Manufacturing's GVA share has conditional r = -0.166, while MHT GVA has r = 0.157 and changes sign in the rank-based check. KIS GVA is positively associated in the 55-economy sample, but its correlation falls to 0.036 on the 33-economy common funding/structure sample. Coverage and economic heterogeneity substantially alter the comparison.

The fixed 34-economy structure/funding model raises in-sample R² from 0.139 to 0.258, but worsens held-out RMSE from 0.435 to 0.549. That adverse result should constrain the narrative. Sector composition demonstrably matters for interpreting the spending benchmark; the available broad shares do not establish that it is the main statistical explanation of conditional income gaps.

![Fixed-sample predictive comparisons](Figures/04_model_validation.png)
*Figure 4. Held-out error for the capability, research-indicator and structure/funding families. The bars compare specifications on an unchanged sample within each family. Lower values are better; adding structure and funding variables worsens prediction in their smaller sample.*

![Manufacturing standardisation](Figures/05_industry_standardisation.png)
*Figure 5. All 19 complete economies under observed and common manufacturing GVA weights. The exercise changes weights while holding within-group intensities fixed; it is an accounting counterfactual, not an estimate of the income consequences of industrial restructuring.*

Research focus adds further texture. China reports a much larger experimental-development share than Iceland, whereas Portugal and Singapore have closer development shares but different basic-research and engineering shares. Across the available countries, however, basic research, development and engineering shares do not provide strong conditional income correlations. Their small, selected samples also preclude a general claim that one research mix is optimal. Differences in industry demand and missions can rationally generate different portfolios.

## 7. Explanation III: income sources, value capture and production boundaries

The largest pairwise gaps are informative because they challenge the assumption that present domestic R&D is the principal source of all measured income. Kenya and Saudi Arabia have almost identical intensities, while their available 2021 resource rents are 1.23% and 25.57% of GDP. Natural-resource income offers a concrete alternative mechanism for this contrast. It is not a quantified decomposition of the pair's income difference, nor does it mean that resource abundance reliably creates high income: the global conditional rent correlation is -0.117.

GDP and income accruing to residents can also differ. In 2022, GNI/GDP is 68.35% in Ireland, 64.71% in Luxembourg and 80.63% in Singapore. These ratios directly document a production–residency distinction relevant to three prominent high-GDP examples. They do not identify how much is due to any single channel, such as multinational profits, cross-border labour or financial activity. GNI is not household disposable income, and this paper does not construct a cross-country welfare correction or a profit-shifting estimate.

Value capture also operates within production networks. MHT goods constitute 67.26% of Singapore's goods exports compared with 37.73% in Portugal; the corresponding GVA shares are 17.21% and 3.48%. These are different objects. Gross exports can contain substantial imported inputs and omit knowledge-intensive service exports. Srholec's evidence [14] cautions against treating them as domestic technological content. Our positive conditional association between MHT export share and income is correspondingly weaker under rank adjustment. It supports investigating international production and specialisation, not a direct conversion from export composition to domestic research returns.

Two other global correlates warrant attention. Trade relative to GDP has conditional r = 0.540, while agriculture's GDP share has r = -0.706. These are consistent with openness and structural transformation, but also reflect economy size, development level and denominator effects. Neither is an experimentally identified policy lever. Fixed investment and private credit show much weaker conditional associations in this sample; a one-year investment flow is not the accumulated capital stock, and aggregate credit is not a measure of efficient allocation across firms. The allocation mechanism in Hsieh and Klenow [10] consequently remains a literature-supported explanation requiring more granular data.

## 8. Funding and intermediary organisation: a mechanism to evaluate

Funding composition is sometimes treated as a shorthand for commercial orientation or successful translation. The global data do not support that shortcut. Business performance and business funding shares have modest conditional correlations, with q-values above conventional significance thresholds. The share of university research funded by business is negatively correlated with income after the stated control, but its adjusted q-value is 0.219. This is not evidence that collaboration reduces prosperity; it demonstrates that a financial-flow proxy is inadequate for ranking intermediary quality.

The case profiles make this concrete. China's business-funded share of university R&D is 32.32%, compared with 2.04% in Iceland. Singapore's share exceeds Portugal's. A single monotonic interpretation therefore fails across even these transparently selected comparisons. Payments can fund different activities, involve different institutions and reflect different public-finance arrangements. The funding cube contains no project-level information on technical difficulty, additionality, uptake or productivity.

**Table 6. Organisational mechanisms in three intermediary systems**

| System | Organisation and financing | Mechanism relevant to firms | Evidence available here |
|---|---|---|---|
| Fraunhofer, Germany | Research institutes; institutional base funding plus competitive public and private contracts | Applied research capacity, contract projects and technical problem-solving | Official financing description; firm evaluation using generated instruments |
| Catapults, United Kingdom | Independent centres; core public support, collaborative R&D and commercial income | Shared facilities, demonstrators, testing and collaboration | Official governance/funding review; no common causal national effect established |
| A*STAR, Singapore | Public research agency with business programmes and researcher secondments | Technology roadmaps, adoption assistance and expertise embedded in firms | Official programme descriptions; no comparable causal estimate established |

*Notes: Current Fraunhofer and A*STAR webpages were accessed in 2026; Catapult discussion principally uses the 2021 review. These are documented organisational comparisons, not exact reconstructions of all 2022 arrangements or a ranking of national effectiveness.*

Fraunhofer's financing description [20] combines stable institutional capacity with contract demand. Its “at least two-thirds” competitive-income statement includes both public and private contracts; it does not mean two-thirds exclusively from industry. The Catapult review [21] discusses the core/collaborative/commercial funding model and governance arrangements, while recognising variation and evaluation challenges. A*STAR's GET-Up/T-Up descriptions [22] highlight a different mechanism: personnel and expertise can be placed inside firms rather than only exchanged through external projects.

The Fraunhofer firm evaluation [16] offers bounded outcome evidence. Its heteroscedasticity-generated instruments require substantive covariance and exclusion assumptions. Successful statistical diagnostics cannot prove them, and the estimated firm responses do not measure a national income gap or establish superiority over other organisational models. The most defensible inference is that intermediary functions are plausible, institutionally documented channels whose effectiveness needs programme-level evaluation.

An informative next study would observe eligible firms before and after exposure, specify the intermediary function and contract or secondment date, and measure adoption, productivity and value-added outcomes. Randomised offers, credible eligibility thresholds or phased openings could provide a counterfactual. Funding continuity, technical staffing, project selection and diffusion to non-participants should be measured directly. There is no defensible comparable national intermediary-organisation index in the present dataset.

## 9. Robustness, timing and limits

The main conclusions survive several descriptive checks. The global rank association remains positive with nominal income, after removing Israel's high-intensity observation, and after the specified boundary exclusions. Alternative matched cross-sections in 2019, 2021 and 2023 also show a positive relationship, although their available-country samples and provider coverage differ. Capability/publication associations remain positive with nonlinear intensity controls, rank adjustment and population controls. Industry, patent and funding results are more sensitive. Full specifications, country lists, coefficient intervals and leave-one-out correlation ranges accompany the paper.

Timing requires a distinct outcome. Table 7 relates earlier R&D intensity to subsequent annualised growth in constant-PPP GDP per capita, controlling for initial log income. The historical R&D series is the archived WDI series rather than a retroactive reconstruction of the harmonised 2022 provider selection. Each window is restricted to the main universe and available historical observations. These are exploratory convergence-adjusted diagnostics, not a causal distributed-lag or knowledge-stock model.

**Table 7. Earlier R&D and later real income growth**

| Growth window | n | R&D coefficient | HC3 95% interval |
| --- | --- | --- | --- |
| 2010–2019 | 69 | 0.192 | [-0.227, 0.611] |
| 2010–2022 | 69 | 0.489 | [-0.234, 1.212] |
| 2015–2022 | 75 | 0.683 | [-0.366, 1.732] |

*Notes: Outcome equals 100 × log(real PPP income at end / real PPP income at start) / years. Coefficients measure annual log-growth percentage points per one percentage-point difference in initial GERD/GDP, conditional on initial log income. All HC3 intervals include zero.*

The positive adjusted point estimates are compatible with a beneficial relationship, but the intervals do not distinguish them from zero. Unconditional associations differ because initially richer economies often grow more slowly. These results neither show that lags resolve the entire income puzzle nor contradict the better-identified funding and firm evidence in the literature. A credible return estimate requires a defined intervention, sufficient follow-up, research stocks and attention to spillovers and opportunity costs.

Several limitations remain central. The sample is selected by statistical availability; the 2022 cross-section can reflect pandemic recovery and exceptional commodity conditions. Mixed publication vintages remain despite matching observation years. Intensity has GDP in its denominator, so shocks to GDP can mechanically change the ratio as well as income; reverse causality and simultaneous choices remain. Population-normalised measures share a denominator, country indicators are noisy, and international spillovers violate simple independence assumptions. Broad industry groups conceal within-group technologies and firm heterogeneity. Financial flows are not institutional performance, gross exports are not domestic value added, and neither patents nor publications have been quality-adjusted.

The review is structured and targeted. It examines close precedents, major mechanism papers, one large meta-analysis and official organisational documents. Available full-text sections were read at the depths recorded in the companion review; some published studies were accessed through earlier working papers. Reading a meta-analysis is not equivalent to independently reading every included study. These boundaries are documented so that the empirical exercise and the literature claims can be extended without overstating the present evidence.

## 10. Discussion and conclusion

The statement “higher R&D investment means higher GDP per capita” needs a precise interpretation. As a broad cross-sectional tendency, it is supported. As a deterministic national ranking, it is contradicted by the dispersion among comparable-intensity economies. As a causal claim about an additional research investment, it cannot be adjudicated by this design. Positive but heterogeneous benefits in the wider literature remain compatible with all three observations.

Three explanations have substantive support, but of different kinds. **Capabilities and knowledge use** have strong conditional and held-out predictive evidence, supported by literature on absorption, diffusion and management. **Industrial composition** has direct accounting support: changing weights changes intensity benchmarks, although broad industrial shares explain little additional income variation on the smaller common sample. **Alternative income sources and production boundaries** are concretely relevant to extreme contrasts through resource rents and GNI/GDP, without providing a complete global decomposition. Research outputs overlap with capabilities; intermediaries, allocation and value capture supply additional mechanisms whose national causal contributions remain unmeasured.

The practical implication is to use R&D intensity as one component of a diagnostic system. Ask what research is performed, by whom and for what production base; whether firms can adopt and scale knowledge; where value added and income accrue; and whether specific intermediary services change firm outcomes. The evidence does not yield a universal optimal spending share, funding mix or intermediary model. It does support research policies assessed jointly with capability building, diffusion and productive use, rather than judged only by whether a national expenditure target has been reached.

## Reproducibility statement

The accompanying workbook, frozen input tables, raw supplementary responses, analysis and validation scripts, source provenance and literature-reading ledger document the calculation chain. The original archive is identified by its hash; repository HEAD is not established as its build commit. The companion *Literature Review* distinguishes publication records from actually inspected versions, and the *Journal Argument Guide* explains how leading papers inform the puzzle–mechanism–measurement–evidence structure used here. Analytical and document checks validate reproducibility within their stated scope, not the correctness of every official estimate or the causal interpretation of associations.

## References

[1] Goñi, E., and Maloney, W. F. (2017). Why don't poor countries do R&D? Varying rates of factor returns across the development process. *European Economic Review*, 94, 126–147. Substantive version inspected: World Bank Policy Research Working Paper 6811 (2014), *Why Don't Poor Countries Do R&D?* https://documents.worldbank.org/curated/en/855681468326185477/pdf/WPS6811.pdf

[2] Coad, A., and Vezzani, A. (2019). Three cheers for industry: Is manufacturing linked to R&D, exports, and productivity growth? *Structural Change and Economic Dynamics*, 50, 14–25. Inspected version: JRC Working Paper 06/2017, *Manufacturing the future*. https://doi.org/10.1016/j.strueco.2019.04.006

[3] Huang, C., Arundel, A., and Hollanders, H. (2010). How firms innovate: R&D, non-R&D, and technology adoption. UNU-MERIT Working Paper 2010-027. https://www.merit.unu.edu/publications/wppdf/2010/wp2010-027.pdf

[4] Cohen, W. M., and Levinthal, D. A. (1990). Absorptive capacity: A new perspective on learning and innovation. *Administrative Science Quarterly*, 35, 128–152. https://doi.org/10.2307/2393553

[5] Griffith, R., Redding, S., and Van Reenen, J. (2004). Mapping the two faces of R&D: Productivity growth in a panel of OECD industries. *Review of Economics and Statistics*, 86, 883–895. Inspected version: IFS Working Paper W02/00. https://doi.org/10.1162/0034653043125194

[6] Cirera, X., and Maloney, W. F. (2017). *The Innovation Paradox: Developing-Country Capabilities and the Unrealized Promise of Technological Catch-Up*. World Bank. Selected sections consulted. https://doi.org/10.1596/978-1-4648-1160-9

[7] Comin, D., and Mestieri, M. (2018). If technology has arrived everywhere, why has income diverged? *American Economic Journal: Macroeconomics*, 10, 137–178. Inspected version: NBER Working Paper 19010 (2013). https://doi.org/10.1257/mac.20150175

[8] Bloom, N., Eifert, B., Mahajan, A., McKenzie, D., and Roberts, J. (2013). Does management matter? Evidence from India. *Quarterly Journal of Economics*, 128, 1–51. Inspected version: NBER Working Paper 16658 (2011). https://doi.org/10.1093/qje/qjs044

[9] Hall, R. E., and Jones, C. I. (1999). Why do some countries produce so much more output per worker than others? *Quarterly Journal of Economics*, 114, 83–116. Inspected version: NBER Working Paper 6564 (1998). https://doi.org/10.1162/003355399555954

[10] Hsieh, C.-T., and Klenow, P. J. (2009). Misallocation and manufacturing TFP in China and India. *Quarterly Journal of Economics*, 124, 1403–1448. Inspected version: NBER Working Paper 13290, revised December 2008. https://doi.org/10.1162/qjec.2009.124.4.1403

[11] Syverson, C. (2011). What determines productivity? *Journal of Economic Literature*, 49, 326–365. Inspected version: NBER Working Paper 15712 (2010). https://doi.org/10.1257/jel.49.2.326

[12] Mathieu, A., and van Pottelsberghe de la Potterie, B. (2010). A note on the drivers of R&D intensity. *Research in World Economy*, 1(1). https://doi.org/10.5430/rwe.v1n1p56

[13] Teece, D. J. (1986). Profiting from technological innovation: Implications for integration, collaboration, licensing and public policy. *Research Policy*, 15, 285–305. https://doi.org/10.1016/0048-7333(86)90027-2

[14] Srholec, M. (2007). High-tech exports from developing countries: A symptom of technology spurts or statistical illusion? *Review of World Economics*, 143, 227–255. https://doi.org/10.1007/s10290-007-0106-z

[15] Howells, J. (2006). Intermediation and the role of intermediaries in innovation. *Research Policy*, 35, 715–728. https://doi.org/10.1016/j.respol.2006.03.005

[16] Comin, D., Licht, G., Pellens, M., and Schubert, T. (2019). Do companies benefit from public research organizations? The impact of the Fraunhofer Society in Germany. Working paper. https://doi.org/10.2139/ssrn.3354365

[17] Bloom, N., Jones, C. I., Van Reenen, J., and Webb, M. (2020). Are ideas getting harder to find? *American Economic Review*, 110, 1104–1144. https://doi.org/10.1257/aer.20180338

[18] Ugur, M., Trushin, E., Solomon, E., and Guidi, F. (2016). R&D and productivity in OECD firms and industries: A hierarchical meta-regression analysis. *Research Policy*, 45, 2069–2086. https://doi.org/10.1016/j.respol.2016.08.001

[19] Moretti, E., Steinwender, C., and Van Reenen, J. (2025). The intellectual spoils of war? Defense R&D, productivity, and international spillovers. *Review of Economics and Statistics*, 107, 14–27. Accepted manuscript consulted. https://doi.org/10.1162/rest_a_01293

[20] Fraunhofer-Gesellschaft. Finances: facts and figures. Official organisational description, accessed 11 November 2026. https://www.fraunhofer.de/en/about-fraunhofer/profile-structure/facts-and-figures/finances.html

[21] UK Department for Business, Energy & Industrial Strategy (2021). *Catapult Network Review: How the UK's Catapults Can Strengthen Research and Development Capacity*. https://assets.publishing.service.gov.uk/media/6065a7a9d3bf7f0c8d06b811/catapult-network-review-april-2021.pdf

[22] A*STAR. Programmes for SMEs. Official GET-Up/T-Up and capability-building descriptions, accessed 11 November 2026. https://www.a-star.edu.sg/enterprise/innovation-offerings/programmes-for-smes

[23] Satria, H. (2026). *Worldwide R&D and income explorer, 2000–2025*. Frozen project archive, supplemented with separately archived World Bank indicators. https://handysatria1.github.io/world-rd-income/ Archive SHA-256: `5094ee093f0abd22a335ccaaf5d0da8c8ba5fa0e453244ad6023877901ddc9eb`.

[24] Hall, B. H., Mairesse, J., and Mohnen, P. (2010). Measuring the returns to R&D. *Handbook of the Economics of Innovation*, 2, 1033–1082. Archived 2009 working-paper version used as background. https://doi.org/10.1016/S0169-7218(10)02008-3
