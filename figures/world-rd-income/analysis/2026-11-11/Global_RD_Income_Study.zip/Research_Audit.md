# Global research and reproducibility audit

## Scope and contribution

Research date: **11 November 2026**. This successor manuscript is organised around global patterns and rule-selected examples. It integrates national income, R&D personnel and outputs, capability indicators, industrial GVA/BERD, research focus, funding–performer structure and gross goods exports. It is a reproducible descriptive comparative study with a structured targeted literature review.

The analysis estimates income conditional on R&D. The older intensity-outcome regressions are not relabelled as income models. Country/economy observations have equal weights; no population-weighted claim about the world's average resident is made.

## 1. Frozen data and provenance

Original archive: https://handysatria1.github.io/world-rd-income/world-rd-income.zip

- Size at retrieval: **306,578,962 bytes**.
- SHA-256: **5094ee093f0abd22a335ccaaf5d0da8c8ba5fa0e453244ad6023877901ddc9eb**.
- Repository HEAD is **not established as the archive's build commit**.

The prior project verified 114 archived source hashes, 13,847 national observations, 6,243 industry ratios and 153 selected signed group sums. These are inherited upstream checks, with their original scope retained in `Source_notes/Upstream_Research_Audit.md` and copied validation reports. They do not imply that every official workbook or industrial concordance has been independently reconstructed.

The global analysis uses frozen extracts rather than requiring the 306 MB archive at runtime. `Data/input_manifest.csv` records 66 input files by relative path, size and SHA-256. `Source_notes/extract_provenance.json` identifies additional extracts copied from the preceding revision for independent validation. The `input_` prefixes distinguish frozen inputs from regenerated outputs. The supplement collector now limits its manifest to inputs rather than accidentally including generated analyses.

Supplementary World Bank responses, observation statuses, footnotes, metadata and retrieval URLs are retained in `Data/raw_wb/`. WGI uses source 3, with current identifiers `GOV_WGI_GE.EST` and `GOV_WGI_RL.EST`; HCI uses source 63. API “all” responses contain aggregates and blank ISO3 codes. Raw files remain intact; analytical joins filter to the frozen 83-economy universe before enforcing unique economy–metric–year keys.

### Observation years and vintages

- Core R&D, GDP, outputs, GVA, funding, focus and main supplements: **2022 observations**, where available.
- Human Capital Index: explicitly **2020**.
- Resource rents: latest available in **2020–2022**; **80 economies use 2021**, **Kuwait and Syria use 2020**, **Turkmenistan is missing**. Kenya and Saudi Arabia both use 2021. No 2022 rent value is silently inferred.
- Researchers: principal analysis uses **2022**. A separately labelled prior-observation field exists but is not substituted into the main measure.
- Core archive and 11 November 2026 supplements have distinct publication vintages. Matched observation years do not eliminate vintage differences.
- Population for density calculations comes from the supplement; PPP income retains the archive's vintage. The implied per-person research amount is an arithmetic scaling, not a separately observed cost-adjusted research measure.

## 2. Measurement boundaries

The core universe has 83 unique economies and excludes Basque Country and overlapping aggregates. Coverage declines to 55 for detailed GVA shares, 34–40 for major funding/performance indicators, and 19 for complete manufacturing standardisation. These are different selected samples. Country lists and coverage summaries accompany every statistical family.

GERD/GDP, manufacturing BERD/manufacturing GVA and industry shares of economy-wide GVA have distinct denominators. The industry calculation uses the complete A–T partition and five manufacturing groups. Common manufacturing weights are equal-economy averages of within-manufacturing GVA weights. Current-price structural weights are not real output volumes or causal restructuring scenarios.

MHT comprises ISIC 20, 21 and 26–30; custom KIS comprises J, K, M and P. Gross goods exports classify goods by associated industry, not necessarily the exporter's main activity, and do not measure domestic value added. The grouped accounts retain their source flags. Broad-sector ratios suppressed for negative reconciliation remainders remain missing even where assigned numerator and denominator amounts are present; Greece and Romania illustrate this distinction.

Funding × performer, research type × performer and field × performer are separate cubes. Source amount and multiplier checks precede share calculations. S2/V2 source-flagged shares are excluded under the inherited comparability rule. Research type/field shares retain their own totals; missing capital categories are not zero-filled. Singapore and Portugal do not have complete 2022 manufacturing BERD coverage for the reported manufacturing ratio.

The researcher series is reported as researchers per million; a full-time-equivalent label is not imposed solely from abbreviated API metadata. Scientific articles are the WDI scientific-and-technical-publication series, with selected journals and conference proceedings and field/database coverage. Patent counts are resident **applications**, not grants, patent families, quality-adjusted inventions or commercial returns. Metadata retrieved now does not establish that every historical source-definition revision was absent.

## 3. Selection and estimation

All 3,403 unordered pairs of the 83 economies are screened; 120 satisfy absolute intensity gap ≤0.15 percentage points **and** symmetric relative gap ≤10%. The latter is 2 × absolute gap / sum of intensities. The largest income ratio is selected within each **mean-intensity** band. The complete pair distribution and all selected pairs are disclosed. Selection is descriptive and was not preregistered.

Boundary sensitivity excludes Ireland, Luxembourg and economies with latest available 2020–2022 rents ≥10% GDP; an additional sensitivity requires population ≥1 million. Missing rents do not trigger exclusion. These flags are explicit diagnostic choices, not an exhaustive classification of unusual economic structures.

Outcome: natural-log current-PPP GDP per capita. Baseline: intercept plus GERD/GDP in percentage points. Conditional correlations residualise both the indicator and outcome on the same controls. Rank checks rank-transform both variables and intensity before residualisation. Scientific densities use log1p. The Fisher-transformation intervals use residual degrees of freedom; the 36 primary p-values receive BH adjustment. Spatial dependence, measurement uncertainty and nonrandom sampling limit inferential interpretation.

Models are OLS with HC3 covariance estimates and fixed complete-case samples within each family. Held-out RMSE uses explicit leave-one-economy-out refits; the validator recomputes it using the PRESS identity. No cross-validation-driven tuning is performed, but the indicators and model families are exploratory. Validation is internal rather than a prospective external forecast test. R² improvements and partial correlations are not causal shares of income.

Timing diagnostics use archived WDI initial R&D and constant-PPP income. Annualised log growth is conditioned on initial log income, in 2010–2019, 2010–2022 and 2015–2022. The universe is selected by 2022 availability. No shock identification, full knowledge-stock model, spatial spillover adjustment or causal lag estimate is claimed.

## 4. Literature and institutional evidence

`Literature_Review.md` contains a 22-work reading/access ledger, mechanism synthesis and search limitations. Reading depth distinguishes actual full-text sections, earlier working papers, prior-audit reuse and abstract/metadata access. In particular:

- Ugur et al. synthesises 65 studies; those 65 were not each independently read here.
- Goñi–Maloney, Coad–Vezzani, Comin–Mestieri, the management experiment, Hall–Jones, Hsieh–Klenow and Syverson were inspected in the specifically identified working-paper versions.
- Timmer et al. remains abstract/metadata access after unsuccessful full-text retrieval.
- The Fieldhouse–Mertens text consulted is the archived 2024 working paper, not a silently substituted later version.
- Current Fraunhofer/A*STAR web descriptions are not backdated to exact 2022 arrangements. Fraunhofer's competitive funding combines **public and private** contracts.
- The Fraunhofer evaluation relies on generated-instrument assumptions; institutional descriptions alone do not establish programme effects.

`Sources/Identity_Exclusions.md` records two exploratory NBER downloads with wrong paper numbers, rejected after title checks. Correct files use NBER 19010 and 15712. Wrong downloads remain in the research workspace as an audit trail and are excluded from delivery. `Sources/crossref_verification.json` records the supplementary DOI audit, including HTTP 429 access failures; full-text first-page metadata and earlier publisher records supply checks where available. A failed API call is not a bibliographic contradiction or a verified record.

Full literature PDFs and extracted copyrighted texts remain in the research workspace. The portable bundle includes provenance, links, the written review and official/statistical metadata needed to understand the evidence. Its offline numerical reproduction does not require literature downloads.

## 5. Validation and document review

`validate_global.py` independently checks source joins, scales, missingness, shares, pair selection, correlations, model coefficients, HC3 intervals, PRESS error and timing with NumPy linear algebra. It checks manuscript numerical cells and linked prose, Word table equality, workbook structure, PDF content bounds and the absence of empty pages. The PDF is typeset from the same Markdown as Word, with embedded DejaVu fonts and bookmarked headings.

The machine-readable report is `Data/global_validation.json`. The latest successful checks cover 32,619 supplementary source records, 3,530 amount/unit scalings, 4,897 funding/focus share cells including missingness, 719 industry checks, 79 product-export shares, 19 standardisations, 120 pairs, 36 conditional-correlation specifications, 14 common-sample correlations, 17 models, three timing models, 207 numerical table cells and 64 linked prose occurrences.

Visual review uses `PDF_contact_sheet.jpg` and full-size table/figure pages. A blank portrait page between consecutive landscape figures was detected and removed during review. Word tables, figures and text structure are checked programmatically; Word-native pagination is not asserted to match the PDF.

Portable reproduction is documented in `Data/portable_reproduction.json` after extracting the delivery ZIP into an isolated directory, running the four offline scripts and comparing regenerated results and PDF text. Package integrity is checked separately against `Delivery_Manifest.json`. Dependency installation requires internet on a new computer unless the exact packages are already cached; the analysis itself makes no network requests.

## 6. Interpretation

The strongest measured correlates are capabilities and scientific-system indicators. They overlap and are endogenous to development. Industry standardisation establishes an accounting distinction, while the common-sample income models caution against overstating broad sector/funding explanations. Resource and GNI/GDP comparisons document specific income mechanisms without allocating a causal percentage of any gap. Intermediary effectiveness, scientific quality, firm allocation and value-added trade remain priorities for more granular research.
