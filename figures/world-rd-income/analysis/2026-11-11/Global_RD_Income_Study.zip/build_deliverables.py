# /// script
# requires-python = ">=3.13"
# dependencies = ["python-docx==1.2.0", "reportlab==5.1.0", "matplotlib==3.11.2", "pillow==12.0.0"]
# ///
"""Build matching editable Word and bookmarked PDF from the global manuscript."""
from pathlib import Path
from html import escape
import re
import matplotlib
from PIL import Image as PILImage
from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION_START
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import BaseDocTemplate, Frame, Image, KeepTogether, NextPageTemplate, PageBreak, PageTemplate, Paragraph, Spacer, Table, TableStyle

ROOT = Path(__file__).resolve().parent
TEXT = (ROOT / "Paper.md").read_text(encoding="utf-8")
TITLE = TEXT.splitlines()[0][2:]
TEAL, INK, MUTED = "146B88", "203342", "586976"
HEADER = "GLOBAL R&D AND INCOME  |  EMPIRICAL RESEARCH DRAFT"
WIDTHS = {1:[1.30,1.60,1.25,1.80,.88], 2:[3.05,.40,1.03,1.40,.95],
          3:[4.13,.40,1.00,1.30], 4:[2.71,1.03,1.03,1.03,1.03],
          5:[2.10,1.55,1.63,1.55], 6:[1.00,1.90,1.90,2.03], 7:[2.03,.55,1.90,2.35]}
pattern = r"(\*\*.+?\*\*|(?<!\w)\*(?!\*)\S.*?\*(?!\w)|`[^`]+`|https?://[^\s]+)"

def parse():
    lines = TEXT.splitlines()
    blocks, i = [], 0
    while i < len(lines):
        line = lines[i].strip()
        i += 1
        if not line:
            continue
        if line.startswith("!["):
            match = re.fullmatch(r"!\[([^\]]+)\]\(([^)]+)\)", line)
            while not lines[i].strip():
                i += 1
            assert lines[i].startswith("*Figure ")
            blocks.append(("figure", (match[1],match[2],lines[i][1:-1])))
            i += 1
        elif line.startswith("|"):
            rows = []
            while True:
                row = [x.strip() for x in line.strip("|").split("|")]
                if not all(re.fullmatch(r":?-+:?", x) for x in row):
                    rows.append(row)
                if i == len(lines) or not lines[i].startswith("|"):
                    break
                line = lines[i].strip()
                i += 1
            blocks.append(("table", rows))
        else:
            kind = "body"
            for prefix, label in [("### ","h2"),("## ","h1"),("# ","title"),("> ","equation")]:
                if line.startswith(prefix):
                    kind,line = label,line[len(prefix):]
                    break
            if line.startswith("**Table "):
                kind = "tabletitle"
            elif line.startswith("*Notes:"):
                kind = "caption"
            elif line.startswith("**A matched-year"):
                kind = "subtitle"
            elif re.match(r"^\[\d+\] ",line):
                kind = "reference"
            blocks.append((kind,line))
    return blocks

def markup(text):
    out = []
    for token in re.split(pattern,text):
        if token.startswith("**"):
            out.append("<b>"+markup(token[2:-2])+"</b>")
        elif token.startswith("*") and token.endswith("*"):
            out.append("<i>"+markup(token[1:-1])+"</i>")
        elif token.startswith("http"):
            url=token.rstrip(".,;")
            out.append(f'<link href="{escape(url,quote=True)}" color="#{TEAL}">{escape(url)}</link>'+escape(token[len(url):]))
        else:
            out.append(escape(token[1:-1] if token.startswith("`") else token))
    return "".join(out)

def word_inline(p,text,bold=False,italic=False):
    for token in re.split(pattern,text):
        if not token:
            continue
        if token.startswith("**"):
            word_inline(p,token[2:-2],True,italic)
        elif token.startswith("*") and token.endswith("*"):
            word_inline(p,token[1:-1],bold,True)
        elif token.startswith("http"):
            url=token.rstrip(".,;")
            link=OxmlElement("w:hyperlink")
            link.set(qn("r:id"),p.part.relate_to(url,RT.HYPERLINK,is_external=True))
            run=OxmlElement("w:r")
            props=OxmlElement("w:rPr")
            color=OxmlElement("w:color");color.set(qn("w:val"),TEAL)
            props.append(color);run.append(props)
            t=OxmlElement("w:t");t.text=url;run.append(t);link.append(run);p._p.append(link)
            p.add_run(token[len(url):])
        else:
            run=p.add_run(token[1:-1] if token.startswith("`") else token)
            run.bold,run.italic=bold,italic

def layout(section,wide=False):
    section.orientation=WD_ORIENT.LANDSCAPE if wide else WD_ORIENT.PORTRAIT
    section.page_width=Inches(11.69 if wide else 8.27)
    section.page_height=Inches(8.27 if wide else 11.69)
    section.left_margin=section.right_margin=Inches(.72)
    section.top_margin=section.bottom_margin=Inches(.68)
    section.header_distance=section.footer_distance=Inches(.3)

blocks=parse()
doc=Document()
doc.core_properties.title=TITLE
doc.core_properties.author=""
doc.core_properties.subject="Global matched-year comparison of R&D, income, capabilities and production"
layout(doc.sections[0])
normal=doc.styles["Normal"]
normal.font.name,normal.font.size="Cambria",Pt(11)
normal.font.color.rgb=RGBColor.from_string(INK)
normal.paragraph_format.line_spacing=1.10
normal.paragraph_format.space_after=Pt(7)
normal.paragraph_format.widow_control=True
for name,size in [("Title",25),("Heading 1",16),("Heading 2",12),("Subtitle",12),("Caption",9)]:
    style=doc.styles[name]
    style.font.name,style.font.size="Calibri",Pt(size)
    style.font.color.rgb=RGBColor.from_string(MUTED if name in ["Subtitle","Caption"] else TEAL)
    style.paragraph_format.keep_with_next=name!="Caption"
header=doc.sections[0].header.paragraphs[0];header.text=HEADER;header.style="Caption";header.runs[0].font.size=Pt(8)
footer=doc.sections[0].footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
field=OxmlElement("w:fldSimple");field.set(qn("w:instr"),"PAGE");footer._p.append(field)
tn=0
for index,(kind,value) in enumerate(blocks):
    if kind=="figure":
        label,path,caption=value
        layout(doc.add_section(WD_SECTION_START.NEW_PAGE),True)
        p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
        w,h=PILImage.open(ROOT/path).size
        width=min(10.15,5.55*w/h)
        picture=p.add_run().add_picture(str(ROOT/path),width=Inches(width));picture._inline.docPr.set("descr",label)
        word_inline(doc.add_paragraph(style="Caption"),caption)
        if index+1==len(blocks) or blocks[index+1][0]!="figure":
            layout(doc.add_section(WD_SECTION_START.NEW_PAGE))
    elif kind=="table":
        tn+=1
        t=doc.add_table(rows=0,cols=len(value[0]));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
        for col,width in zip(t.columns,WIDTHS[tn]):
            col.width=Inches(width)
        for i,row in enumerate(value):
            cells=t.add_row().cells
            props=t.rows[-1]._tr.get_or_add_trPr();props.append(OxmlElement("w:cantSplit"))
            if i==0:
                props.append(OxmlElement("w:tblHeader"))
            for cell,text,width in zip(cells,row,WIDTHS[tn]):
                cell.width=Inches(width);p=cell.paragraphs[0]
                p.paragraph_format.space_before=p.paragraph_format.space_after=Pt(4);p.paragraph_format.line_spacing=1
                word_inline(p,text,bold=i==0)
                for run in p.runs:
                    run.font.name,run.font.size="Calibri",Pt(9)
                    if i==0:
                        run.font.color.rgb=RGBColor(255,255,255)
                shade=OxmlElement("w:shd");shade.set(qn("w:fill"),TEAL if i==0 else "F0F5F7" if i%2 else "FFFFFF")
                cell._tc.get_or_add_tcPr().append(shade)
    else:
        p=doc.add_paragraph(style={"title":"Title","subtitle":"Subtitle","h1":"Heading 1","h2":"Heading 2","caption":"Caption"}.get(kind,"Normal"))
        p.paragraph_format.keep_with_next=kind in ["title","subtitle","h1","h2","tabletitle"]
        if kind=="reference":
            p.paragraph_format.left_indent=Inches(.2);p.paragraph_format.first_line_indent=Inches(-.2)
        word_inline(p,value)
doc.save(ROOT/"Paper.docx")

fontpath=Path(matplotlib.get_data_path())/"fonts/ttf"
for suffix,filename in [("","DejaVuSans.ttf"),("-Bold","DejaVuSans-Bold.ttf"),("-Italic","DejaVuSans-Oblique.ttf"),("-BoldItalic","DejaVuSans-BoldOblique.ttf")]:
    pdfmetrics.registerFont(TTFont("Paper"+suffix,str(fontpath/filename)))
pdfmetrics.registerFontFamily("Paper",normal="Paper",bold="Paper-Bold",italic="Paper-Italic",boldItalic="Paper-BoldItalic")
ink,teal,muted=[colors.HexColor("#"+v) for v in [INK,TEAL,MUTED]]
styles={}
for name,size,leading in [("body",10.2,14.4),("title",25,29),("subtitle",12,17),("h1",15,20),("h2",11.5,16),("caption",8.5,11.5),("tabletitle",10,14),("equation",10,15),("reference",9,12.6),("cell",8.2,10.8),("cellhead",8.2,10.8)]:
    styles[name]=ParagraphStyle(name,fontName="Paper-Bold" if name in ["title","h1","h2","tabletitle","cellhead"] else "Paper",fontSize=size,leading=leading,textColor=colors.white if name=="cellhead" else teal if name in ["title","h1","h2"] else muted if name in ["subtitle","caption"] else ink,spaceAfter=7 if name not in ["cell","cellhead"] else 0,spaceBefore=10 if name in ["h1","h2"] else 0,keepWithNext=name in ["title","subtitle","h1","h2","tabletitle"],allowWidows=0,allowOrphans=0)
MX,MY=.72*72,.68*72
def furniture(canvas,document):
    w,h=canvas._pagesize
    canvas.saveState();canvas.setFillColor(muted);canvas.setFont("Paper",7.1)
    canvas.drawString(MX,h-24,HEADER);canvas.drawRightString(w-MX,24,str(document.page));canvas.restoreState()
class PDF(BaseDocTemplate):
    def afterFlowable(self,flowable):
        if isinstance(flowable,Paragraph) and flowable.style.name in ["h1","h2"]:
            key="heading_"+str(self.seq.nextf("heading"));self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(flowable.getPlainText(),key,level=0 if flowable.style.name=="h1" else 1,closed=False)
pdf=PDF(str(ROOT/"Paper.pdf"),pagesize=A4,title=TITLE,author="",leftMargin=MX,rightMargin=MX,topMargin=MY,bottomMargin=MY)
templates=[]
for name,size in [("portrait",A4),("landscape",landscape(A4))]:
    w,h=size
    templates.append(PageTemplate(id=name,frames=[Frame(MX,MY,w-2*MX,h-2*MY,leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],pagesize=size,onPage=furniture))
pdf.addPageTemplates(templates)
story,tn=[],0
for index,(kind,value) in enumerate(blocks):
    if kind=="figure":
        label,path,caption=value
        image=Image(str(ROOT/path));scale=min(10.15*72/image.drawWidth,5.55*72/image.drawHeight)
        image.drawWidth*=scale;image.drawHeight*=scale
        if index==0 or blocks[index-1][0]!="figure":
            story.extend([NextPageTemplate("landscape"),PageBreak()])
        next_template="landscape" if index+1<len(blocks) and blocks[index+1][0]=="figure" else "portrait"
        story.extend([Spacer(1,8),image,Spacer(1,10),Paragraph(markup(caption),styles["caption"]),NextPageTemplate(next_template),PageBreak()])
    elif kind=="table":
        tn+=1
        cells=[[Paragraph(markup(cell),styles["cellhead" if i==0 else "cell"]) for cell in row] for i,row in enumerate(value)]
        t=Table(cells,colWidths=[v*72 for v in WIDTHS[tn]],repeatRows=1,hAlign="LEFT")
        t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),teal),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.HexColor("#F0F5F7"),colors.white]),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)]))
        story.extend([t,Spacer(1,7)])
    else:
        p=Paragraph(markup(value),styles[kind]);story.append(KeepTogether([p]) if kind=="equation" else p)
pdf.build(story)
print(f"Created Paper.docx and Paper.pdf: {tn} tables, five figures.")
