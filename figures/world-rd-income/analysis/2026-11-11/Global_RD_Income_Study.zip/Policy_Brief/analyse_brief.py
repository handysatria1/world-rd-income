# /// script
# requires-python = ">=3.13"
# dependencies = ["numpy==2.5.4", "pandas==3.1.1", "scipy==1.18.1", "matplotlib==3.11.2", "openpyxl==3.1.5"]
# ///
"""Frozen 2022 global tests of hypotheses found in the user's presentations.

National analyses always use the original 83-economy universe. Basque Country
is a regional illustration only. No imputations or tests of an East-West effect.
First execution freezes extra archive inputs; subsequent execution is offline.
"""
from pathlib import Path
import hashlib
import json
import shutil
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

ROOT = Path(__file__).resolve().parent
D, F, I = ROOT/"Data", ROOT/"Figures", ROOT/"Inputs"
for folder in (D,F,I): folder.mkdir(exist_ok=True)
GLOBAL = ROOT.parent/"Data"
ARCHIVE = ROOT.parents[1]/"Archive/world-rd-income/figures/world-rd-income/data"
for name in ["basque_annual.csv", "sector_productivity.csv", "research_group_joined.csv", "broad_sector_annual.csv"]:
    target=I/name
    if not target.exists():
        q=pd.read_csv(ARCHIVE/name)
        q.loc[q.year.eq(2022)].to_csv(target,index=False)
if not (I/"research_group_classification.csv").exists():
    shutil.copy2(ARCHIVE/"research_group_classification.csv",I/"research_group_classification.csv")

d=pd.read_csv(GLOBAL/"global_countries_2022.csv").set_index("iso3")
assert len(d)==83 and "ES-PV" not in d.index and d.gdp_year.eq(2022).all()
d["log_population"]=np.log(d.population)
groups=pd.read_csv(I/"research_group_joined.csv")
prod=pd.read_csv(I/"sector_productivity.csv")
rdcube=pd.read_csv(GLOBAL/"input_rd_breakdown_annual.csv")
fields=pd.read_csv(GLOBAL/"input_rd_sector_field_annual.csv")
base=json.loads((GLOBAL/"summary.json").read_text())
summary={"baseline":base,"reference_year":2022}

def residual(values,controls):
    X=np.column_stack([np.ones(len(values)),np.asarray(controls)])
    return np.asarray(values)-X@np.linalg.lstsq(X,values,rcond=None)[0]

def partial_row(name,series):
    q=d[["rd","ppp","log_population"]].join(series.rename("x")).dropna()
    y=np.log(q.ppp)
    r=float(np.corrcoef(residual(q.x,q[["rd"]]),residual(y,q[["rd"]]))[0,1])
    rpop=float(np.corrcoef(residual(q.x,q[["rd","log_population"]]),residual(y,q[["rd","log_population"]]))[0,1])
    ci=np.tanh(np.arctanh(r)+np.array([-1,1])*1.96/np.sqrt(len(q)-4))
    p=float(2*stats.t.sf(abs(r*np.sqrt((len(q)-3)/(1-r*r))),len(q)-3))
    return dict(metric=name,n=len(q),raw_r=float(stats.pearsonr(q.x,y).statistic),partial_rd=r,
                ci_low=ci[0],ci_high=ci[1],partial_rd_population=rpop,p=p,countries=";".join(q.index))

# Concentration on EXACTLY the same five manufacturing bins, complete inputs only.
concentration=[]
for iso,q in groups.loc[groups.iso3.isin(d.index)&groups.group_id.between(3,7)].groupby("iso3"):
    q=q.sort_values("group_id")
    if len(q)!=5 or not q.berd_coverage.eq("complete").all() or not q.gva_coverage.eq("complete").all() or not q.berd_percent_gva.notna().all(): continue
    b=q.berd_assigned_usd.to_numpy();v=q.gva_assigned_usd.to_numpy()
    if np.any(~np.isfinite(b)) or np.any(~np.isfinite(v)) or b.sum()<=0 or np.any(v<=0): continue
    bshare,vshare=b/b.sum(),v/v.sum()
    concentration.append(dict(iso3=iso,economy=d.loc[iso,"economy"],berd_hhi=float(bshare@bshare),
                              gva_hhi=float(vshare@vshare),largest_berd_share=100*bshare.max(),
                              largest_gva_share=100*vshare.max(),portfolio_distance=.5*abs(bshare-vshare).sum(),
                              berd_top_group=q.iloc[bshare.argmax()].research_group))
c=pd.DataFrame(concentration).set_index("iso3")
assert len(c)>=10
c.to_csv(D/"manufacturing_concentration.csv")
summary["concentration"]={"n":len(c),"berd_more_concentrated":int((c.berd_hhi>c.gva_hhi).sum()),
                          "median_berd_hhi":float(c.berd_hhi.median()),"median_gva_hhi":float(c.gva_hhi.median()),
                          "median_berd_largest_share":float(c.largest_berd_share.median()),
                          "median_gva_largest_share":float(c.largest_gva_share.median())}
sector_shares=d[["economy","gva_mfg","berd_share_mfg"]].dropna()
sector_shares.to_csv(D/"manufacturing_research_production_shares.csv")
summary["manufacturing_overrepresentation"]={"n":len(sector_shares),
    "berd_share_larger":int((sector_shares.berd_share_mfg>sector_shares.gva_mfg).sum()),
    "median_berd_share":float(sector_shares.berd_share_mfg.median()),"median_gva_share":float(sector_shares.gva_mfg.median())}

# Within-country GVA per employed person: exchange-rate factors cancel in ratios.
p=prod.loc[prod.iso3.isin(d.index)].copy()
p["relative_gva_per_worker"]=p.gva_share_percent/p.employment_share_percent
p=p.loc[np.isfinite(p.relative_gva_per_worker)]
assert np.allclose(p.relative_gva_per_worker,p.gva_per_person_usd_thousand/p.economy_gva_per_person_usd_thousand)
p.to_csv(D/"sector_productivity_relative.csv",index=False)
wide=p.pivot(index="iso3",columns="group",values="relative_gva_per_worker")
pr=[]
for a,b in [("MHT","LMT"),("KIS","LIS"),("MHT","KIS")]:
    q=wide[[a,b]].dropna()
    pr.append(dict(comparison=f"{a}/{b}",n=len(q),first_higher=int((q[a]>q[b]).sum()),
                   median_ratio=float((q[a]/q[b]).median()),countries=";".join(q.index)))
pd.DataFrame(pr).to_csv(D/"sector_productivity_comparisons.csv",index=False)
summary["productivity"]=pr

# Research type comparison: government PERFORMERS (not all public research)
# versus business performers. Normalise only observed BR/AR/ED portfolios, retaining coverage.
portfolio=[]
for iso,row in d.iterrows():
    arrays=[row[[f"research_{s}_{k}" for k in ["BR","AR","ED"]]].to_numpy(float) for s in ["BES","GOV"]]
    if not all(np.isfinite(a).all() and a.sum()>=90 and (a>=0).all() for a in arrays): continue
    b,g=arrays
    portfolio.append(dict(iso3=iso,economy=row.economy,business_three_type_coverage=b.sum(),government_three_type_coverage=g.sum(),
                          distance=.5*abs(b/b.sum()-g/g.sum()).sum(),business_ed=100*b[2]/b.sum(),government_ed=100*g[2]/g.sum()))
pf=pd.DataFrame(portfolio).set_index("iso3")
pf.to_csv(D/"government_business_portfolios.csv")
new=[partial_row("Manufacturing BERD concentration (HHI)",c.berd_hhi),
     partial_row("Manufacturing R&D-GVA composition distance",c.portfolio_distance),
     partial_row("Government-business research-type distance",pf.distance),
     partial_row("MHT relative GVA per worker",wide.MHT),
     partial_row("KIS relative GVA per worker",wide.KIS)]
new=pd.DataFrame(new)
new["bh_q"]=stats.false_discovery_control(new.p.to_numpy(),method="bh")
new.to_csv(D/"additional_global_tests.csv",index=False)

# Rebuild common manufacturing weights from the frozen five-bin input.
good=groups.loc[groups.iso3.isin(c.index)&groups.group_id.between(3,7)].copy()
good["within_mfg_weight"]=good.gva_assigned_usd/good.groupby("iso3").gva_assigned_usd.transform("sum")
weights=good.groupby("group_id").within_mfg_weight.mean()
weights.rename("mean_gva_weight").to_csv(D/"common_manufacturing_weights.csv")
good["within_intensity"]=100*good.berd_assigned_usd/good.gva_assigned_usd
good["standardised_contribution"]=good.group_id.map(weights)*good.within_intensity
std=good.groupby("iso3").standardised_contribution.sum()
prior=pd.read_csv(GLOBAL/"manufacturing_standardisation.csv").set_index("iso3")
assert set(std.index)==set(prior.index) and np.allclose(std,prior.loc[std.index,"common_structure"],atol=1e-9)
prior.to_csv(D/"manufacturing_standardisation.csv")

# Six-case dashboard, all observations 2022. Basque numeric provenance is separate.
cases=["ES-PV","SGP","KOR","GBR","USA","CHN"]
profiles=d.reindex(cases).copy()
basque=pd.read_csv(I/"basque_annual.csv").iloc[0]
profiles.loc["ES-PV",["economy","rd","ppp","nominal","gdp_year"]]=[
    "Basque Country",basque.rd_percent_gdp_derived,basque.gdp_per_capita_ppp_derived,basque.gdp_per_capita_usd_derived,2022]
profiles["geography_type"]="national economy"
profiles.loc["ES-PV","geography_type"]="region within Spain"
profiles.loc["SGP","geography_type"]="city-state"
profiles["ppp_note"]="National GDP PPP"
profiles.loc["ES-PV","ppp_note"]="Spain national GDP-PPP proxy, not regional price survey"
b=rdcube.loc[rdcube.iso3.eq("ES-PV")&rdcube.year.eq(2022)&rdcube.basis.eq("XDC_V")]
def amount(kind,sector,category):
    q=b.loc[b.breakdown.eq(kind)&b.sector_code.eq(sector)&b.category_code.eq(category),"amount"]
    return float(q.iloc[0]) if len(q)==1 else np.nan
total=amount("funding","_T","_T")
assert total==basque.gerd_eur_reported
for funder in ["BES","GOV","HES","PNP","ROW"]:
    profiles.loc["ES-PV",f"fund_{funder}"]=100*amount("funding","_T",funder)/total
for sector in ["BES_PNP","GOV","HES"]:
    profiles.loc["ES-PV",f"perform_{sector}"]=100*amount("funding",sector,"_T")/total
for code in ["BR","AR","ED","CAP_EX_NEC"]:
    profiles.loc["ES-PV",f"research_ALL_{code}"]=100*amount("research","_T",code)/total
for code in ["FORD1","FORD2","FORD3"]:
    q=fields.loc[fields.iso3.eq("ES-PV")&fields.year.eq(2022)&fields.basis.eq("XDC_V")&fields.sector_code.eq("_T")].set_index("field_code")
    if code in q.index and "_T" in q.index:
        profiles.loc["ES-PV",f"field_ALL_{code}"]=100*q.loc[code,"amount"]/q.loc["_T","amount"]
bg=groups.loc[groups.iso3.eq("ES-PV")&groups.group_id.between(3,7)]
assert len(bg)==5 and bg.gva_coverage.eq("complete").all()
profiles.loc["ES-PV","gva_mfg"]=bg.gva_share_percent.sum()
for group in ["MHT","LMT","KIS","LIS"]:
    q=prod.loc[prod.iso3.eq("ES-PV")&prod.group.eq(group)]
    if len(q)==1: profiles.loc["ES-PV",f"gva_{group}"]=q.iloc[0].gva_share_percent
exports=pd.read_csv(GLOBAL/"input_sector_exports.csv")
q=exports.loc[exports.iso3.eq("ES-PV")&exports.year.eq(2022)]
if len(q):
    # Column names differ from the linked national dashboard: preserve source table too.
    q.to_csv(D/"basque_exports_source.csv",index=False)
    for group in ["MHT","LMT"]:
        value=q.loc[q.group.eq(group)&q.coverage_status.eq("available"),"share_percent"]
        if len(value)==1: profiles.loc["ES-PV",f"export_{group}"]=float(value.iloc[0])
profiles["gerd_ppp_bn_identity"]=profiles.rd/100*profiles.ppp*profiles.population/1e9
profiles.loc["ES-PV","gerd_ppp_bn_identity"]=basque.gerd_ppp_derived/1e9
profiles["business_scope"]="Business enterprises"
profiles.loc["ES-PV","business_scope"]="Business + private nonprofit, kept combined"
profiles.to_csv(D/"six_case_profiles_2022.csv")
pd.DataFrame([basque]).to_csv(D/"basque_income_provenance.csv",index=False)
pairs=[]
for a,b in [("ES-PV","SGP"),("KOR","GBR"),("USA","CHN")]:
    x,y=profiles.loc[a],profiles.loc[b]
    gap=abs(x.rd-y.rd);rel=gap/((x.rd+y.rd)/2)
    pairs.append(dict(pair=f"{a}–{b}",first=a,second=b,absolute_rd_gap_pp=gap,relative_rd_gap=rel,
                      strict_near_intensity=bool(gap<=.15 and rel<=.1),
                      income_ratio_second_over_first=y.ppp/x.ppp,
                      national_regression_pair=a!="ES-PV" and b!="ES-PV"))
pd.DataFrame(pairs).to_csv(D/"illustrative_pair_audit.csv",index=False)
assert not any(p["strict_near_intensity"] for p in pairs)
summary["pairs"]=pairs
summary["additional_tests"]=new.to_dict("records")
summary["portfolio_n"]=len(pf)

# Exact symmetric decomposition of manufacturing BERD / whole-economy GVA.
dec=[]
for a,b in [("KOR","GBR"),("USA","CHN")]:
    qa=good.loc[good.iso3.eq(a)].set_index("group_id")
    qb=good.loc[good.iso3.eq(b)].set_index("group_id")
    wa,wb=qa.gva_share_percent/100,qb.gva_share_percent/100
    ia,ib=qa.within_intensity,qb.within_intensity
    composition=float(((wa-wb)*(ia+ib)/2).sum())
    intensity=float(((ia-ib)*(wa+wb)/2).sum())
    delta=float((wa*ia).sum()-(wb*ib).sum())
    assert abs(composition+intensity-delta)<1e-10
    dec.append(dict(pair=f"{a} minus {b}",gap_pp=delta,composition_pp=composition,within_group_intensity_pp=intensity))
pd.DataFrame(dec).to_csv(D/"manufacturing_accounting_decomposition.csv",index=False)
summary["decompositions"]=dec

# Figures: global context first, case colours identify comparisons, not inferential groups.
TEAL,ORANGE,INK="#176B83","#C56132","#203342"
colours={"ES-PV":"#6C5B9A","SGP":"#6C5B9A","KOR":ORANGE,"GBR":ORANGE,"USA":TEAL,"CHN":TEAL}
short={"ES-PV":"Basque*","SGP":"Singapore","KOR":"Korea","GBR":"UK","USA":"US","CHN":"China"}
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,"axes.spines.top":False,"axes.spines.right":False,
                     "axes.titleweight":"bold","axes.labelcolor":INK,"text.color":INK,"savefig.facecolor":"white"})
def save(fig,name):
    fig.savefig(F/f"{name}.png",dpi=200,bbox_inches="tight")
    fig.savefig(F/f"{name}.svg",bbox_inches="tight")
    plt.close(fig)
fig,ax=plt.subplots(figsize=(8.1,4.6))
ax.scatter(d.rd,d.ppp,color="#A5B1B8",s=24,alpha=.75,label="83-economy sample")
x=np.linspace(0,d.rd.max(),200)
coef=np.linalg.lstsq(np.column_stack([np.ones(len(d)),d.rd]),np.log(d.ppp),rcond=None)[0]
ax.plot(x,np.exp(coef[0]+coef[1]*x),color="#697B86",lw=1.3,label="Log-income linear fit")
offsets={"ES-PV":(-2,14),"SGP":(10,0),"KOR":(9,-3),"GBR":(8,-17),"USA":(10,2),"CHN":(10,-4)}
for iso,r in profiles.iterrows():
    ax.scatter(r.rd,r.ppp,s=70,marker="D" if iso=="ES-PV" else "o",facecolors="white" if iso=="ES-PV" else colours[iso],edgecolors=colours[iso],zorder=4)
    ax.annotate(short[iso],(r.rd,r.ppp),xytext=offsets[iso],textcoords="offset points",fontsize=10,color=colours[iso],weight="bold")
ax.set(yscale="log",xlabel="R&D expenditure / GDP (%)",ylabel="GDP per person (current international $, PPP)",ylim=(2000,220000),xlim=(-.1,7.1))
ax.set_yticks([3000,10000,30000,100000]);ax.yaxis.set_major_formatter(FuncFormatter(lambda v,p:f"{v:,.0f}"))
ax.legend(loc="lower right",frameon=False,fontsize=9)
ax.grid(axis="y",alpha=.18)
save(fig,"Figure_1_global")

cor=pd.read_csv(GLOBAL/"income_correlations.csv").set_index("metric")
metrics=["gov_effect","internet","hci_2020","log_publications_pm","log_researchers","log_patents_pm","gva_KIS","gva_mfg","fund_BES","research_ALL_ED"]
labels=["Government effectiveness","Internet use","Human Capital Index (2020)","Articles per million (log1p)","Researchers per million (log1p)","Resident patents per million (log1p)","Custom KIS share of GVA","Manufacturing share of GVA","Business funding share","Experimental development share"]
fig,ax=plt.subplots(figsize=(8.1,4.8))
for j,(m,label) in enumerate(zip(metrics,labels)):
    r=cor.loc[m]
    ax.plot([r.ci_low,r.ci_high],[j,j],color=TEAL,lw=1.8)
    ax.scatter(r.partial_rd,j,color=TEAL,s=30,zorder=3)
    ax.text(1.16,j,f"n={int(r.n)}",ha="right",va="center",fontsize=9)
ax.axvline(0,color="#7F8C94",lw=.8);ax.set_yticks(range(len(metrics)),labels);ax.invert_yaxis()
ax.set(xlim=(-.55,1.20),xlabel="Correlation with log income after linear R&D adjustment")
ax.set_xticks([-.4,-.2,0,.2,.4,.6,.8,1])
fig.tight_layout();save(fig,"Figure_2_capabilities")

fig,axes=plt.subplots(1,2,figsize=(8.1,3.8),gridspec_kw={"width_ratios":[1,1.3]})
axes[0].scatter(c.gva_hhi,c.berd_hhi,color="#8FA4AE",s=35)
axes[0].plot([.2,1],[.2,1],color="#8C969C",ls="--",lw=1)
for iso in ["KOR","GBR","USA","CHN"]:
    axes[0].scatter(c.loc[iso,"gva_hhi"],c.loc[iso,"berd_hhi"],color=colours[iso])
    shift={"KOR":(7,7),"GBR":(-16,13),"USA":(32,-3),"CHN":(22,25)}[iso]
    axes[0].annotate(short[iso],(c.loc[iso,"gva_hhi"],c.loc[iso,"berd_hhi"]),xytext=shift,textcoords="offset points",fontsize=8,
                     arrowprops=dict(arrowstyle="-",color=colours[iso],lw=.6),color=colours[iso],
                     bbox=dict(facecolor="white",alpha=.8,edgecolor="none",pad=1))
axes[0].set(xlabel="GVA concentration (HHI)",ylabel="R&D concentration (HHI)",xlim=(.19,.6),ylim=(.19,.8),title=f"A. Same five groups; n={len(c)}")
ss=prior.loc[["USA","KOR","CHN","GBR","TUR","FIN"]]
for j,(iso,r) in enumerate(ss.iterrows()):
    axes[1].plot([r.observed,r.common_structure],[j,j],color="#B7C1C8",lw=2)
    axes[1].scatter(r.observed,j,color=ORANGE,s=38,label="Observed" if j==0 else None)
    axes[1].scatter(r.common_structure,j,color=TEAL,s=38,label="Common weights" if j==0 else None)
axes[1].set_yticks(range(len(ss)),[short.get(i,{"TUR":"Türkiye","FIN":"Finland"}.get(i,i)) for i in ss.index]);axes[1].invert_yaxis()
axes[1].set(xlabel="Manufacturing BERD / GVA (%)",title="B. Composition changes benchmarks",xlim=(0,15))
axes[1].legend(frameon=False,fontsize=8,loc="lower right")
fig.tight_layout();save(fig,"Figure_3_structure")

fig,axes=plt.subplots(1,2,figsize=(8.1,3.5),sharey=True)
for ax,kind,title in zip(axes,["fund","perform"],["A. Who pays?","B. Who performs?"]):
    bottom=np.zeros(6)
    categories=[("BES","Business",TEAL),("GOV","Government",ORANGE),("HES","Higher education","#8A79AB")]
    if kind=="fund": categories.append(("ROW","Abroad","#A5B6C1"))
    for code,label,colour in categories:
        vals=profiles[f"{kind}_{code}"].to_numpy(float,copy=True)
        if kind=="perform" and code=="BES": vals[0]=profiles.loc["ES-PV","perform_BES_PNP"]
        # Draw only known components; missing observations stay NaN in the data.
        # Their unassigned share is included in the grey remainder, not declared zero.
        drawn=np.where(np.isfinite(vals),vals,0)
        ax.barh(range(6),drawn,left=bottom,label=label,color=colour,height=.65);bottom+=drawn
    rem=100-bottom
    assert np.all(rem>=-.001)
    ax.barh(range(6),rem,left=bottom,label="Other / unreported",color="#E1E6E9",height=.65)
    ax.set(title=title,xlim=(0,100),xlabel="Share of total R&D (%)")
    ax.set_yticks(range(6),[short[i] for i in profiles.index])
    ax.legend(loc="upper center",bbox_to_anchor=(.5,-.19),ncol=2,frameon=False,fontsize=8)
axes[0].invert_yaxis();fig.tight_layout();save(fig,"Figure_4_funding")

fig,ax=plt.subplots(figsize=(8.1,3.7))
ax.scatter(pf.government_ed,pf.business_ed,s=34,color="#A5B1B8")
for iso in [i for i in cases if i in pf.index]:
    r=pf.loc[iso];ax.scatter(r.government_ed,r.business_ed,color=colours[iso],s=60)
    ax.annotate(short[iso],(r.government_ed,r.business_ed),xytext=(6,-11 if iso=="CHN" else 5),textcoords="offset points",fontsize=10)
ax.plot([0,100],[0,100],ls="--",lw=1,color="#899AA5")
ax.set(xlabel="Experimental development in government-performed R&D (%)",ylabel="Experimental development in business R&D (%)",xlim=(0,100),ylim=(0,104))
fig.tight_layout();save(fig,"Figure_5_portfolios")

manifest=[]
for path in sorted(I.glob("*.csv"))+[GLOBAL/n for n in ["global_countries_2022.csv","input_rd_breakdown_annual.csv","input_rd_sector_field_annual.csv","input_sector_exports.csv","summary.json","income_correlations.csv","manufacturing_standardisation.csv"]]:
    manifest.append(dict(path=path.relative_to(ROOT.parent).as_posix(),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
pd.DataFrame(manifest).to_csv(D/"input_manifest.csv",index=False)
(D/"summary.json").write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding="utf-8")
with pd.ExcelWriter(ROOT/"Policy_Brief_Evidence.xlsx",engine="openpyxl") as writer:
    for path in sorted(D.glob("*.csv")):
        pd.read_csv(path).to_excel(writer,sheet_name=path.stem[:31],index=False)
    for ws in writer.book:
        ws.freeze_panes="C2";ws.auto_filter.ref=ws.dimensions
        for col in ws.columns:
            from openpyxl.utils import get_column_letter
            ws.column_dimensions[get_column_letter(col[0].column)].width=min(45,max(15,len(str(col[0].value))+2))
print(json.dumps({k:v for k,v in summary.items() if k!="baseline"},indent=2,ensure_ascii=False))
