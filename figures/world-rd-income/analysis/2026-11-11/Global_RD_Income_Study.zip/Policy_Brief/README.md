# Global policy brief and methods companion

## Start here

1. **Policy_Brief.pdf** — nine-page figure-led brief, including two reference pages; global evidence followed by Basque Country–Singapore, Korea–UK and US–China.
2. **../Methods/Methods_Guide.pdf** — ten-page supervisor-ready explanation, equations, actual China/Iceland residual calculations, Excel instructions and likely questions.
3. **../Methods/Worked_Example.xlsx** — live Excel formulas and already-populated Python-verified values. Excel itself was not executed; opening requests recalculation.
4. **Policy_Brief_Evidence.xlsx** — six-case profiles, pair audit, global tests, industrial accounts and exact samples.

Both documents also have editable `.docx` and `.md` versions. PDF layouts were visually checked; Word content/structure is verified programmatically, but its pagination depends on the local Word/font environment.

## Findings and audit

- `Patterns_and_Hypotheses.md`: which slide-inspired propositions generalise, which do not, and which remain uncertain.
- `Comparability.md`: scope, sources, denominator differences, missing data and case-specific restrictions.
- `PDF_Review/Reading_Ledger.md` and `.csv`: actual reading depth for 78 byte-unique documents from 92 PDF paths. All eight presentation texts were read; not every page of the wider source library was substantively read.
- `Data/Six_Case_Extended_Table.md`: additional research personnel, publications, patents, types, fields and funding comparisons.
- `Data/input_manifest.csv`: input hashes.
- `Data/validation.json`: numerical and document checks.

## Offline reproduction

From the parent `Global` folder, run:

```powershell
uv run --python 3.13 analyse_global.py
uv run --python 3.13 Methods/worked_example.py
uv run --python 3.13 Policy_Brief/analyse_brief.py
uv run --python 3.13 Policy_Brief/render_documents.py
uv run --python 3.13 Policy_Brief/build_documents.py
uv run --python 3.13 Policy_Brief/validate_brief.py
```

Python dependencies are pinned in script headers. Add `--offline` after `uv run` when the dependencies are cached. The included frozen inputs avoid all source downloads during analytical reproduction. The original global paper has separate `render_paper.py`, `build_deliverables.py` and `validate_global.py` commands documented in the parent README.

Templates are the editable sources for document revisions; the renderer inserts tables from CSV/JSON. `build_reading_ledger.py` rebuilds the ledger from the inventory and screening bundles, using the documented prior reading record; it does not perform new reading. `review_pdfs.py` and `screen_sources.py` are workspace-only inventory/extraction aids and require the original PDFs. Full source texts and thumbnail contact sheets are kept in the research workspace, while the portable package contains the inventory, bounded screens and ledger.

## Evidence limits

Equal-weight cross-sectional associations and accounting identities are descriptive. None of the requested pairs meets the strict near-intensity rule. Basque Country is excluded from national regressions; its PPP uses Spain's factor. Five additional hypotheses form a separate exploratory multiple-testing family. All five approximate intervals include zero. Institutional descriptions and published causal findings retain their different evidence bases in the brief and parent literature review.
