# Six-case measurement supplement

| Measure | Basque* | Singapore | Korea | UK | US | China |
| --- | --- | --- | --- | --- | --- | --- |
| Researchers per million | — | 8,782 | 9,435 | — | 4,937 | 1,849 |
| Articles per million | — | 2,200 | 1,393 | 1,505 | 1,340 | 627 |
| Resident applications per million | — | 303 | 3,556 | 165 | 819 | 1,037 |
| Basic research / reported total (%) | — | 23.61 | 15.02 | — | 14.42 | 6.57 |
| Applied research / reported total (%) | — | 29.81 | 19.93 | — | 17.98 | 11.31 |
| Development / reported total (%) | — | 46.58 | 65.05 | — | 67.36 | 82.11 |
| Engineering / field total (%) | 69.88 | 62.79 | 71.58 | — | — | — |
| Custom KIS / GVA (%) | 19.43 | 25.79 | 21.03 | 29.53 | 27.89 | 16.05 |
| Business funding / GERD (%) | 55.92 | 59.19 | 76.31 | 60.03 | 69.64 | 79.02 |
| Business performance / GERD (%) | — | 64.16 | 79.38 | 70.81 | 78.32 | 77.57 |
| Combined business + nonprofit performance (%) | 77.14 | — | — | — | — | — |
| Manufacturing BERD / manufacturing GVA (%) | — | — | 11.82 | 4.83 | 13.20 | 5.56 |

All values 2022; unavailable/comparability-excluded cells are —. Research-type and field totals differ. Basque business/nonprofit performers remain combined. Singapore survey scope excludes social sciences/humanities. UK aggregate research types and researcher density are unavailable in this same-year dataset; specific-performer research portfolios are separately available. These counts are not quality-adjusted efficiency measures. See ../Comparability.md.
