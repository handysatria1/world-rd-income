# Comparability and sources for the policy brief

## 1. Units, years and universe

The main universe is the existing 83-economy matched 2022 dataset, frozen in `../Data/global_countries_2022.csv`. Economies are equally weighted. Basque Country (`ES-PV`) is a region within Spain, excluded from regressions to avoid overlap with Spain. Singapore is a city-state. National samples also include separately reported statistical economies; “83 countries” should not be used as a sovereign-state claim.

The 2022 observations retain their inherited provider/vintage choices. Same observation year does not imply identical publication/revision dates. HCI is explicitly 2020; resource rents use the latest available 2020–2022 observation. Those exceptions remain labelled in the global data and do not enter the new five-test family. Earlier presentation charts showing 2024, 2025 or provisional Basque values are not substituted into the matched-year profiles.

Every additional input is frozen under `Inputs/`. `Data/input_manifest.csv` contains SHA-256 values for all direct analytical inputs. The source archive and global metadata remain the authoritative upstream provenance; initial freeze requires the original archive, but the delivered inputs allow offline reruns. Do not re-run collection scripts to reproduce the frozen results.

## 2. Measurement boundaries

- **GDP** is gross domestic production at market prices; **GVA** is value added at basic prices. Net taxes on products separate these concepts; sector GVA shares do not use GDP as their denominator.
- **GERD** covers domestic R&D across institutional performers. **BERD** is business-performed research regardless of funding source. Industry BERD is assigned to economic activities, not identical to the field of the research.
- **Funding source × performer**, **research type × performer**, and **field × performer** are separate source cubes. They cannot be joined into a funding source × research type cross-tabulation without additional evidence.
- **Manufacturing BERD/GVA** uses manufacturing GVA. The pair decomposition uses manufacturing BERD divided by **whole-economy GVA**. Their percentage-point differences are different objects.
- **MHT** is the project group ISIC 20, 21, 26–30; **custom KIS** comprises J, K, M, P. They are not interchangeable with every official technology/knowledge classification, or with the ifo article's headquarters-based corporate categories. `Inputs/research_group_classification.csv` records the five manufacturing groups; the broader classification is in the inherited source metadata.
- Export indicators are **gross goods** shares, not domestic-value-added exports, service exports or quality-adjusted technology measures. Basque native technology classes are adjusted by NACE 254, 325 and 301 to the project grouping. Residual goods remain outside MHT/LMT; no rescaling to force their sum to 100%.
- Researchers are a capacity/input measure; articles and resident patent applications represent distinct outputs. Population-normalised counts are not quality-adjusted and need not measure where knowledge is ultimately used. The ifo reference uses PCT applications, which differ from this project's resident-application series.

## 3. Case-specific restrictions

| Case | Preserved source restriction | Consequence |
|---|---|---|
| Basque Country | Eustat regional GERD/GDP/GDP per person; Spain national PPP = 0.55926 EUR/international dollar | PPP income is a proxy; no own regional price index; not included in national regressions |
| Basque Country | Business and private non-profit performers are combined | `perform_BES` stays missing; combined 77.144% is labelled explicitly in Figure 4 |
| Basque Country | Research-type cube has totals and separately reported capital only | Basic/applied/development remain missing; no allocation from fields or slides |
| Basque Country | Matched 2022 industry research does not provide an eligible comparable manufacturing BERD ratio here | No invented manufacturing BERD/GVA; GVA and exports still usable |
| Singapore | RIE scope is science and technology; social sciences/humanities excluded in report definitions | National institutional shares/types require this scope qualification |
| Singapore | Detailed industry BERD insufficient for the project's complete manufacturing ratio | Do not treat its science/technology field categories as industries |
| UK | Same-year researcher density and aggregate research-type mix unavailable/comparability-excluded | Missing stays missing; available business/government research portfolios may still be used |
| UK | Observed business BR/AR/ED covers 93.308% of reported performer total | Normalise three observed types only in the portfolio comparison; retain coverage |
| US | Observed government BR/AR/ED covers 98.378% of performer total | Same normalisation rule; do not silently present as full-budget shares |
| China | Resident applications and territorial R&D differ from PCT applications/headquarters spending | Do not equate legal counts with research quality or value capture |

Basque 2022 arithmetic: GERD €1,794,704,000; GDP €86,714,411,000; reported GDP/person €39,587. Intensity = 2.069672%; PPP proxy = $70,784.6082. Values and original source URLs/retrieval times are in `Data/basque_income_provenance.csv`. The implied PPP R&D total is computed separately; no population is reverse-engineered from rounded income.

Basque export shares: MHT 46.331397%, LMT 49.879912%, residual 3.788691%. Raw source/reclassification details are in `Data/basque_exports_source.csv`. MHT/LMT now populate the six-case profiles.

## 4. New analysis rules

**Industry eligibility:** five complete manufacturing groups, finite/nonnegative research, positive GVA and non-missing inherited valid BERD/GVA ratios. This preserves the earlier 19-economy standardisation sample. Romania's apparently complete underlying amounts have unavailable valid ratios and remain excluded; this analysis does not reverse the source restriction.

**Concentration:** HHI is calculated using the same five groups separately for manufacturing research and GVA. The whole-economy manufacturing-overrepresentation result and the within-manufacturing HHI result are conceptually different. Aggregation can mask concentration within a broad group.

**Portfolio comparison:** government performers are not all public research. Both government and business must have all three basic/applied/development cells observed, nonnegative, and total coverage ≥90%. Normalise each observed three-type vector to sum to one, calculate half the L1 distance, and retain original coverage. The distance is not a collaboration/translation-effectiveness measure. Basque Country is unavailable.

**Sector productivity:** relative GVA per employed person = sector GVA share / sector employment share, with consistent denominators. All comparisons are within-country nominal ratios. Hours, prices, capital intensity and composition can contribute; these are not causal reallocation gains or sector-PPP productivity comparisons.

**Inference:** five new exploratory partial correlations refit both regressions on the exact complete-case sample. One control is GERD/GDP; the additional sensitivity also includes log population. Fisher intervals are approximate and pointwise. The five p-values receive BH adjustment as a distinct exploratory family. Exact country lists are retained. All five intervals include zero; no zero-effect or equivalence claim follows.

## 5. Institutional and reading evidence

Kleibrink–Magro supports government-led Basque policy design, stakeholder contestation and stakeholder co-led implementation; it does not support reducing the system to a purely bottom-up label. A*STAR current programme pages and the UK 2021 Catapult review describe mechanisms, not a harmonised 2022 treatment-effect comparison. Fraunhofer's competitive two-thirds includes public as well as private contracts.

`PDF_Review/Reading_Ledger.md` records the actual reading depth of all 78 unique PDFs. The eight presentation texts, ifo article text, Singapore report text and definitions note were read fully as extracted text. Other documents have targeted sections, bounded excerpts or prior source audits. Full extraction is not full intellectual reading, and thumbnail contact sheets do not validate small numerical chart labels. Two misnamed source files are excluded. The supplied data, not slide-only numbers, generate the current tables.
