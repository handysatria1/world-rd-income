# /// script
# requires-python = ">=3.13"
# dependencies = ["pymupdf==1.26.7", "pillow==12.0.0"]
# ///
"""Inventory every existing workspace PDF, deduplicate bytes, extract every page.

Generated brief/methods PDFs are excluded on subsequent runs. Extraction is not
labelled as intellectual full-text review; the companion reading ledger records it.
"""
from pathlib import Path
import csv
import hashlib
import json
import re
import textwrap
import fitz
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[2]
OUT = ROOT / "PDF_Review"
OUT.mkdir(exist_ok=True)
rows, hashes = [], {}
for path in sorted(WORKSPACE.rglob("*.pdf")):
    if ROOT in path.parents or path.parent.name == "Methods":
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    relative = path.relative_to(WORKSPACE).as_posix()
    first = digest not in hashes
    ident = hashes.setdefault(digest, f"P{len(hashes)+1:03d}")
    doc = fitz.open(path)
    texts = [page.get_text(sort=True) for page in doc]
    if first:
        (OUT / f"{ident}.txt").write_text(
            f"FILE: {relative}\nTITLE: {doc.metadata.get('title', '')}\n" +
            "\n".join(f"\n--- PAGE {i+1} ---\n{text}" for i, text in enumerate(texts)), encoding="utf-8")
        (OUT / f"{ident}_compact.txt").write_text(
            f"FILE: {relative}\n" + "\n\n".join(textwrap.fill(f"PAGE {i+1}: " + re.sub(r"\s+", " ", text).strip(), width=140)
                                                     for i, text in enumerate(texts)), encoding="utf-8")
    rows.append(dict(id=ident, path=relative, sha256=digest, unique=first,
                     pages=len(doc), characters=sum(map(len,texts)),
                     sparse_pages=";".join(str(i+1) for i,t in enumerate(texts) if len(t.strip())<100),
                     title=doc.metadata.get("title", "")))
    if path.parent == WORKSPACE:
        thumbs=[]
        for i,page in enumerate(doc):
            pix=page.get_pixmap(matrix=fitz.Matrix(.33,.33),alpha=False)
            im=Image.frombytes("RGB",[pix.width,pix.height],pix.samples)
            im.thumbnail((290,220))
            thumb=Image.new("RGB",(310,250),"white")
            thumb.paste(im,((310-im.width)//2,24))
            ImageDraw.Draw(thumb).text((8,5),f"{ident} page {i+1}",fill="black")
            thumbs.append(thumb)
        for start in range(0,len(thumbs),24):
            batch=thumbs[start:start+24]
            sheet=Image.new("RGB",(1240,250*((len(batch)+3)//4)),"#ccd3d8")
            for j,im in enumerate(batch): sheet.paste(im,((j%4)*310,(j//4)*250))
            sheet.save(OUT/f"{ident}_contact_{start//24+1}.jpg")
    doc.close()
with (OUT/"Inventory.csv").open("w",newline="",encoding="utf-8-sig") as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
summary=dict(files=len(rows),unique_files=len(hashes),pages_including_duplicates=sum(r["pages"] for r in rows),
             unique_pages=sum(r["pages"] for r in rows if r["unique"]),
             unique_characters=sum(r["characters"] for r in rows if r["unique"]))
(OUT/"Inventory_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print(json.dumps(summary,indent=2))
for r in rows:
    if r["unique"]: print(f'{r["id"]}: {r["pages"]} pages; {r["characters"]} chars; {r["path"]}')
