# /// script
# requires-python = ">=3.13"
# dependencies = ["python-docx==1.2.0", "reportlab==5.1.0", "matplotlib==3.11.2", "pillow==12.0.0", "pymupdf==1.26.7"]
# ///
"""Typeset matching policy brief and teaching guide, preserving explicit pages."""
from pathlib import Path
from html import escape
import json
import re
import matplotlib
from PIL import Image as PILImage, ImageDraw
import pymupdf
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate, Paragraph, Image, Table, TableStyle, Spacer, PageBreak, KeepTogether

ROOT=Path(__file__).resolve().parent
TEAL,INK,MUTED,PALE="176B83","203342","586976","EDF4F6"
TOKEN=r"(\*\*.+?\*\*|(?<!\w)\*(?!\*)\S.*?\*(?!\w)|`[^`]+`|https?://[^\s]+)"
def markup(text):
    out=[]
    for token in re.split(TOKEN,text):
        if token.startswith("**"): out.append("<b>"+markup(token[2:-2])+"</b>")
        elif token.startswith("*") and token.endswith("*"): out.append("<i>"+markup(token[1:-1])+"</i>")
        elif token.startswith("http"):
            url=token.rstrip(".,;")
            out.append(f'<link href="{escape(url,quote=True)}" color="#{TEAL}">{escape(url)}</link>'+escape(token[len(url):]))
        else: out.append(escape(token[1:-1] if token.startswith("`") else token))
    return "".join(out)
def word_inline(p,text,bold=False,italic=False):
    for token in re.split(TOKEN,text):
        if not token: continue
        if token.startswith("**"): word_inline(p,token[2:-2],True,italic)
        elif token.startswith("*") and token.endswith("*"): word_inline(p,token[1:-1],bold,True)
        elif token.startswith("http"):
            url=token.rstrip(".,;");link=OxmlElement("w:hyperlink")
            link.set(qn("r:id"),p.part.relate_to(url,RT.HYPERLINK,is_external=True))
            r=OxmlElement("w:r");pr=OxmlElement("w:rPr");colour=OxmlElement("w:color");colour.set(qn("w:val"),TEAL)
            pr.append(colour);r.append(pr);t=OxmlElement("w:t");t.text=url;r.append(t);link.append(r);p._p.append(link)
            p.add_run(token[len(url):])
        else:
            r=p.add_run(token[1:-1] if token.startswith("`") else token);r.bold=bold;r.italic=italic
def parse(text):
    lines=text.splitlines();blocks=[];i=0
    while i<len(lines):
        line=lines[i].strip();i+=1
        if not line: continue
        if line=="<!-- PAGEBREAK -->": blocks.append(("break",None));continue
        if line.startswith("!["):
            m=re.fullmatch(r"!\[([^\]]+)\]\(([^)]+)\)",line);assert m
            while not lines[i].strip(): i+=1
            assert lines[i].startswith("*Figure ")
            blocks.append(("figure",(m[1],m[2],lines[i][1:-1])));i+=1;continue
        if line.startswith("|"):
            rows=[]
            while True:
                row=[c.strip() for c in line.strip("|").split("|")]
                if not all(re.fullmatch(r":?-+:?",c) for c in row): rows.append(row)
                if i==len(lines) or not lines[i].startswith("|"): break
                line=lines[i].strip();i+=1
            blocks.append(("table",rows));continue
        kind="body"
        for prefix,label in [("### ","h2"),("## ","h1"),("# ","title"),("> ","equation"),("- ","bullet")]:
            if line.startswith(prefix): kind,line=label,line[len(prefix):];break
        if line.startswith("**Table "): kind="tabletitle"
        elif line.startswith("*Notes:"): kind="caption"
        elif re.match(r"^\[\d+\] ",line): kind="reference"
        elif kind=="body" and len(blocks)==1: kind="subtitle"
        blocks.append((kind,line))
    return blocks

fontpath=Path(matplotlib.get_data_path())/"fonts/ttf"
for suffix,name in [("","DejaVuSans.ttf"),("-Bold","DejaVuSans-Bold.ttf"),("-Italic","DejaVuSans-Oblique.ttf"),("-BoldItalic","DejaVuSans-BoldOblique.ttf")]:
    pdfmetrics.registerFont(TTFont("Brief"+suffix,str(fontpath/name)))
pdfmetrics.registerFontFamily("Brief",normal="Brief",bold="Brief-Bold",italic="Brief-Italic",boldItalic="Brief-BoldItalic")
MARGIN=44
WIDTH=A4[0]-2*MARGIN
def widths(rows):
    n=len(rows[0])
    if n==6: shares=[.18,.14,.17,.17,.17,.17]
    elif n==4: shares=[.45,.09,.17,.29] if rows[0][1]=="n" else [.39,.19,.20,.22]
    elif n==3: shares=[.32,.34,.34]
    else: shares=[.37,.63] if n==2 else [1/n]*n
    return [WIDTH*x for x in shares]

class PDF(BaseDocTemplate):
    def afterFlowable(self,f):
        if isinstance(f,Paragraph) and f.style.name in ["h1","h2"]:
            key="h"+str(self.seq.nextf("h"));self.canv.bookmarkPage(key)
            self.canv.addOutlineEntry(f.getPlainText(),key,0,False)

reports=[]
for folder,stem,header,body_size in [(ROOT,"Policy_Brief","GLOBAL INNOVATION & PROSPERITY  |  POLICY BRIEF",9.5),
                                    (ROOT.parent/"Methods","Methods_Guide","R&D & PROSPERITY  |  METHODS COMPANION",10.0)]:
    text=(folder/f"{stem}.md").read_text(encoding="utf-8");blocks=parse(text)
    title=blocks[0][1]
    styles={}
    for kind,size,leading in [("body",body_size,body_size*1.38),("bullet",body_size,body_size*1.38),
            ("title",26,29),("subtitle",13,18),("h1",16,21),("h2",11.4,16),
            ("caption",8.0,10.8),("reference",8.9,12.4),("tabletitle",10,14),
            ("equation",9.3,13.4),("cell",8.1,10.7),("cellhead",8.1,10.7)]:
        styles[kind]=ParagraphStyle(kind,fontName="Brief-Bold" if kind in ["title","h1","h2","tabletitle","cellhead"] else "Brief",
            fontSize=size,leading=leading,textColor=colors.HexColor("#"+(TEAL if kind in ["title","h1","h2"] else MUTED if kind in ["caption","subtitle"] else INK)),
            spaceBefore=8 if kind in ["h1","h2"] else 0,spaceAfter=7 if kind not in ["cell","cellhead"] else 0,
            keepWithNext=kind in ["title","subtitle","h1","h2","tabletitle"],allowWidows=0,allowOrphans=0,
            splitLongWords=True,leftIndent=9 if kind=="bullet" else 0,firstLineIndent=-9 if kind=="bullet" else 0)
    styles["cellhead"].textColor=colors.white
    styles["equation"].backColor=colors.HexColor("#"+PALE);styles["equation"].borderPadding=6
    styles["equation"].spaceBefore=5;styles["equation"].spaceAfter=10
    def furniture(canvas,document):
        canvas.saveState();canvas.setFillColor(colors.HexColor("#"+MUTED));canvas.setFont("Brief",7)
        canvas.drawString(MARGIN,A4[1]-24,header)
        canvas.setStrokeColor(colors.HexColor("#"+TEAL));canvas.setLineWidth(.7)
        canvas.line(MARGIN,A4[1]-31,A4[0]-MARGIN,A4[1]-31)
        canvas.drawString(MARGIN,23,"Independent research draft  •  11 November 2026")
        canvas.drawRightString(A4[0]-MARGIN,23,str(document.page));canvas.restoreState()
    pdf=PDF(str(folder/f"{stem}.pdf"),pagesize=A4,title=title,author="",leftMargin=MARGIN,rightMargin=MARGIN,topMargin=44,bottomMargin=42)
    pdf.addPageTemplates(PageTemplate(id="main",frames=[Frame(MARGIN,42,WIDTH,A4[1]-86,leftPadding=0,rightPadding=0,topPadding=0,bottomPadding=0)],onPage=furniture))
    story=[]
    for kind,value in blocks:
        if kind=="break": story.append(PageBreak())
        elif kind=="figure":
            alt,path,caption=value;image=Image(str(folder/path));factor=min(WIDTH/image.drawWidth,260/image.drawHeight)
            image.drawWidth*=factor;image.drawHeight*=factor
            story.append(KeepTogether([image,Spacer(1,5),Paragraph(markup(caption),styles["caption"]),Spacer(1,4)]))
        elif kind=="table":
            cells=[[Paragraph(markup(c),styles["cellhead" if i==0 else "cell"]) for c in row] for i,row in enumerate(value)]
            t=Table(cells,colWidths=widths(value),hAlign="LEFT",repeatRows=1)
            t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#"+TEAL)),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.HexColor("#"+PALE),colors.white]),
                ("VALIGN",(0,0),(-1,-1),"MIDDLE"),("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5)]))
            story.extend([t,Spacer(1,7)])
        else:
            content=("• "+value) if kind=="bullet" else value
            p=Paragraph(markup(content),styles[kind]);story.append(KeepTogether([p]) if kind=="equation" else p)
    pdf.build(story)

    # Editable equivalent with the same content, source links and deliberate page boundaries.
    doc=Document();doc.core_properties.title=title;doc.core_properties.author=""
    section=doc.sections[0];section.page_width=Inches(A4[0]/72);section.page_height=Inches(A4[1]/72)
    section.left_margin=section.right_margin=Inches(MARGIN/72);section.top_margin=Inches(44/72);section.bottom_margin=Inches(42/72)
    section.header_distance=section.footer_distance=Inches(.22)
    for name,size in [("Normal",body_size),("Title",26),("Subtitle",13),("Heading 1",16),("Heading 2",11.4),("Caption",8.0)]:
        style=doc.styles[name];style.font.name="Calibri";style.font.size=Pt(size)
        style.font.color.rgb=RGBColor.from_string(TEAL if name in ["Title","Heading 1","Heading 2"] else INK)
        style.paragraph_format.space_after=Pt(7);style.paragraph_format.line_spacing=1.08
        style.paragraph_format.widow_control=True
        style.paragraph_format.keep_with_next=name in ["Title","Subtitle","Heading 1","Heading 2"]
    head=section.header.paragraphs[0];head.text=header;head.style="Caption"
    foot=section.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    foot.add_run("Independent research draft  |  ").font.size=Pt(8)
    page=OxmlElement("w:fldSimple");page.set(qn("w:instr"),"PAGE");foot._p.append(page)
    for kind,value in blocks:
        if kind=="break": doc.add_page_break()
        elif kind=="figure":
            alt,path,caption=value;p=doc.add_paragraph();p.paragraph_format.keep_with_next=True;p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            w,h=PILImage.open(folder/path).size;width=min(WIDTH/72,260/72*w/h)
            picture=p.add_run().add_picture(str(folder/path),width=Inches(width));picture._inline.docPr.set("descr",alt)
            word_inline(doc.add_paragraph(style="Caption"),caption)
        elif kind=="table":
            t=doc.add_table(rows=0,cols=len(value[0]));t.autofit=False
            for col,w in zip(t.columns,widths(value)): col.width=Pt(w)
            for i,row in enumerate(value):
                cells=t.add_row().cells;pr=t.rows[-1]._tr.get_or_add_trPr();pr.append(OxmlElement("w:cantSplit"))
                if i==0: pr.append(OxmlElement("w:tblHeader"))
                for cell,c,w in zip(cells,row,widths(value)):
                    cell.width=Pt(w);p=cell.paragraphs[0];p.paragraph_format.space_after=Pt(4);p.paragraph_format.space_before=Pt(4)
                    word_inline(p,c,bold=i==0)
                    for r in p.runs: r.font.size=Pt(8.1);r.font.color.rgb=RGBColor.from_string("FFFFFF" if i==0 else INK)
                    shade=OxmlElement("w:shd");shade.set(qn("w:fill"),TEAL if i==0 else PALE if i%2 else "FFFFFF");cell._tc.get_or_add_tcPr().append(shade)
        else:
            p=doc.add_paragraph(style={"title":"Title","subtitle":"Subtitle","h1":"Heading 1","h2":"Heading 2","caption":"Caption"}.get(kind,"Normal"))
            p.paragraph_format.keep_with_next=kind in ["title","subtitle","h1","h2","tabletitle"]
            word_inline(p,("• "+value) if kind=="bullet" else value)
            if kind in ["equation","reference"]:
                for r in p.runs: r.font.size=Pt(9.3 if kind=="equation" else 8.9)
    doc.save(folder/f"{stem}.docx")
    with pymupdf.open(folder/f"{stem}.pdf") as f:
        pages=[];thumbs=[]
        for i,page in enumerate(f):
            pix=page.get_pixmap(matrix=pymupdf.Matrix(.65,.65),alpha=False)
            im=PILImage.frombytes("RGB",[pix.width,pix.height],pix.samples)
            tile=PILImage.new("RGB",(410,580),"white");im.thumbnail((390,550));tile.paste(im,((410-im.width)//2,20))
            ImageDraw.Draw(tile).text((10,3),f"Page {i+1}",fill="black");thumbs.append(tile)
            pages.append(dict(page=i+1,characters=len(page.get_text()),first_lines=page.get_text().splitlines()[3:6]))
        for start in range(0,len(thumbs),6):
            batch=thumbs[start:start+6];sheet=PILImage.new("RGB",(1230,580*((len(batch)+2)//3)),"#D8E0E4")
            for j,tile in enumerate(batch):sheet.paste(tile,((j%3)*410,(j//3)*580))
            sheet.save(folder/f"{stem}_contact_{start//6+1}.jpg")
        reports.append(dict(document=stem,pages=len(f),planned_pages=1+sum(k=="break" for k,v in blocks),page_details=pages,
                            figures=sum(k=="figure" for k,v in blocks),tables=sum(k=="table" for k,v in blocks)))
(ROOT/"Data/document_layout.json").write_text(json.dumps(reports,indent=2,ensure_ascii=False),encoding="utf-8")
print(json.dumps(reports,indent=2,ensure_ascii=True))
