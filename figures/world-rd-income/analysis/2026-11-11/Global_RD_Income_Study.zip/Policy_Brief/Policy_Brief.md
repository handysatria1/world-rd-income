# Beyond the R&D target

**Global patterns in innovation systems and prosperity**

Policy brief | 11 November 2026 | Matched reference year: 2022

## Key messages

- **R&D and prosperity are positively related, but a spending share is an incomplete benchmark.** Across 83 economies, the rank correlation is 0.701. Among 120 pairs with closely comparable R&D intensities, 47 have at least a twofold income difference.
- **Capabilities matter to the interpretation.** Human capital, connectivity, government effectiveness and scientific capacity have strong income associations after adjusting for R&D intensity. These are development signals, not estimated policy returns.
- **Industrial structure changes the spending benchmark.** Manufacturing is overrepresented in business R&D in all 19 eligible economies. Yet R&D is more concentrated than production within manufacturing in only 7 of 19.
- **Compare systems through their functions and outcomes.** Basque Country–Singapore, Korea–UK and US–China illuminate different scales, production structures and research portfolios. None is a strict near-intensity pair.

![Global R&D intensity and PPP income](Figures/Figure_1_global.png)
*Figure 1. A positive global relationship with substantial dispersion. Grey points: 83 economies. Coloured national points belong to that sample; the open diamond adds Basque Country as a regional illustration. Basque PPP uses Spain's national conversion factor. The fitted line models log income; it excludes Basque Country. Source: frozen project data [17], OECD/World Bank and Eustat inputs.*

National spending targets capture ambition, but not the whole route from research to prosperity. That route runs through research capacity, knowledge, adoption, commercial use and domestic value added. Accumulated skills, investment, resource income and cross-border production also influence GDP per person. An imperfect spending–income relationship therefore calls for a broader diagnostic, rather than a conclusion that research has no benefits.

<!-- PAGEBREAK -->

## 1. What the global evidence supports

A regression of natural-log PPP GDP per person on GERD/GDP has R² = 0.285. This describes variation in the 2022 sample; it is not the share of income caused by R&D. Functional form matters: using log(1 + R&D intensity) raises R² to 0.390. Nevertheless, dispersion remains. Under the joint near-intensity rule—at most 0.15 percentage points and 10% relative difference—the median higher-to-lower income ratio is 1.57. The 120 pairs overlap and are not independent experiments.

![Conditional capability and structure associations](Figures/Figure_2_capabilities.png)
*Figure 2. Partial correlations with log PPP income, controlling linear GERD/GDP; approximate pointwise 95% intervals. Each row refits both residual regressions on its own complete-case sample. Different samples limit comparisons between rows. HCI is from 2020; other displayed observations are 2022. Log1p means log(1 + indicator). Sources: Global/Data/income_correlations.csv and underlying official series.*

**Capabilities provide the clearest measured signals.** On a fixed sample of 79 economies, adding internet use, human capital and government effectiveness reduces leave-one-economy-out prediction error from 0.615 to 0.303 log-income units. On 70 common economies, the partial correlations are 0.777 for articles per million, 0.612 for researchers per million and 0.258 for resident patent applications per million. These counts measure different activities and are not quality-adjusted innovation scores.

This is consistent with research-assisted learning, diffusion and complementary capabilities [5–8,15]. It is also consistent with reverse causality: prosperous economies can finance better skills, research and institutions. Publications and capabilities overlap substantially; adding publications to a capability model on 77 common economies changes prediction error only from 0.307 to 0.296. Their explanatory contributions cannot be added as separate causes of income.

<!-- PAGEBREAK -->

## 2. Production structure: a benchmark, not a universal recipe

Manufacturing's share of business R&D exceeds its share of total GVA in **all 19 eligible economies**. The respective medians are **50.11% and 17.75%**. This supports a systematic connection between manufacturing and measured business research [2,4]. It does not establish that shifting production into manufacturing will raise national income.

![Concentration and common-weight manufacturing benchmarks](Figures/Figure_3_structure.png)
*Figure 3. A: concentration within the same five manufacturing groups; points above the diagonal have a higher R&D HHI than GVA HHI. B: selected observed and common-weight manufacturing BERD/GVA ratios; the weights are averaged across all 19 eligible economies. Both panels exclude incomplete or source-ineligible ratios. Sources: frozen research-group accounts; Policy_Brief/Data.*

**Two concentration claims must be distinguished.** Manufacturing is research-heavy relative to the whole economy. Within manufacturing, however, R&D is more concentrated than GVA in only 7 of 19 economies. The five-group aggregation can conceal finer specialisation; it cannot support the stronger claim that research is always more concentrated than production.

**Sector size and research effort both affect aggregate intensity.** Holding within-group BERD/GVA fixed and assigning common manufacturing GVA weights changes the US benchmark from 13.20% to 10.60%, Finland's from 7.18% to 5.87%, and Türkiye's from 2.67% to 6.15%. This is an accounting counterfactual [3], not a simulation of economic restructuring.

**Table 1. Sectoral GVA per employed person: within-economy comparisons**

| Sector comparison | First sector higher | Median ratio |
| --- | --- | --- |
| MHT/LMT | 47/53 | 1.468× |
| KIS/LIS | 43/53 | 1.242× |

*Notes: Ratios use nominal GVA per employed person within each economy; exchange-rate factors cancel. MHT = ISIC 20, 21, 26–30; custom KIS = J, K, M, P. LMT and LIS are the project's comparison groups. These are not sector-specific PPP comparisons, hourly productivity or causal gains from moving workers.*

The sectoral differences are common, but do not identify a universal prosperity strategy. The fixed 34-economy structure/funding model worsens held-out prediction error from 0.435 to 0.549. Broad sector shares are useful for interpreting research inputs; their additional income-predictive content is weak on this smaller sample.

<!-- PAGEBREAK -->

## 3. Three illustrative comparisons in global perspective

The requested cases span a region, a city-state and large national economies. They illustrate mechanisms across Western and Eastern settings; they do not estimate an East–West effect. Their R&D gaps are **0.261 pp** for Basque Country–Singapore, **2.066 pp** for Korea–UK and **0.990 pp** for US–China. All fail the strict near-intensity rule.

**Table 2. Matched 2022 production and research profiles**

| Economy | R&D/GDP % | PPP/person $ | Mfg/GVA % | MHT/GVA % | MHT/exports % |
| --- | --- | --- | --- | --- | --- |
| Basque* | 2.07 | 70,785 | 21.40 | 7.22 | 46.33 |
| Singapore | 1.81 | 144,418 | 20.64 | 17.21 | 67.26 |
| Korea | 4.85 | 55,509 | 29.27 | 18.65 | 73.03 |
| UK | 2.78 | 60,267 | 9.34 | 4.25 | 46.53 |
| US | 3.48 | 78,009 | 11.54 | 5.97 | 49.86 |
| China | 2.49 | 23,028 | 28.87 | 11.38 | 58.75 |

*Notes: Income = current international dollars at GDP PPP. Basque Country is a region; its PPP value is a Spain-national-price proxy, not a regional price estimate. All industry shares use GVA, while export shares use gross goods exports. “—” means unavailable or comparability-excluded, not zero. Sources and full precision: six_case_profiles_2022.csv; additional scope notes in Comparability.md.*

### Basque Country–Singapore: similar manufacturing shares, different systems

Manufacturing represents 21.40% of Basque GVA and 20.64% of Singapore GVA. Yet MHT accounts for 7.22% versus 17.21% of total GVA, and 46.33% versus 67.26% of goods exports. Even a similar manufacturing share can conceal a different industrial mix. Singapore's PPP GDP per person is 2.04 times the Basque proxy, but this comparison combines different economic boundaries and price assumptions.

Business finances 55.92% and 59.19% of R&D, respectively. Broad funding shares therefore do not uniquely describe institutional organisation. Basque evidence documents government-led priority setting followed by stakeholder co-led implementation involving firms, clusters, technology centres and universities [11]. Singapore's A*STAR programmes illustrate public research capacity connected to firms through technical services and personnel [13; programme sources in the evidence review]. Neither description identifies the cause of the income difference.

### Korea–UK: a much larger research share, a smaller income difference

Korea spends 4.85% of GDP on R&D against the UK's 2.78%, while UK PPP income is 8.57% higher. Korea has a larger manufacturing base and higher manufacturing BERD/GVA. An exact accounting decomposition of **manufacturing BERD / whole-economy GVA** attributes the 3.008 pp Korea–UK gap to 2.118 pp of composition and 0.889 pp of within-group intensity. This decomposes a research ratio, not their income gap.

<!-- PAGEBREAK -->

### US–China: research intensity, production scale and value capture

US PPP GDP per person is 3.39 times China's, while GERD/GDP is 3.48% versus 2.49%. China has a larger manufacturing share of GVA, 28.87% against 11.54%, but lower manufacturing BERD/GVA, 5.56% against 13.20%. These opposing components nearly offset in manufacturing BERD relative to whole-economy GVA: the US-minus-China gap is −0.083 pp, consisting of −1.246 pp composition and +1.163 pp within-group intensity.

**A patent count is not a measure of captured income.** China has approximately 1,037 resident applications per million against 819 in the US; the US has more researchers and scientific articles per million. Application coverage, legal practices, field, quality and subsequent commercial use matter. Gross MHT exports likewise cannot reveal domestic value added, imported content or ownership of complementary assets [9,18].

![Funders and performers across six illustrative cases](Figures/Figure_4_funding.png)
*Figure 4. Funding source and performer are separate dimensions of R&D. Basque business performance includes private non-profit performers and must not be read as a pure business share. Grey retains other or unreported components; missing source cells remain missing in the data. National and regional accounting boundaries differ. Source: frozen funding–performer cube, 2022.*

Business performs 78.32% of US R&D and 77.57% of China's. Similar performer shares therefore coexist with very different income, within-industry intensity and research portfolios. Public funding can support business-performed work; public performance is not synonymous with public funding.

The distinction also matters for intermediary policy. UK Catapults provide shared facilities, demonstrators and collaborative services [12]. Fraunhofer combines institutional capacity with competitive public and private contracts; its firm-level evaluation provides outcome evidence under specific instrumental-variable assumptions [19]. These organisational examples supply mechanisms to investigate, rather than national-effectiveness rankings.

<!-- PAGEBREAK -->

## 4. Research portfolios: a hypothesis that needs qualification

The presentations suggest that links between public and business research may help explain translation into prosperity. The comparable quantitative test here is narrower: the distance between **government-performed and business-performed** basic/applied/development portfolios. It excludes higher education from the government side and does not measure organisational collaboration.

![Government and business research portfolios](Figures/Figure_5_portfolios.png)
*Figure 5. Experimental development as a share of observed basic/applied/development spending, normalised separately for each performer. All three types must be present and together cover at least 90% of the reported performer total. n = 26; Basque Country is unavailable. The diagonal means equal development shares, not equal total portfolios. Source: government_business_portfolios.csv.*

Among the cases, Singapore's business/government development shares are 50.25%/57.22%, compared with China's 95.93%/47.47%. Yet the full three-type distance has a weak income association after R&D adjustment, **r = −0.091, n = 26**, with an approximate 95% interval spanning −0.470 to 0.315. Similarity is not established as a global prosperity rule; different research missions may require complementary rather than identical portfolios.

**Table 3. Additional exploratory global tests**

| Indicator | n | Partial r | 95% interval |
| --- | --- | --- | --- |
| Manufacturing R&D HHI | 19 | 0.184 | [-0.309, 0.599] |
| Manufacturing R&D–GVA distance | 19 | -0.154 | [-0.579, 0.337] |
| Government–business type distance | 26 | -0.091 | [-0.470, 0.315] |
| MHT relative GVA/worker | 53 | 0.171 | [-0.107, 0.424] |
| KIS relative GVA/worker | 53 | -0.268 | [-0.504, 0.005] |

*Notes: Outcome is log PPP income; all rows control GERD/GDP. Intervals are approximate pointwise 95% intervals. All include zero; Benjamini–Hochberg q-values for this five-test family range from 0.274 to 0.664. The result means these data do not establish a clear conditional association, not that the mechanisms have been disproved. Population-control sensitivity and exact samples accompany the workbook.*

Field, research type and industry must also be kept distinct. Engineering is a field; development is a type; electronics is an industry. The separate funding–performer, type–performer and field–performer cubes do not reveal which funder paid for which research type. Singapore's RIE survey excludes social sciences and humanities [13], further limiting direct comparisons with broader national coverage.

<!-- PAGEBREAK -->

## 5. Policy implications: broaden the diagnostic

**1. Pair spending targets with capability and diffusion measures.** The strongest global signals concern human capital, connectivity, institutions and scientific capacity. Monitor whether firms can recruit, adopt, manage and scale technology alongside research budgets. These associations motivate programme evaluation; they do not tell policymakers the causal return to an extra unit of any indicator.

**2. Benchmark industry research at comparable structures.** Report GERD/GDP together with sector GVA shares and within-industry BERD/GVA. Common-weight comparisons can reveal whether a low aggregate ratio reflects production composition or low research effort inside comparable industries. The present five groups are a starting point; finer categories and firm data would improve diagnosis.

**3. Evaluate intermediary functions and additional outcomes.** Measure technical problem-solving, testing, adoption, researcher mobility and access to facilities. Link participation to pre-project characteristics and subsequent productivity or value added, using a credible comparison group. A funding share, a contract count or a research-portfolio distance cannot substitute for this evidence [10–12,19].

**4. Track domestic value capture and long-run benefits.** Add domestic-value-added exports, ownership, resident income and knowledge diffusion to patent and publication counts. Singapore's GNI/GDP ratio of 80.63% illustrates why production and resident income differ; GNI itself is not household welfare. Research has delayed and cross-border benefits, so one-year spending–income comparisons should be complemented by longitudinal and programme-level evidence [14–16,18].

### Methods box: how to read the evidence

**Coverage.** The main sample comprises 83 non-overlapping economies with matched 2022 R&D intensity and PPP GDP per person, equally weighted. Basque Country is excluded from national regressions because it overlaps Spain. Statistical availability selects the sample; it is not a census of the world.

**Adjustment.** For each indicator, regress it on R&D intensity; separately regress log income on R&D intensity using exactly the same economies. Correlate the two residuals. A positive result means that economies above the indicator's R&D-based fitted line also tend to be above the income line. It does not hold all other determinants constant or identify a policy effect.

**Checks.** The underlying study reports nonlinear and rank adjustments, population controls, boundary exclusions, common-sample models, leave-one-out prediction and multiple-testing adjustments. Five new tests form a separate exploratory family. Historical growth diagnostics give positive convergence-adjusted R&D estimates, but all three uncertainty intervals include zero.

**Comparability.** GDP differs from basic-price GVA; GERD differs from BERD; gross exports differ from domestic value added. Main data retain frozen provider vintages; HCI is explicitly 2020. Current PPP is used for cross-sectional levels, not intertemporal real growth. Broad classifications, mixed publication vintages and incomplete coverage remain material limitations.

**Bottom line.** R&D intensity is a useful input measure. Prosperity depends on how knowledge is generated, absorbed, deployed and rewarded within a wider economy. This brief supports measuring those links, while preserving the distinction between descriptive patterns, accounting identities and causal evidence.

<!-- PAGEBREAK -->

## Sources and reading basis

This independent draft follows the key-message, figure-led policy structure of Dietrich et al. [1]. Their company-headquarters R&D scoreboard and PCT patent analysis differ from this brief's territorial R&D and resident-application measures. Their “middle-technology trap” cannot be inferred directly from our broader MHT grouping.

All 92 workspace PDF files were inventoried: 78 byte-unique documents, 2,975 unique pages. Text was extracted throughout. All eight presentation texts and the eight-page ifo reference were read; other documents received the targeted, prior-audit or bounded screening reads recorded in PDF_Review/Reading_Ledger.md. Some opening screens contain front matter. Extraction and screening do not mean every page was substantively read. Earlier project charts and manuscripts are analytical history, not independent corroborating sources. Two misnamed downloads were excluded from substantive citation.

[1] Dietrich, A., Dorn, F., Fuest, C., Gros, D., Presidente, G., Mengel, P.-L., and Tirole, J. (2024). Europe's Middle-Technology Trap. *EconPol Forum*, 25(4), 32–39. Full local article text read. https://www.ifo.de/DocDL/econpol-forum-2024-4-dorn-fuest-etal-innovation.pdf

[2] Galindo-Rueda, F., and Verger, F. (2016). OECD Taxonomy of Economic Activities Based on R&D Intensity. *OECD STI Working Papers*, 2016/04. Measurement/classification sections consulted. https://doi.org/10.1787/5jlv73sqqp8r-en

[3] Mathieu, A., and van Pottelsberghe de la Potterie, B. (2010). A Note on the Drivers of R&D Intensity. *Research in World Economy*, 1(1). https://doi.org/10.5430/rwe.v1n1p56

[4] Coad, A., and Vezzani, A. (2019). Three cheers for industry: Is manufacturing linked to R&D, exports, and productivity growth? *Structural Change and Economic Dynamics*, 50, 14–25. Substantive version read: JRC WP 06/2017. https://doi.org/10.1016/j.strueco.2019.04.006

[5] Goñi, E., and Maloney, W. F. (2017). Why don't poor countries do R&D? Varying rates of factor returns across the development process. *European Economic Review*, 94, 126–147. Inspected: World Bank WP 6811 (2014). https://documents.worldbank.org/curated/en/855681468326185477/pdf/WPS6811.pdf

[6] Cirera, X., and Maloney, W. F. (2017). *The Innovation Paradox*. World Bank. Selected capability sections, not a complete book reading. https://doi.org/10.1596/978-1-4648-1160-9

[7] Cohen, W. M., and Levinthal, D. A. (1990). Absorptive capacity: A new perspective on learning and innovation. *Administrative Science Quarterly*, 35, 128–152. Prior substantive source audit. https://doi.org/10.2307/2393553

[8] Comin, D., and Mestieri, M. (2018). If technology has arrived everywhere, why has income diverged? *AEJ: Macroeconomics*, 10, 137–178. Inspected: NBER WP 19010 (2013). https://doi.org/10.1257/mac.20150175

[9] Srholec, M. (2007). High-tech exports from developing countries: A symptom of technology spurts or statistical illusion? *Review of World Economics*, 143, 227–255. https://doi.org/10.1007/s10290-007-0106-z

<!-- PAGEBREAK -->

## Sources and reproducibility, continued

[10] Howells, J. (2006). Intermediation and the role of intermediaries in innovation. *Research Policy*, 35, 715–728. https://doi.org/10.1016/j.respol.2006.03.005

[11] Kleibrink, A., and Magro, E. (2018). The making of responsive innovation policies: varieties of evidence and their contestation in the Basque Country. *Palgrave Communications*, 4, 74. Targeted full-text reading, including implementation and conclusions. https://doi.org/10.1057/s41599-018-0136-2

[12] UK Department for Business, Energy & Industrial Strategy (2021). *Catapult Network Review*. Official organisational and evaluation context. https://assets.publishing.service.gov.uk/media/6065a7a9d3bf7f0c8d06b811/catapult-network-review-april-2021.pdf

[13] A*STAR. *National RIE Survey of Singapore 2023*, plus “Definition of Innovation and R&D activities”. Full extracted local report and definitions note read; used for scope, not to replace 2022 observations. Local source identities: P015 and P026 in the PDF inventory. Official GET-Up/T-Up programme descriptions: https://www.a-star.edu.sg/enterprise/innovation-offerings/programmes-for-smes

[14] Ugur, M., Trushin, E., Solomon, E., and Guidi, F. (2016). R&D and productivity in OECD firms and industries: A hierarchical meta-regression analysis. *Research Policy*, 45, 2069–2086. https://doi.org/10.1016/j.respol.2016.08.001

[15] Griffith, R., Redding, S., and Van Reenen, J. (2004). Mapping the two faces of R&D: Productivity growth in a panel of OECD industries. *Review of Economics and Statistics*, 86, 883–895. Inspected: IFS WP W02/00. https://doi.org/10.1162/0034653043125194

[16] Moretti, E., Steinwender, C., and Van Reenen, J. (2025). The intellectual spoils of war? Defense R&D, productivity, and international spillovers. *Review of Economics and Statistics*, 107, 14–27. Accepted manuscript consulted. https://doi.org/10.1162/rest_a_01293

[17] Satria, H. (2026). *Worldwide R&D and income explorer, 2000–2025*. Frozen project archive and separately archived World Bank supplements. https://handysatria1.github.io/world-rd-income/ Archive SHA-256: `5094ee093f0abd22a335ccaaf5d0da8c8ba5fa0e453244ad6023877901ddc9eb`.

[18] Teece, D. J. (1986). Profiting from technological innovation: Implications for integration, collaboration, licensing and public policy. *Research Policy*, 15, 285–305. https://doi.org/10.1016/0048-7333(86)90027-2

[19] Comin, D., Licht, G., Pellens, M., and Schubert, T. (2019). Do companies benefit from public research organizations? The impact of the Fraunhofer Society in Germany. Working paper. https://doi.org/10.2139/ssrn.3354365 Official financing description: https://www.fraunhofer.de/en/about-fraunhofer/profile-structure/facts-and-figures/finances.html

**Reproduction.** Policy_Brief_Evidence.xlsx contains the new numerical results. Policy_Brief/analyse_brief.py uses frozen inputs and the existing global results; every input hash is recorded. Methods/Methods_Guide.pdf and Worked_Example.xlsx explain the residual calculation, Excel formulas and supervisor questions. The main global manuscript, source provenance, additional sensitivities and validation scripts accompany the portable package.

**Evidence boundaries.** Published mechanism studies retain their actual inspected versions and identification assumptions in Global/Literature_Review.md. Fagerberg–Srholec (2008), Wong–Ho–Singh and Timmer et al. (2014) remain bibliographic/abstract leads where full text was not obtained; slide-only numerical claims from them are not used as verified evidence here.
