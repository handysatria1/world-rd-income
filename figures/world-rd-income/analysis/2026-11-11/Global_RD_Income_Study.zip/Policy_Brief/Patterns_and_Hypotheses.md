# What the data add to the presentations

The presentations motivate hypotheses. The global sample checks whether those case observations generalise. These are exploratory, not preregistered tests.

| Proposition suggested by the material | Global result | Appropriate interpretation |
|---|---|---|
| Higher R&D intensity accompanies prosperity | Spearman 0.701 across 83 economies; linear log-income R² 0.285 | Positive tendency, incomplete ranking; not a causal return |
| Similar R&D can coexist with different income | 120 near-intensity pairs; median ratio 1.575; 47 ratios ≥2 | Genuine dispersion in the selected universe; overlapping pairs |
| Research needs complementary capabilities | Capability model held-out error 0.615→0.303 on 79 fixed economies | Strong conditional/predictive signal; reverse causality remains |
| Outputs describe the system better than spending alone | On 70 common economies: publications r=0.777, researchers 0.612, patents 0.258 after R&D adjustment | Different signals, not policy-return or quality rankings |
| Manufacturing is disproportionately research-intensive | Business R&D share exceeds GVA share in 19/19; medians 50.11% and 17.75% | Supported at broad sector level |
| Research is always more concentrated than production | Manufacturing R&D HHI exceeds GVA HHI in only 7/19 | Not general at the five-group aggregation |
| More concentrated research explains prosperity | Partial r=0.184, n=19; interval includes zero; population adjustment reverses sign | Small-sample result does not establish the proposed relationship |
| A close research–production composition is richer | Portfolio-distance partial r=−0.154, n=19; interval includes zero | No clear conditional support; distance need not be an inefficiency |
| MHT/KIS have higher labour productivity | MHT>LMT in 47/53, median ratio 1.468; custom KIS>LIS in 43/53, median 1.242 | Common within-country nominal differences; no marginal reallocation effect |
| These sector productivity advantages explain richer economies | MHT relative GVA/worker r=0.171; KIS r=−0.268; both intervals include zero | Within-country sector hierarchy is distinct from cross-country income explanation |
| Similar public–business research focus improves translation | Government–business type distance r=−0.091, n=26; interval includes zero | Narrow proxy, no global prosperity rule; higher education excluded |
| Industrial mix accounts for different R&D ratios | Common weights change rankings; Korea–UK gap decomposes 3.008=2.118+0.889 pp | Exact research-ratio accounting; not an income decomposition |
| Business funding/performer shares rank system success | Fixed 34-economy structure/funding prediction worsens 0.435→0.549 | Broad financial shares do not measure intermediary effectiveness |

## How the six cases refine the argument

- **Basque Country–Singapore:** close manufacturing GVA shares conceal different MHT composition. The regional PPP proxy and business/nonprofit aggregation constrain the comparison. Institutional evidence supports a richer governance account than top-down versus bottom-up.
- **Korea–UK:** broadly comparable income coexists with much higher Korean R&D, manufacturing weight and within-manufacturing intensity. This pair is not matched on research intensity.
- **US–China:** manufacturing composition and within-industry research intensity offset in the whole-economy GVA contribution. Different patent/researcher/publication patterns show why counts cannot be treated as interchangeable value-capture measures.

## Connection to the ifo article

Dietrich et al. offer a useful figure-led sequence: input → sector composition → research outputs → policy. This brief follows that structure while asking a global income question and testing broader patterns. Their headquarters-based corporate scoreboard, PCT patent fields and “mid-tech/high-tech” classes differ from territorial BERD, resident applications and the project MHT classification. The available data do not independently establish a middle-technology trap, an East–West effect or a universal intermediary model.

## Next empirical step

A stronger causal study would specify an intervention and link firm/programme participation to pre-treatment capabilities, adoption, domestic value added and subsequent productivity. A credible counterfactual, longer follow-up, knowledge stocks and spillovers are required. The current results help choose questions and improve measurement; they do not quantify causal shares of national income gaps.
