# /// script
# requires-python = ">=3.13"
# dependencies = ["numpy==2.5.4", "pandas==3.1.1", "scipy==1.18.1", "openpyxl==3.1.5", "pymupdf==1.26.7", "python-docx==1.2.0"]
# ///
"""Independent arithmetic/sample and numerical-document checks for research delivery."""
from pathlib import Path
from itertools import combinations
from zipfile import ZipFile
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import numpy as np
import pandas as pd
from scipy import stats
from openpyxl import load_workbook
import pymupdf
from docx import Document

ROOT=Path(__file__).resolve().parent
D,I,G,M=ROOT/"Data",ROOT/"Inputs",ROOT.parent/"Data",ROOT.parent/"Methods"
read=lambda name:pd.read_csv(D/(name+".csv"))
def same(a,b): assert np.allclose(a,b,atol=1e-9,rtol=1e-9,equal_nan=True),(a,b)
d=pd.read_csv(G/"global_countries_2022.csv").set_index("iso3")
assert len(d)==83 and d.index.is_unique and "ES-PV" not in d.index
summary=json.loads((D/"summary.json").read_text())
for r in read("input_manifest").itertuples():
    assert hashlib.sha256((ROOT.parent/r.path).read_bytes()).hexdigest()==r.sha256,r.path

# Global fit and strict pair enumeration, independently through centred moments.
y=np.log(d.ppp);z=d.rd
r=stats.pearsonr(z,y).statistic
same(r*r,summary["baseline"]["r2"])
same(stats.spearmanr(z,y).statistic,summary["baseline"]["spearman"])
ratios=[]
for a,b in combinations(d.itertuples(),2):
    gap=abs(a.rd-b.rd)
    if gap<=.15 and gap/np.mean([a.rd,b.rd])<=.1:ratios.append(max(a.ppp,b.ppp)/min(a.ppp,b.ppp))
assert len(ratios)==120 and sum(v>=2 for v in ratios)==47
same(np.median(ratios),summary["baseline"]["median_pair_income_ratio"])

profiles=read("six_case_profiles_2022").set_index("iso3")
assert list(profiles.index)==["ES-PV","SGP","KOR","GBR","USA","CHN"]
for iso in profiles.index[1:]: same(profiles.loc[iso,["rd","ppp"]].to_numpy(float),d.loc[iso,["rd","ppp"]].to_numpy(float))
b=read("basque_income_provenance").iloc[0]
same(profiles.loc["ES-PV","rd"],100*b.gerd_eur_reported/b.gdp_eur_reported)
same(profiles.loc["ES-PV","ppp"],b.gdp_per_capita_eur_reported/b.eur_per_international_dollar)
assert profiles.loc["ES-PV",["perform_BES","research_ALL_BR","research_ALL_AR","research_ALL_ED"]].isna().all()
assert profiles.loc[["ES-PV","SGP"],"berd_gva_mfg"].isna().all()
exports=read("basque_exports_source").set_index("group")
for group in ["MHT","LMT"]:same(profiles.loc["ES-PV","export_"+group],exports.loc[group,"share_percent"])
same(exports.share_percent.sum(),100)
for row in read("illustrative_pair_audit").itertuples():
    a,b=profiles.loc[row.first],profiles.loc[row.second]
    same(row.absolute_rd_gap_pp,abs(a.rd-b.rd))
    same(row.relative_rd_gap,2*abs(a.rd-b.rd)/(a.rd+b.rd))
    same(row.income_ratio_second_over_first,b.ppp/a.ppp)
    assert not row.strict_near_intensity

# Reconstruct industry quantities from input amounts and approved eligibility.
groups=pd.read_csv(I/"research_group_joined.csv")
groups=groups.loc[groups.iso3.isin(d.index)&groups.group_id.between(3,7)]
c=read("manufacturing_concentration").set_index("iso3")
valid=[];weights=[];intensities={};wholecontrib={}
for iso,q in groups.groupby("iso3"):
    q=q.sort_values("group_id")
    if len(q)!=5 or not(q.berd_coverage.eq("complete")&q.gva_coverage.eq("complete")&q.berd_percent_gva.notna()).all():continue
    valid.append(iso)
    B,V=q.berd_assigned_usd.to_numpy(),q.gva_assigned_usd.to_numpy()
    assert (B>=0).all() and (V>0).all()
    s,t=B/B.sum(),V/V.sum()
    same(c.loc[iso,["berd_hhi","gva_hhi","portfolio_distance"]].to_numpy(float),[sum(s*s),sum(t*t),sum(abs(s-t))/2])
    weights.append(t);intensities[iso]=100*B/V
    wholecontrib[iso]=sum(q.gva_share_percent.to_numpy()/100*intensities[iso])
assert set(valid)==set(c.index) and len(valid)==19 and "ROU" not in valid
assert int((c.berd_hhi>c.gva_hhi).sum())==7
common=np.array(weights).mean(axis=0)
same(common.sum(),1)
same(common,read("common_manufacturing_weights").mean_gva_weight)
std=read("manufacturing_standardisation").set_index("iso3")
for iso in valid: same(std.loc[iso,"common_structure"],np.dot(common,intensities[iso]))
shares=read("manufacturing_research_production_shares").set_index("iso3")
assert set(shares.index)==set(valid) and (shares.berd_share_mfg>shares.gva_mfg).all()
for row in read("manufacturing_accounting_decomposition").itertuples():
    a,b=row.pair.split(" minus ")
    same(row.gap_pp,wholecontrib[a]-wholecontrib[b])
    same(row.gap_pp,row.composition_pp+row.within_group_intensity_pp)

p=read("sector_productivity_relative")
same(p.relative_gva_per_worker,p.gva_per_person_usd_thousand/p.economy_gva_per_person_usd_thousand)
wide=p.pivot(index="iso3",columns="group",values="relative_gva_per_worker")
for row in read("sector_productivity_comparisons").itertuples():
    a,b=row.comparison.split("/");q=wide[[a,b]].dropna()
    assert len(q)==row.n and (q[a]>q[b]).sum()==row.first_higher and set(q.index)==set(row.countries.split(";"))
    same((q[a]/q[b]).median(),row.median_ratio)

pf=read("government_business_portfolios").set_index("iso3")
assert len(pf)==26 and "ES-PV" not in pf.index
for iso,row in pf.iterrows():
    b=d.loc[iso,[f"research_BES_{k}" for k in ["BR","AR","ED"]]].to_numpy(float)
    g=d.loc[iso,[f"research_GOV_{k}" for k in ["BR","AR","ED"]]].to_numpy(float)
    assert min(b.sum(),g.sum())>=90 and max(b.sum(),g.sum())<=100.001
    same([row.business_three_type_coverage,row.government_three_type_coverage],[b.sum(),g.sum()])
    same(row.distance,sum(abs(b/b.sum()-g/g.sum()))/2)
    same([row.business_ed,row.government_ed],[100*b[-1]/b.sum(),100*g[-1]/g.sum()])

# One-control closed-form correlation and inverse-covariance two-control check.
tests=read("additional_global_tests")
vectors=[c.berd_hhi,c.portfolio_distance,pf.distance,wide.MHT,wide.KIS]
for row,v in zip(tests.itertuples(),vectors):
    q=d[["rd","ppp","population"]].join(v.rename("x")).dropna()
    assert len(q)==row.n and list(q.index)==row.countries.split(";")
    matrix=np.corrcoef(np.array([q.x,np.log(q.ppp),q.rd]))
    xy,xz,yz=matrix[0,1],matrix[0,2],matrix[1,2]
    r=(xy-xz*yz)/np.sqrt((1-xz*xz)*(1-yz*yz));same(r,row.partial_rd)
    precision=np.linalg.inv(np.corrcoef(np.array([q.x,np.log(q.ppp),q.rd,np.log(q.population)])))
    same(-precision[0,1]/np.sqrt(precision[0,0]*precision[1,1]),row.partial_rd_population)
    same(np.tanh(np.arctanh(r)+np.array([-1,1])*1.96/np.sqrt(len(q)-4)),[row.ci_low,row.ci_high])
    assert row.ci_low<0<row.ci_high
same(tests.bh_q,stats.false_discovery_control(tests.p,method="bh"))

# Teaching example: direct centred slopes instead of least-squares implementation.
res=pd.read_csv(M/"Residuals.csv")
calc=json.loads((M/"Calculation_Checks.json").read_text())
assert len(res)==80 and set(d.index)-set(res.iso3)=={"MMR","SYR","TKM"}
for actual,fitted,residual in [(res.internet,"internet_fitted","internet_residual_pp"),(np.log(res.ppp),"log_ppp_fitted","log_ppp_residual")]:
    slope=((res.rd-res.rd.mean())*(actual-actual.mean())).sum()/((res.rd-res.rd.mean())**2).sum()
    pred=actual.mean()+slope*(res.rd-res.rd.mean())
    same(res[fitted],pred);same(res[residual],actual-pred)
same(np.corrcoef(res.internet_residual_pp,res.log_ppp_residual)[0,1],calc["partial_r"])
assert calc["checks"]["excel_formulas_executed"] is False
wb=load_workbook(M/"Worked_Example.xlsx",data_only=False)
assert wb["Summary"]["C15"].value=="=CORREL(Data_and_residuals!$H$2:$H$81,Data_and_residuals!$J$2:$J$81)"
same(wb["Summary"]["B15"].value,calc["partial_r"])
checked=pd.DataFrame(list(wb["Values_checked"].values)[1:],columns=res.columns)
same(checked.iloc[:,2:].to_numpy(float),res.iloc[:,2:].to_numpy(float));wb.close()

wb=load_workbook(ROOT/"Policy_Brief_Evidence.xlsx",data_only=True)
for path in sorted(D.glob("*.csv")):
    frame=pd.read_csv(path)
    sheet=wb[path.stem[:31]]
    assert sheet.max_row==len(frame)+1 and sheet.max_column==len(frame.columns),path.name
    for i,col in enumerate(frame.columns,1):
        assert sheet.cell(1,i).value==col
        if pd.api.types.is_numeric_dtype(frame[col]) and not pd.api.types.is_bool_dtype(frame[col]):
            saved=[sheet.cell(j,i).value if sheet.cell(j,i).value is not None else np.nan for j in range(2,len(frame)+2)]
            same(saved,frame[col].to_numpy(float))
wb.close()

# Assert the most important prose claims against source tables as rounded display strings.
brief=(ROOT/"Policy_Brief.md").read_text(encoding="utf-8")
guide=(M/"Methods_Guide.md").read_text(encoding="utf-8")
models=pd.read_csv(G/"income_models.csv").set_index("model")
commoncorr=pd.read_csv(G/"common_sample_correlations.csv")
claim_tokens=[f'{summary["baseline"]["r2"]:.3f}',f'{summary["baseline"]["spearman"]:.3f}',
              f'{shares.berd_share_mfg.median():.2f}',f'{shares.gva_mfg.median():.2f}']
claim_tokens += [f'{models.loc[m,"loo_rmse"]:.3f}' for m in ["capability_0","capability_3","structure_0","structure_3","joint_1","joint_3"]]
claim_tokens += [f'{r.partial_rd:.3f}' for r in commoncorr.loc[commoncorr.family.eq("research_outputs")].itertuples()]
for token in claim_tokens:assert token in brief,token
for token in ["0.736373185","79.849129845","3.968112837","10.126721657","0.295407362","0.615471576","0.823416627"]:
    assert token in guide,token
assert set(map(int,re.findall(r"(?m)^\[(\d+)\] ",brief)))==set(range(1,20))
for term in ["0.261","2.066","0.990","7 of 19","19 eligible","47/53","43/53"]:assert term in brief,term

def normalise(s):return re.sub(r"\s+","",s).replace("*","").replace("`","").replace("−","-")
documents=[]
for folder,stem,expected_pages,expected_tables,expected_figures in [(ROOT,"Policy_Brief",9,3,5),(M,"Methods_Guide",10,7,1)]:
    md=(folder/f"{stem}.md").read_text(encoding="utf-8")
    assert "{{" not in md and "\ufffd" not in md
    for path in re.findall(r"!\[[^\]]+\]\(([^)]+)\)",md):assert (folder/path).is_file()
    with pymupdf.open(folder/f"{stem}.pdf") as pdf:
        assert len(pdf)==expected_pages,(stem,len(pdf))
        pdftext="\n".join(page.get_text() for page in pdf)
        assert "\ufffd" not in pdftext and all(len(page.get_text())>1000 for page in pdf)
        for page in pdf:
            for b in page.get_text("blocks"):
                assert b[0]>=0 and b[1]>=0 and b[2]<=page.rect.width+.2 and b[3]<=page.rect.height+.2,(stem,page.number,b[:4])
        for line in md.splitlines():
            if line.startswith(("## ","### ")):
                assert normalise(line.lstrip("# ")) in normalise(pdftext),(stem,line)
        # Every body/table/caption token must survive PDF generation (figures are images).
        absent=[]
        for line in md.splitlines():
            if not line.strip() or line.startswith(("![","<!--","| ---")):continue
            cleaned=re.sub(r"^[#> -]+","",line).strip("*")
            if line.startswith("|"):
                segments=[c.strip() for c in line.strip("|").split("|")]
            else: segments=[cleaned]
            for segment in segments:
                if normalise(segment) not in normalise(pdftext):absent.append(segment[:100])
        assert not absent,(stem,absent)
    doc=Document(folder/f"{stem}.docx")
    assert len(doc.tables)==expected_tables and len(doc.inline_shapes)==expected_figures
    with ZipFile(folder/f"{stem}.docx") as archive:
        tree=ET.fromstring(archive.read("word/document.xml"));ns={"w":"http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        wordtext="".join(t.text or "" for t in tree.findall(".//w:t",ns))
    for line in md.splitlines():
        if not line.strip() or line.startswith(("![","<!--","| ---")):continue
        if line.startswith("|"):segments=[c.strip() for c in line.strip("|").split("|")]
        else:segments=[re.sub(r"^[#> -]+","",line).strip("*")]
        for segment in segments:assert normalise(segment) in normalise(wordtext),(stem,segment[:80])
    documents.append(dict(document=stem,pages=expected_pages,tables=expected_tables,figures=expected_figures,all_text_verified=True))

ledger=pd.read_csv(ROOT/"PDF_Review/Reading_Ledger.csv")
assert len(ledger)==78 and ledger.id.is_unique and ledger.pages.sum()==2975
inventory=pd.read_csv(ROOT/"PDF_Review/Inventory.csv")
assert len(inventory)==92 and inventory.sha256.nunique()==78
assert set(ledger.id)==set(inventory.id)
assert (ledger.loc[ledger.id.isin(["P053","P058"]),"reading_depth"]=="Identity check + exclusion").all()

report=dict(passed=True,global_economies=83,strict_pairs=120,manufacturing_economies=19,portfolio_economies=26,
            sector_productivity_economies=53,new_tests=5,all_new_pointwise_intervals_include_zero=True,
            independent_partial_formula_checks=True,exact_accounting_checks=True,workbooks_numerically_checked=True,
            excel_formulas_executed=False,pdf_text_and_bounds_checked=True,word_content_checked=True,word_layout_rendered=False,
            documents=documents,pdf_inventory_files=92,unique_reading_ledger_rows=78,all_library_pages_substantively_read=False)
(D/"validation.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
print(json.dumps(report,indent=2))
