# /// script
# requires-python = ">=3.13"
# dependencies = ["pandas==3.1.1"]
# ///
"""Fill publication tables directly from the frozen/reproduced analysis outputs."""
from pathlib import Path
import json
import re
import pandas as pd

ROOT=Path(__file__).resolve().parent
D=ROOT/"Data"
M=ROOT.parent/"Methods"
profiles=pd.read_csv(D/"six_case_profiles_2022.csv").set_index("iso3")
def table(headers,rows):
    return "\n".join(["| "+" | ".join(headers)+" |", "| "+" | ".join(["---"]*len(headers))+" |"]+
                     ["| "+" | ".join(map(str,r))+" |" for r in rows])
def number(v,digits=2): return "—" if pd.isna(v) else f"{v:,.{digits}f}"

names={"ES-PV":"Basque*","SGP":"Singapore","KOR":"Korea","GBR":"UK","USA":"US","CHN":"China"}
case_rows=[]
for code,r in profiles.iterrows():
    case_rows.append([names[code],number(r.rd,2),number(r.ppp,0),number(r.gva_mfg),number(r.gva_MHT),number(r.export_MHT)])
case_table=table(["Economy","R&D/GDP %","PPP/person $","Mfg/GVA %","MHT/GVA %","MHT/exports %"],case_rows)
productivity=pd.read_csv(D/"sector_productivity_comparisons.csv")
productivity_table=table(["Sector comparison","First sector higher","Median ratio"],
    [[r.comparison,f"{r.first_higher}/{r.n}",number(r.median_ratio,3)+"×"] for r in productivity.iloc[:2].itertuples()])
new=pd.read_csv(D/"additional_global_tests.csv")
newlabels=["Manufacturing R&D HHI","Manufacturing R&D–GVA distance","Government–business type distance","MHT relative GVA/worker","KIS relative GVA/worker"]
additional_table=table(["Indicator","n","Partial r","95% interval"],
    [[label,int(r.n),number(r.partial_rd,3),f"[{r.ci_low:.3f}, {r.ci_high:.3f}]"] for label,r in zip(newlabels,new.itertuples())])
pairs=pd.read_csv(D/"illustrative_pair_audit.csv")
pair_table=table(["Pair","R&D gap, pp","Relative gap","Meets both rules?"],
    [[f"{names[r.first]} / {names[r.second]}",number(r.absolute_rd_gap_pp,3),number(100*r.relative_rd_gap,2)+"%","No"] for r in pairs.itertuples()])
calc=json.loads((M/"Calculation_Checks.json").read_text())
casecalc=pd.DataFrame(calc["cases"]).set_index("iso3")
worked_table=table(["Quantity","China","Iceland"],
    [[label,*[number(casecalc.loc[c,key],digits) for c in ["CHN","ISL"]]] for key,label,digits in [
        ("rd","R&D/GDP (%)",6),("internet","Observed internet (%)",6),("ppp","PPP GDP/person ($)",2),
        ("log_ppp","Observed log income",6),("internet_fitted","Fitted internet (%)",6),
        ("internet_residual_pp","Internet residual (pp)",6),("log_ppp_fitted","Fitted log income",6),
        ("log_ppp_residual","Log-income residual",6)]])
for folder,stem,replacements in [(ROOT,"Policy_Brief",dict(CASE_TABLE=case_table,PRODUCTIVITY_TABLE=productivity_table,ADDITIONAL_TABLE=additional_table)),
                                   (M,"Methods_Guide",dict(PAIR_TABLE=pair_table,WORKED_TABLE=worked_table))]:
    text=(folder/f"{stem}.template.md").read_text(encoding="utf-8")
    for key,value in replacements.items(): text=text.replace("{{"+key+"}}",value)
    assert not re.search(r"\{\{[A-Z_]+\}\}",text)
    (folder/f"{stem}.md").write_text(text,encoding="utf-8")

# Extended six-case measurements stay in the transparent supplement, avoiding an oversized brief table.
metrics=[("researchers","Researchers per million",0),("publications_pm","Articles per million",0),
         ("patents_pm","Resident applications per million",0),("research_ALL_BR","Basic research / reported total (%)",2),
         ("research_ALL_AR","Applied research / reported total (%)",2),("research_ALL_ED","Development / reported total (%)",2),
         ("field_ALL_FORD2","Engineering / field total (%)",2),("gva_KIS","Custom KIS / GVA (%)",2),
         ("fund_BES","Business funding / GERD (%)",2),("perform_BES","Business performance / GERD (%)",2),
         ("perform_BES_PNP","Combined business + nonprofit performance (%)",2),("berd_gva_mfg","Manufacturing BERD / manufacturing GVA (%)",2)]
supp=table(["Measure",*[names[i] for i in profiles.index]],
           [[label,*[number(profiles.loc[i,key],digits) for i in profiles.index]] for key,label,digits in metrics])
(D/"Six_Case_Extended_Table.md").write_text("# Six-case measurement supplement\n\n"+supp+"\n\nAll values 2022; unavailable/comparability-excluded cells are —. Research-type and field totals differ. Basque business/nonprofit performers remain combined. Singapore survey scope excludes social sciences/humanities. UK aggregate research types and researcher density are unavailable in this same-year dataset; specific-performer research portfolios are separately available. These counts are not quality-adjusted efficiency measures. See ../Comparability.md.\n",encoding="utf-8")
print("Rendered Policy_Brief.md, Methods_Guide.md and the extended six-case table.")
