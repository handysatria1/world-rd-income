# /// script
# requires-python = ">=3.13"
# dependencies = []
# ///
"""Record documented reading depth; never promote extraction to full reading."""
from pathlib import Path
import csv
import json
import re

ROOT=Path(__file__).resolve().parent/"PDF_Review"
inventory=list(csv.DictReader((ROOT/"Inventory.csv").open(encoding="utf-8-sig")))
unique=[r for r in inventory if r["unique"]=="True"]
prior={
    19:"Selected capability chapters/passages; prior literature audit; not whole-book reading.",
    23:"Main text and industry-standardisation argument; prior literature audit.",
    48:"Introduction, recruitment/randomisation setting and intervention; 2011 working-paper version.",
    49:"Governance, funding and evaluation discussion; prior full-text sections audit.",
    50:"Supplementary official update; bounded screen and prior contextual use.",
    51:"Introduction, data, regressions, diagnostics and interpretation; 2017 WP, not 2019 journal text.",
    52:"Introduction and diffusion-estimation framework; verified NBER 19010 version.",
    54:"Introduction, data, instruments and varying-coefficient results; WB 2014 version.",
    55:"Introduction, levels/accounting logic and instrument discussion; NBER 1998 version.",
    56:"Introduction, model/data and alternative explanations; revised December 2008 WP.",
    57:"Introduction, fragmentation data, regression and conclusions.",
    59:"Introduction, measurement and mechanism sections; verified NBER 15712.",
    60:"Inclusion/estimation, heterogeneity and detailed conclusions; published 2016 text.",
    68:"Prior conceptual/source audit; not newly read page by page.",
    69:"Introduction, matching, generated-IV assumptions and results.",
    70:"Functional typology, case framework and organisation discussion.",
    71:"Abstract, substantive introduction and prior archived context; not all survey tables.",
    73:"Introduction, framework and examples; prior audit.",
    74:"Introduction and narrative identification/timing; archived 2024 WP.",
    75:"Introduction, R&D data, interactions, results and table notes; IFS WP version.",
    76:"Prior-audit background use; not newly read in full.",
    77:"Introduction, defense instrument and main-result interpretation; accepted manuscript.",
    78:"Introduction and complementary-assets/appropriation framework.",
}
themes={
    1:"R&D is one innovation input; motivates conditional comparisons and mechanism tests.",
    2:"Singapore development narrative, research institutions and translation; slide numerics require sources.",
    3:"Singapore high-level system/production comparison; distinguish fields from industries.",
    4:"Basque regional networks and industrial orientation; regional/national comparability matters.",
    5:"US research, sector mix and commercialisation; national outcomes do not identify programme effects.",
    6:"UK services, research and intermediaries; matched vintages and missing UK indicators matter.",
    7:"Cross-case funding, performers, portfolios and production; hypotheses for global tests.",
    8:"Latest cross-case synthesis; concentration/productivity/portfolio claims tested globally.",
    9:"Historical ANBERD source context; no historical table values substituted into 2022 data.",
    10:"Historical ANBERD context; opening screen can be front matter.",
    11:"BERD performer scope, industry assignment and international comparability.",
    12:"Historical ANBERD context; no fresh full table verification.",
    13:"Historical ANBERD context; classification/vintage matters.",
    14:"Historical ANBERD context; classification/vintage matters.",
    15:"Singapore scope excludes social sciences/humanities; 2023 report not 2022 replacement.",
    16:"Historical ANBERD context; publication year is not observation year.",
    17:"Intensity uses value added; activity classifications differ from research fields.",
    18:"Innovation-policy descriptive precedent; screened lead, no numerical inference imported.",
    20:"Style and substantive comparison; scoreboard/PCT measures differ from project data.",
    21:"Science/technology/industry distinctions; screened background lead.",
    22:"Innovation-policy and fiscal mechanisms; screened background, no causal estimate imported.",
    24:"Chinese industry classification; bounded screen only, not independent code-by-code audit.",
    25:"ICIO classification annex; preserve file identity and metadata-vintage inconsistency.",
    26:"R&D/innovation definitions; research fields are not industries.",
    53:"Wrong-paper download: actual title is Exporting and Plant-Level Efficiency Gains; excluded.",
    58:"Wrong-paper download under Syverson filename; excluded under prior identity audit.",
    72:"Innovation is broader than R&D; bounded screen, not a complete manual reading.",
}
screens={}
for path in sorted(ROOT.glob("Screen_*.md")):
    for block in re.split(r"(?m)^## ",path.read_text(encoding="utf-8"))[1:]:
        ident=block.split()[0]
        pages=re.findall(r"(?:Opening|Targeted) screen, PDF p\.(\d+)",block)
        screens[ident]=f'{path.name}: PDF pp. '+", ".join(pages)
records=[]
for row in unique:
    n=int(row["id"][1:]);depth="Bounded screen";basis=screens.get(row["id"],"")
    caveat="Extracted all pages; only bounded excerpts read; opening may be front matter."
    if n<=8:
        depth="Full extracted presentation text + thumbnail inspection"
        basis=f'All {row["pages"]} pages of text; all corresponding contact sheets visually inspected.'
        caveat="Thumbnail inspection cannot verify small chart values; extraction can omit image-only content."
    elif n==20:
        depth="Full extracted article text"
        basis="All eight PDF pages (printed pp. 32–39)."
        caveat="Read substantive text; numerical claims not independently re-estimated."
    elif n in [15,26]:
        depth="Full extracted report/note text"
        basis=f'All {row["pages"]} pages of available text, including scope/definitions.'
        caveat="Report scope checked; this is not a numerical audit of every source table."
    elif n in [11,17]:
        depth="Targeted methodology reading + bounded screen"
        basis+=("; P011_compact.txt lines 145–269, introduction/methodological material." if n==11 else "; PDF pp. 5–9, concept and measurement/taxonomy.")
        caveat="Historical statistical tables / remaining taxonomy appendices not read in full."
    elif n in prior:
        depth="Bounded screen + documented prior substantive reading"
        basis+="; "+prior[n]
        caveat="Exact depth/version in Global/Literature_Review.md section 7; not a new whole-document reading."
    elif n in [53,58]:
        depth="Identity check + exclusion"
        caveat="Not cited as the work implied by its filename."
    elif 27<=n<=47 or n in [61,62,63,64,65,66,67]:
        depth="Bounded screen of project output"
        caveat="Prior project product, not independent empirical evidence or an external publication."
    use=themes.get(n,"Mechanism/background evidence at the depth recorded in the prior review." if n in prior else "Project history; current brief reuses frozen matched-2022 data rather than mixed-year graphics.")
    records.append(dict(id=row["id"],file=Path(row["path"]).name,pages=int(row["pages"]),reading_depth=depth,
                        reading_basis=basis,use_in_brief=use,caveat=caveat,sha256=row["sha256"]))
with (ROOT/"Reading_Ledger.csv").open("w",newline="",encoding="utf-8-sig") as f:
    w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
lines=["# PDF reading ledger", "", "**Snapshot: 11 November 2026.** 92 files; 78 byte-unique documents; 2,975 unique pages. All pages were extracted. The eight top-level presentations contain 232 pages; their full extracted text was read and all 14 contact sheets were inspected at thumbnail resolution.",
       "", "**Reading depth is not extraction coverage.** This ledger does not claim substantive reading of every page. All unique documents received at least bounded screening or a deeper recorded read. Screening bundles are capped opening/targeted excerpts; some are front matter. Missing image text and small graphical details remain limitations. Duplicate paths and page sparsity are retained in Inventory.csv. The original snapshot excludes subsequently generated brief/methods PDFs.",
       "", "The earlier literature audit remains authoritative for exact inspected versions and targeted sections. P053 and P058 are misnamed wrong-paper downloads and are excluded from substantive citation. P025 has a filename referring to 2025 and embedded title metadata referring to 2018; do not infer a new data vintage from its filename alone.",
       "", "| ID | Document / pages | Reading depth and basis | Contribution and boundary |", "| --- | --- | --- | --- |"]
for r in records:
    lines.append(f'| {r["id"]} | {r["file"]} ({r["pages"]} pp.) | {r["reading_depth"]}. {r["reading_basis"]} | {r["use_in_brief"]} {r["caveat"]} |')
lines += ["", "## Additional online sources", "", "Kleibrink–Magro (2018): Basque institutional, policy-design, implementation and conclusion sections read. Its evidence supports government-led design and stakeholder co-led implementation, with contested priorities; not a purely bottom-up model. https://doi.org/10.1057/s41599-018-0136-2", "", "Fagerberg–Srholec (2008): DOI/publication metadata verified, full text not obtained. Wong–Ho–Singh: DOI/publication metadata only; numerical slide claims remain unverified. Timmer et al. (2014): earlier abstract/metadata verification only. These leads are not treated as independently read full texts."]
(ROOT/"Reading_Ledger.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
assert len(records)==78 and sum(r["pages"] for r in records)==2975
print(json.dumps({"files":len(inventory),"unique_ledger_rows":len(records),"unique_pages":2975,"all_pages_substantively_read":False},indent=2))
