# /// script
# requires-python = ">=3.13"
# dependencies = []
# ///
"""Create explicitly bounded reading aids; these are not full-document reviews."""
from pathlib import Path
import csv
import re
import textwrap

ROOT = Path(__file__).resolve().parent / "PDF_Review"
rows = list(csv.DictReader((ROOT / "Inventory.csv").open(encoding="utf-8-sig")))
for lo, hi in [(9,26),(27,47),(48,61),(62,78)]:
    blocks=[]
    for row in rows:
        n=int(row["id"][1:])
        if row["unique"]!="True" or not lo<=n<=hi:
            continue
        text=(ROOT/f'{row["id"]}.txt').read_text(encoding="utf-8")
        pages=re.findall(r"--- PAGE (\d+) ---\n(.*?)(?=\n--- PAGE |\Z)",text,re.S)
        blocks.append(f'## {row["id"]} | {row["pages"]} pages | {row["path"]}')
        # The first substantive page, skipping copyright/contents pages when possible.
        opening=next(((p,t) for p,t in pages if len(t)>1200 and not re.search(r"ISBN|All rights reserved",t[:600])),pages[0])
        p,t=opening
        blocks.append(textwrap.fill(f'Opening screen, PDF p.{p}: '+re.sub(r'\s+',' ',t)[:1400],140))
        candidates=[(p,t) for p,t in pages if re.search(r'(?im)^\s*(?:\d[. ]+)?(?:conclusions?|summary|methodological notes|general notes)\b',t)]
        if candidates and candidates[-1][0]!=p:
            p,t=candidates[-1]
            match=re.search(r'(?im)^\s*(?:\d[. ]+)?(?:conclusions?|summary|methodological notes|general notes)\b',t)
            blocks.append(textwrap.fill(f'Targeted screen, PDF p.{p}: '+re.sub(r'\s+',' ',t[match.start():])[:1800],140))
    (ROOT/f'Screen_{lo:03d}_{hi:03d}.md').write_text('\n\n'.join(blocks),encoding='utf-8')
print('Four bounded screening bundles created; page locators retained.')
