# /// script
# requires-python = ">=3.13"
# dependencies = ["numpy==2.5.4", "pandas==3.1.1", "matplotlib==3.11.2", "openpyxl==3.1.5"]
# ///
"""Teach and independently reproduce the internet row of Figure 3.

Produces an inspectable residual table, an Excel formula workbook and a diagram.
Uses the exact 80-economy row sample; no network access or main-output changes.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.workbook.properties import CalcProperties

ROOT = Path(__file__).resolve().parent
D = ROOT.parent / "Data"
d = pd.read_csv(D / "global_countries_2022.csv").set_index("iso3")
published = pd.read_csv(D / "income_correlations.csv").set_index("metric").loc["internet"]
q = d.loc[published.countries.split(";"), ["economy", "rd", "internet", "ppp"]].copy()
assert len(q) == 80 and q.notna().all().all()
assert set(d.index) - set(q.index) == {"MMR", "SYR", "TKM"}
y, x, z = np.log(q.ppp.to_numpy()), q.internet.to_numpy(), q.rd.to_numpy()
X = np.column_stack([np.ones(len(q)), z])
bx, by = np.linalg.lstsq(X, x, rcond=None)[0], np.linalg.lstsq(X, y, rcond=None)[0]
ex, ey = x - X @ bx, y - X @ by
rxy, rxz, ryz = np.corrcoef(np.column_stack([x, y, z]), rowvar=False)[np.triu_indices(3, 1)]
r = np.corrcoef(ex, ey)[0, 1]
algebraic_r = (rxy - rxz * ryz) / np.sqrt((1 - rxz**2) * (1 - ryz**2))
se = 1 / np.sqrt(len(q) - 4)  # n - k - 3; one control, k=1
fisher = np.arctanh(r)
ci = np.tanh(fisher + np.array([-1, 1]) * 1.96 * se)
t = r * np.sqrt((len(q) - 3) / (1 - r**2))
alternative_X = np.column_stack([np.ones(len(q)), np.log1p(z)])
ax = x - alternative_X @ np.linalg.lstsq(alternative_X, x, rcond=None)[0]
ay = y - alternative_X @ np.linalg.lstsq(alternative_X, y, rcond=None)[0]
alternative_r = np.corrcoef(ax, ay)[0, 1]
full = np.linalg.lstsq(np.column_stack([X, x]), y, rcond=None)[0]
residual_slope = ex @ ey / (ex @ ex)
assert np.allclose([r, rxy, rxz, alternative_r, *ci],
                   [published.partial_rd, published.pearson, published.corr_rd,
                    published.partial_logrd, published.ci_low, published.ci_high], atol=1e-12)
assert np.allclose(r, algebraic_r, atol=1e-12)
assert np.allclose(full[-1], residual_slope, atol=1e-12)
assert np.allclose(X.T @ ex, 0, atol=1e-9) and np.allclose(X.T @ ey, 0, atol=1e-9)

out = q.reset_index()
out["log_ppp"] = y
out["internet_fitted"] = X @ bx
out["internet_residual_pp"] = ex
out["log_ppp_fitted"] = X @ by
out["log_ppp_residual"] = ey
out["ppp_fitted_backtransformed"] = np.exp(X @ by)
out.to_csv(ROOT / "Residuals.csv", index=False)

wb = Workbook()
guide = wb.active
guide.title = "Read_me"
instructions = [
    "Partial correlation: how Figure 3's internet row is calculated",
    "Sample: 80 economies, 2022. R&D/GDP uses percentage-point units: 2.5 means 2.5%, not 0.025.",
    "The outcome is natural-log PPP GDP per capita. Internet use is percentage of population.",
    "Summary column B contains independently calculated Python values; column C contains live Excel formulas.",
    "Data_and_residuals contains the source values and Excel formulas for both fitted values and residuals.",
    "Values_checked contains the same complete numerical table calculated in Python, readable without Excel recalculation.",
    "Excel is set to recalculate on opening. Some previewers do not evaluate formulas; use Values_checked and Summary column B there.",
    "Step 1: fit internet = intercept + slope * R&D; residual = observed internet minus fitted internet.",
    "Step 2: fit log income = intercept + slope * R&D; residual = observed log income minus fitted log income.",
    "Step 3: correlate the two residual columns. The result is 0.736373, Figure 3's blue dot.",
    "The calculation is repeated across all 80 economies, not just the China/Iceland illustration.",
    "The original 83-economy baseline residual columns are not reused: both lines are refitted on this row's 80-economy sample.",
    "The dollar benchmark is exp(fitted log income). It is not an unbiased forecast of arithmetic-mean income or a welfare target.",
    "The interval is an approximate pointwise Fisher interval. It does not cover all measurement/model uncertainty or adjust for 36 tests.",
    "The workbook demonstrates the blue-dot calculation. The companion Python script also verifies the orange log(1 + R&D) check.",
    "Association is not causation. Conditioning on R&D does not identify a total or direct policy effect.",
    "Method reference: Kim (2015), doi:10.5351/CSAM.2015.22.6.665, Section 2, Equation 2.3.",
]
for row, text in enumerate(instructions, 1):
    guide.cell(row, 1, text)
    guide.cell(row, 1).alignment = Alignment(wrap_text=True, vertical="center")
    guide.row_dimensions[row].height = 45
guide.column_dimensions["A"].width = 115
guide.freeze_panes = "A2"

summary = wb.create_sheet("Summary")
summary.append(["Quantity", "Python-verified value", "Live Excel calculation"])
summary.cell(3, 1, "The source sample is identical in all calculations below.")
summary.cell(4, 1, "Open in Excel to recalculate column C; column B is already populated.")
last = len(q) + 1
ref = lambda col: f"Data_and_residuals!${col}$2:${col}${last}"
rows = {
    7: ("Number of economies", len(q), f"=COUNTA({ref('A')})"),
    8: ("Internet intercept", bx[0], f"=INTERCEPT({ref('D')},{ref('C')})"),
    9: ("Internet slope on R&D", bx[1], f"=SLOPE({ref('D')},{ref('C')})"),
    10: ("Log-income intercept", by[0], f"=INTERCEPT({ref('F')},{ref('C')})"),
    11: ("Log-income slope on R&D", by[1], f"=SLOPE({ref('F')},{ref('C')})"),
    12: ("Unadjusted correlation: internet and log income", rxy, f"=CORREL({ref('D')},{ref('F')})"),
    13: ("Correlation: internet and R&D", rxz, f"=CORREL({ref('D')},{ref('C')})"),
    14: ("Correlation: log income and R&D", ryz, f"=CORREL({ref('F')},{ref('C')})"),
    15: ("Partial correlation: two residuals", r, f"=CORREL({ref('H')},{ref('J')})"),
    16: ("Partial correlation: equivalent algebraic formula", algebraic_r, "=(C12-C13*C14)/SQRT((1-C13^2)*(1-C14^2))"),
    17: ("Fisher z transform", fisher, "=ATANH(C15)"),
    18: ("Approximate Fisher z standard error", se, "=1/SQRT(C7-4)"),
    19: ("Approximate 95% interval: lower", ci[0], "=TANH(C17-1.96*C18)"),
    20: ("Approximate 95% interval: upper", ci[1], "=TANH(C17+1.96*C18)"),
    21: ("Conventional partial-correlation t statistic", t, "=C15*SQRT((C7-3)/(1-C15^2))"),
    22: ("Degrees of freedom for the conventional t test", len(q)-3, "=C7-3"),
    23: ("Squared partial r: conditional residual fit only", r**2, "=C15^2"),
}
for row, (label, value, formula) in rows.items():
    summary.cell(row, 1, label)
    summary.cell(row, 2, float(value))
    summary.cell(row, 3, formula)
    summary.cell(row, 2).number_format = summary.cell(row, 3).number_format = "0.000000"
summary.column_dimensions["A"].width = 59
summary.column_dimensions["B"].width = 24
summary.column_dimensions["C"].width = 28
summary.freeze_panes = "B7"

data = wb.create_sheet("Data_and_residuals")
checked = wb.create_sheet("Values_checked")
for sheet in [data, checked]:
    sheet.append(out.columns.tolist())
    sheet.freeze_panes = "C2"
    sheet.auto_filter.ref = f"A1:K{last}"
    for col in "ACDEFGHIJK":
        sheet.column_dimensions[col].width = 24
    sheet.column_dimensions["B"].width = 30
    sheet.row_dimensions[1].height = 36
for i, record in enumerate(out.itertuples(index=False, name=None), 2):
    checked.append(record)
    data.append([*record[:5], f"=LN(E{i})", f"=Summary!$C$8+Summary!$C$9*C{i}",
                 f"=D{i}-G{i}", f"=Summary!$C$10+Summary!$C$11*C{i}", f"=F{i}-I{i}", f"=EXP(I{i})"])
    for sheet in [data, checked]:
        for cell in sheet[i][2:]:
            cell.number_format = "0.000000"
        if record[0] in ["CHN", "ISL"]:
            for cell in sheet[i]:
                cell.fill = PatternFill("solid", fgColor="E2F0F4")
for sheet in wb:
    for cell in sheet[1]:
        cell.fill = PatternFill("solid", fgColor="146B88")
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(wrap_text=True, vertical="center")
wb.calculation = CalcProperties(calcId=0, fullCalcOnLoad=True, forceFullCalc=True)
wb.save(ROOT / "Worked_Example.xlsx")

# Verify the saved numerical sheet and formula references without claiming an Excel calculation run.
reopened = load_workbook(ROOT / "Worked_Example.xlsx", data_only=False)
assert reopened["Values_checked"].max_row == last
saved = pd.DataFrame(list(reopened["Values_checked"].values)[1:], columns=out.columns)
assert np.allclose(saved.iloc[:, 2:].to_numpy(float), out.iloc[:, 2:].to_numpy(float))
assert reopened["Summary"]["C15"].value == f"=CORREL({ref('H')},{ref('J')})"
assert reopened["Data_and_residuals"][f"J{last}"].value == f"=F{last}-I{last}"
reopened.close()

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, axes = plt.subplots(1, 3, figsize=(16, 5.7))
teal, orange = "#146B88", "#D65F24"
grid = np.linspace(0, z.max() + .2, 200)
axes[0].scatter(z, x, color="#9DAAB3", s=25, alpha=.75)
axes[0].plot(grid, bx[0]+bx[1]*grid, color=teal, lw=1.5)
axes[0].set(title="1. Internet use versus R&D", xlabel="R&D / GDP (%)", ylabel="Internet users (% population)")
axes[1].scatter(z, y, color="#9DAAB3", s=25, alpha=.75)
axes[1].plot(grid, by[0]+by[1]*grid, color=teal, lw=1.5)
axes[1].set(title="2. Log income versus R&D", xlabel="R&D / GDP (%)", ylabel="Natural log of PPP GDP per person")
axes[2].scatter(ex, ey, color="#9DAAB3", s=25, alpha=.75)
rg = np.linspace(ex.min()-1, ex.max()+1, 200)
axes[2].plot(rg, residual_slope*rg, color=teal, lw=1.5)
axes[2].axhline(0, color="#657680", lw=.8)
axes[2].axvline(0, color="#657680", lw=.8)
axes[2].set(title=f"3. Correlate the residuals: r = {r:.3f}", xlabel="Internet residual (percentage points)", ylabel="Log-income residual")
for iso, color in [("CHN", orange), ("ISL", teal)]:
    j = q.index.get_loc(iso)
    label = q.loc[iso, "economy"]
    for ax, values, coeff in [(axes[0], x, bx), (axes[1], y, by)]:
        predicted = coeff[0]+coeff[1]*z[j]
        ax.plot([z[j], z[j]], [predicted, values[j]], color=color, ls="--", lw=1.8)
        ax.scatter([z[j]], [values[j]], color=color, s=55, zorder=4)
        ax.scatter([z[j]], [predicted], color=color, marker="x", s=45, zorder=4)
        ax.annotate(label, (z[j], values[j]), xytext=(8, 5 if iso=="ISL" else -13), textcoords="offset points", color=color, fontsize=10, weight="bold")
    axes[2].scatter([ex[j]], [ey[j]], color=color, s=55, zorder=4)
    axes[2].annotate(label, (ex[j], ey[j]), xytext=(7, 7 if iso=="ISL" else -14), textcoords="offset points", color=color, fontsize=10, weight="bold")
fig.suptitle("How adjusting for R&D intensity produces Figure 3's internet result", fontsize=15, weight="bold", y=.98)
fig.text(.5, .04, "All panels use the same 80 economies. Dashed segments in panels 1–2 are observed-minus-fitted residuals.\nPanel 3 correlates those residuals; it does not estimate a causal internet effect.", ha="center", fontsize=10)
fig.tight_layout(rect=(0, .11, 1, .94), w_pad=2)
fig.savefig(ROOT / "Three_Step_Method.png", dpi=180)
plt.close(fig)

report = dict(n=len(q), internet_intercept=bx[0], internet_slope=bx[1],
              log_income_intercept=by[0], log_income_slope=by[1],
              raw_r=rxy, internet_rd_r=rxz, log_income_rd_r=ryz,
              partial_r=r, algebraic_r=algebraic_r, ci_low=ci[0], ci_high=ci[1],
              alternative_log_rd_r=alternative_r, t_statistic=t, t_df=len(q)-3,
              multiple_regression_internet_slope=full[-1], residual_regression_slope=residual_slope,
              source_hashes={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in
                             [D/"global_countries_2022.csv", D/"income_correlations.csv"]},
              checks=dict(matches_figure_row=True, residual_and_algebraic_methods_agree=True,
                          partial_regression_slope_identity=True, saved_workbook_values_checked=True,
                          excel_formulas_executed=False),
              cases=out.loc[out.iso3.isin(["CHN", "ISL"])].to_dict("records"))
(ROOT / "Calculation_Checks.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
