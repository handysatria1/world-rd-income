# Explaining the R&D–prosperity analysis

**A supervisor-ready methods guide with a worked Excel example**

11 November 2026 | Companion to the global study and policy brief

## 1. Your 30-second explanation

> “I use a matched 2022 cross-section of 83 economies to examine how R&D intensity and income vary together. I then ask which additional indicators are associated with income after adjusting for R&D intensity. For each indicator I fit two regressions on exactly the same economies—one for the indicator and one for log income—and correlate their residuals. I also use common-sample prediction checks and accounting decompositions of industry research. These are descriptive diagnostics, not estimates of the causal return to R&D.”

**The main conclusion:** economies with higher R&D intensity tend to be richer, but intensity alone is insufficient to rank prosperity. Capabilities and scientific capacity contain strong additional information. Industrial composition changes research benchmarks. None of those observations means that research has no benefits.

### What question does each calculation answer?

| Calculation | Question answered | What it cannot establish |
| --- | --- | --- |
| Global scatter and R² | How closely are current research intensity and income associated? | The return to an extra research investment |
| Near-intensity pairs | How different are incomes when spending shares are close? | Matched treatment–control effects |
| Partial correlation | Do indicator and income deviations co-vary after the stated R&D adjustment? | A direct or total causal effect |
| Common-sample models | Does adding information improve fit and held-out prediction? | Which policy should be expanded |
| Common industry weights | How much does the intensity benchmark depend on sector mix? | Income gains from restructuring |
| Published studies and cases | Which mechanisms are plausible or evaluated elsewhere? | A causal decomposition of these national income gaps |

### Open these files during the meeting

- **Policy_Brief/Policy_Brief.pdf:** argument and global figures.
- **Methods/Worked_Example.xlsx:** live formulas plus already-calculated numerical values.
- **Methods/Residuals.csv:** every observation used in the internet example.
- **Global/Data/income_correlations.csv:** 36 indicators, exact samples and robustness results.
- **Policy_Brief/Policy_Brief_Evidence.xlsx:** six cases and new global hypothesis tests.

<!-- PAGEBREAK -->

## 2. Definitions and sample choices

**Outcome:** y = ln(PPP GDP per person). “Income” is shorthand for a production measure. GDP/person is not household disposable income, welfare, output per hour or total factor productivity. PPP reduces cross-country price-level differences; current PPP levels are suitable for this cross-section. Historical growth diagnostics instead use constant-PPP income.

**Research intensity:** z = 100 × GERD/GDP. GERD covers domestic research performed across business, government, higher education and private non-profit sectors. In the data, **2.5 means 2.5%, not 0.025**. A movement from 2% to 3% is one percentage point and a 50% relative increase.

**Why logs?** Income is positive and highly skewed. Logs make proportional differences more interpretable and reduce domination by the largest dollar values. The fitted relationship is linear in log income, not dollars. log(1 + density) is used for researcher/publication/patent densities so that observed zeros can remain in the sample. Missing observations never become zero.

**Why 2022?** It is the frozen project's common linked year for national income, R&D and industrial accounts. Matching years avoids calling a 2024 research share a 2022 observation. It does not remove publication-vintage differences or pandemic/commodity conditions. HCI is explicitly 2020. Resource rents use the labelled latest 2020–2022 observation; most are 2021. The main researcher analysis uses 2022, with prior-year observations kept separately.

**Why 83 economies?** They meet the inherited same-year national coverage rules. They are not a random or complete world sample. Each economy gets equal weight, so the estimand is a relationship across economies, not across the world's residents. Log-population adjustment checks sensitivity to size; it is not population weighting.

**Why is Basque Country excluded from regressions?** It overlaps Spain, already in the national universe. It is a regional case, while Singapore is a city-state. Basque PPP GDP/person is €39,587 divided by Spain's PPP factor, 0.55926 EUR per international dollar: approximately $70,784.61. This is a proxy, not a Basque price survey. Its 2.069672% R&D intensity comes from €1,794,704,000 / €86,714,411,000 × 100.

### Keep the denominators visible

| Indicator | Numerator / denominator | Important distinction |
| --- | --- | --- |
| GERD/GDP | All domestic research / GDP | Economy-wide spending share |
| Manufacturing BERD/GVA | Manufacturing business research / manufacturing GVA | Within-manufacturing intensity |
| Manufacturing contribution | Manufacturing BERD / whole-economy GVA | Different from the preceding ratio |
| Industry GVA share | Industry GVA / total covered GVA | Production composition |
| MHT export share | MHT gross goods exports / total goods exports | Not domestic-value-added exports |
| Research type share | Type expenditure / reported research total | Not a funding-source share |

<!-- PAGEBREAK -->

## 3. Global fit and pair selection

The baseline ordinary least-squares regression is:

> yᵢ = α + βzᵢ + εᵢ, where yᵢ = ln(PPP GDP/person) and zᵢ = GERD/GDP in percent.

OLS chooses the intercept and slope to minimise the sum of squared residuals. R² = 1 − SSE/SST = 0.285219 on 83 economies. It means that this fitted line accounts for about 28.5% of the sample variation in log income. **It does not mean that R&D causes 28.5% of income.** Spearman's rank correlation is 0.701293; it describes whether higher-intensity economies tend to rank higher in income without requiring a straight line in levels.

### The strict “similar R&D” rule

> Absolute gap = abs(zₐ − zᵦ) ≤ 0.15 percentage points.

> Relative gap = 2 × abs(zₐ − zᵦ) / (zₐ + zᵦ) ≤ 0.10.

Both conditions must hold. For example, 0.10% and 0.20% differ by only 0.10 pp, but by 66.7% relative to their mean. The relative condition prevents this from being labelled close. These thresholds are transparent analyst choices, not a natural law.

The rule yields 120 pairs; their median higher/lower PPP income ratio is 1.574896, and 47 ratios are at least two. The same economy can appear repeatedly, so 120 pairs are not 120 independent observations. Extreme examples in the global paper are selected within mean-intensity bands; the full distribution prevents those extremes from being presented as typical.

**Table 1. Audit of the user-requested comparisons**

| Pair | R&D gap, pp | Relative gap | Meets both rules? |
| --- | --- | --- | --- |
| Basque* / Singapore | 0.261 | 13.48% | No |
| Korea / UK | 2.066 | 54.14% | No |
| US / China | 0.990 | 33.11% | No |

*Notes: Relative gaps are symmetric differences divided by mean intensity. Ratios use unrounded source values. The Basque comparison includes a regional PPP proxy. All three comparisons are illustrative; none satisfies the strict rule.*

### Why equal spending shares do not mean equal resources

> PPP-scaled R&D per person = (GERD/GDP ÷ 100) × PPP GDP per person.

At the same share, a richer economy has more implied resources per resident. This identity uses economy-wide PPP, not research-specific prices. It is useful descriptive arithmetic but cannot be inserted as an independent explanation of income: income is already part of its construction. Similarly, national totals mix population scale with intensity. Keep scale, intensity, personnel and outputs separate.

<!-- PAGEBREAK -->

## 4. Partial correlation: three simple steps

Suppose x is internet users as a percentage of population, z is R&D intensity and y is log PPP income. Take only economies with all required values. For this example **n = 80**; Myanmar, Syria and Turkmenistan lack the internet observation. Refit both regressions on these 80 economies. Do not reuse income residuals from the 83-economy baseline.

**Step 1 — adjust internet use for R&D.**

> Fitted internet = 79.849129845 + 3.968112837 × z.

> Internet residual eₓ = observed internet − fitted internet.

**Step 2 — adjust log income for R&D.**

> Fitted log income = 10.126721657 + 0.295407362 × z.

> Log-income residual eᵧ = observed ln(PPP income) − fitted log income.

**Step 3 — correlate the two residual columns.**

> r(x,y | z) = CORREL(eₓ, eᵧ) = 0.736373185.

The raw internet–log-income correlation is 0.780290875. The adjusted value remains strongly positive: economies above the internet fitted line tend also to be above the log-income fitted line. The residuals are deviations from statistical lines, **not measures of national efficiency or policy failure**. Linear fitted internet values are descriptive and need not respect the 0–100 bounds outside the main data range.

![Three-step residual method](Three_Step_Method.png)
*Figure 1. The same 80 economies in all panels. Dashed segments show observed-minus-fitted deviations for China and Iceland. The final panel correlates deviations across all 80 economies. This reproduces the internet row in Figure 3 of the global paper and Figure 2 of the policy brief.*

The equivalent one-control formula is:

> r(x,y | z) = [r(x,y) − r(x,z)r(y,z)] / sqrt{[1 − r(x,z)²][1 − r(y,z)²]}.

Here r(x,z) = 0.383325648 and r(y,z) = 0.519256670. Both methods agree to numerical precision. The calculation is standard partial correlation; see Kim (2015), Section 2, Equation 2.3: https://doi.org/10.5351/CSAM.2015.22.6.665

<!-- PAGEBREAK -->

## 5. Worked observations: China and Iceland

These two rows explain the arithmetic, not the full correlation. The correlation uses all 80 economies.

**Table 2. Actual source values and residual calculations**

| Quantity | China | Iceland |
| --- | --- | --- |
| R&D/GDP (%) | 2.494502 | 2.558122 |
| Observed internet (%) | 75.611316 | 97.583397 |
| PPP GDP/person ($) | 23,028.45 | 76,592.34 |
| Observed log income | 10.044486 | 11.246252 |
| Fitted internet (%) | 89.747593 | 90.000047 |
| Internet residual (pp) | -14.136277 | 7.583350 |
| Fitted log income | 10.863616 | 10.882410 |
| Log-income residual | -0.819130 | 0.363843 |

For China, fitted internet use is 79.849129845 + 3.968112837 × 2.494501536 = 89.747593410. Its actual value is 75.611316030, giving a residual of **−14.136277380 percentage points**. Its fitted log income is 10.863615774, while its actual log income is 10.044485765: the residual is **−0.819130010**.

Iceland's internet residual is **+7.583349959 pp** and its log-income residual is **+0.363842586**. Thus China is below both lines and Iceland above both. Other economies may have different sign combinations; the overall association summarises all of them.

### How to interpret the units

Internet residuals are percentage points. Log-income residuals are log units. Exponentiating the fitted log income produces reference levels of approximately $52,241 for China and $53,232 for Iceland. These are geometric-scale fitted benchmarks, not welfare targets or unbiased forecasts of arithmetic-mean income.

The partial r of 0.736 is unitless. **It does not mean a 73.6% income increase**, a 73.6% return to internet provision or that internet causes 73.6% of prosperity. Squaring it describes a bivariate residual-fit quantity, not a causal share of income.

### Partial correlation versus regression coefficient

Regressing y on both z and x gives an internet slope of 0.037445800 log-income units per percentage point of internet use. Regressing eᵧ on eₓ gives the same slope: the partial-regression identity. This slope differs from the unitless correlation of 0.736. Both are associations under this model. Neither identifies what would happen if a policy raised internet access by one point.

### Why “controlling for R&D” is a limited statement

Only the fitted linear association with R&D is removed. Wealth, institutions and research may influence one another; omitted variables, measurement error and cross-country spillovers remain. Conditioning on a jointly determined variable can itself distort a causal interpretation. Say **“conditional association under this specification”**, rather than “the independent causal effect”.

<!-- PAGEBREAK -->

## 6. Reproduce it in Excel

Open **Worked_Example.xlsx**. Four sheets separate instructions, results, live calculations and checked numerical values. Excel is set to recalculate on opening. Some previewers do not evaluate formulas; **Summary column B** and **Values_checked** contain populated Python-verified values. Excel itself has not been run as part of the verification.

### Source and calculation columns

| Column in Data_and_residuals | Meaning | Formula in row 2, where applicable |
| --- | --- | --- |
| A / B | ISO3 / economy | Source identifiers |
| C | R&D/GDP, percent | Source value; do not apply percentage formatting |
| D | Internet use, percent | Source value |
| E | PPP GDP per person | Source value |
| F | Natural-log income | `=LN(E2)` |
| G | Fitted internet | `=Summary!$C$8+Summary!$C$9*C2` |
| H | Internet residual | `=D2-G2` |
| I | Fitted log income | `=Summary!$C$10+Summary!$C$11*C2` |
| J | Log-income residual | `=F2-I2` |
| K | Exponentiated benchmark | `=EXP(I2)` |

There are 80 data rows, **rows 2–81**. Summary column C contains:

- C8: `=INTERCEPT(Data_and_residuals!$D$2:$D$81,Data_and_residuals!$C$2:$C$81)`
- C9: `=SLOPE(Data_and_residuals!$D$2:$D$81,Data_and_residuals!$C$2:$C$81)`
- C10: `=INTERCEPT(Data_and_residuals!$F$2:$F$81,Data_and_residuals!$C$2:$C$81)`
- C11: `=SLOPE(Data_and_residuals!$F$2:$F$81,Data_and_residuals!$C$2:$C$81)`
- C15: `=CORREL(Data_and_residuals!$H$2:$H$81,Data_and_residuals!$J$2:$J$81)`

**Expected C15: 0.736373185.** Locale settings may display translated function names or semicolon separators. Preserve the ranges and meanings.

### If your supervisor changes the indicator

Start again with that indicator's complete-case sample. Keep exactly the same rows for x, y and z. Recalculate both fitted lines, both residual columns and their correlation; update every range to the new last row. Copying the previous residual column while changing the sample is incorrect. To compare predictors fairly, additionally repeat the analysis on their common intersection of economies.

<!-- PAGEBREAK -->

## 7. Uncertainty, sensitivity and prediction

### Intervals and multiple tests

For k controls, the approximate Fisher standard error is 1/sqrt(n − k − 3). With one R&D control and n = 80:

> Fisher z = atanh(r); interval = tanh[atanh(r) ± 1.96/sqrt(80 − 4)].

The internet interval is **[0.615471576, 0.823416627]**. The conventional t statistic is r × sqrt[(n − k − 2)/(1 − r²)] = 9.550520, with 77 degrees of freedom. These are model-based, pointwise approximations. The countries are not a random independent world sample, and the formulas do not capture all data uncertainty or shared shocks.

The main 36 correlations use Benjamini–Hochberg q-values; the five new exploratory tests form a separate family. BH orders p-values and adjusts them for the number tested. It does not correct selective choice of hypotheses, nonrandom sample coverage or incorrect causal assumptions. These analyses were not preregistered.

### What robustness checks change

| Check | Purpose | Limit |
| --- | --- | --- |
| log(1 + R&D) or quadratic R&D | Relax the straight-line adjustment | Still a chosen functional form |
| Rank-based residuals | Reduce sensitivity to scale/extremes | Different association, not the same linear estimand |
| Additional log population | Examine size/shared-denominator sensitivity | Does not remove all scale effects |
| Boundary exclusions | Remove Ireland, Luxembourg and available resource rents ≥10% of GDP | Does not identify every unusual economy |
| Leave one economy out | Check influence of individual observations | Not a new independent sample |
| Common sample | Keep coverage fixed across indicators/models | Smaller and selected sample |

The internet result becomes 0.722665483 with a log(1 + R&D) control. Positive broad capability results persist across several specifications, but this stability is not proof of causation.

### Held-out prediction: why it matters

For each economy, fit the model on all other economies and predict the omitted economy's log income. Calculate RMSE = sqrt(mean of squared held-out errors). A model can fit observed data better simply by adding variables, yet predict worse. That happens to the structure/funding model: 0.435 → 0.549 on 34 fixed economies. The capability model improves 0.615 → 0.303 on 79 fixed economies. Compare changes **within** a family; the families have different samples.

These are internal leave-one-out checks. Hypotheses were informed by the data and literature, so they are not external validation of a preregistered forecasting model. Regression coefficient intervals in the global tables use HC3 heteroskedasticity-robust covariance; Fisher correlation intervals are a different calculation.

<!-- PAGEBREAK -->

## 8. Industry accounting and the new tests

Let wᵢⱼ be an industry's share of manufacturing GVA, and rᵢⱼ = 100 × industry BERD / industry GVA. Then:

> Observed manufacturing intensity Rᵢ = Σⱼ wᵢⱼ rᵢⱼ.

> Common-weight intensity Rᵢ* = Σⱼ w̄ⱼ rᵢⱼ, with w̄ⱼ the unweighted mean share across 19 economies.

Five mutually exclusive groups cover manufacturing. Common weights sum to one. Only complete GVA/BERD groups with valid source ratios are eligible. Romania's amounts appear complete but its valid ratios are unavailable, so it remains excluded. This restriction is preserved rather than bypassed with an unapproved recalculation.

For the pair decomposition, redefine w as an industry's share of **whole-economy GVA**. The manufacturing contribution difference between A and B is exactly:

> Δ = Σⱼ(wₐⱼ − wᵦⱼ)(rₐⱼ + rᵦⱼ)/2 + Σⱼ(rₐⱼ − rᵦⱼ)(wₐⱼ + wᵦⱼ)/2.

The first term is composition; the second is within-group intensity. The symmetric formula allocates the interaction evenly. Korea minus UK: **3.007884 = 2.118480 + 0.889404 pp**. US minus China: **−0.083270 = −1.246086 + 1.162816 pp**. These are identities for a research ratio, not explanations of income percentages.

### Concentration and portfolio distance

**HHI = Σⱼsⱼ²**, where shares s sum to one. Here R&D and GVA HHI use exactly the same five manufacturing bins; possible values run from 0.2 to 1. Higher HHI means more concentration at this aggregation. R&D HHI exceeds GVA HHI in 7 of 19 economies, not universally.

**Distance = 0.5 × Σⱼabs(pⱼ − qⱼ)**, between two normalised portfolios. It runs from zero (identical observed composition) to one (non-overlapping composition). Applied to government and business research types, all basic/applied/development values must be observed, nonnegative and cover at least 90% of their reported performer totals. Normalisation excludes the remaining reported capital/unclassified component but retains coverage in the data. UK business coverage is 93.31%; US government coverage is 98.38%. “Government” excludes university performers.

### Sector GVA per employed person

> Relative sector GVA/worker = sector GVA share / sector employment share.

This equals sector GVA/worker divided by whole-economy GVA/worker when the shares use the same coverage. MHT exceeds LMT in 47/53 economies, with a median ratio of 1.468; custom KIS exceeds LIS in 43/53, median 1.242. These are nominal within-country ratios and can reflect prices, capital, hours and composition. They do not predict the marginal effect of transferring a worker.

The five new partial-correlation tests all have approximate 95% intervals including zero. That constrains the narrative; it does not prove equivalence or absence of the mechanisms.

<!-- PAGEBREAK -->

## 9. Likely supervisor questions

**“Are you saying R&D does not increase income?”** No. I distinguish a cross-country current spending-share correlation from the causal impact of research. Knowledge accumulation, lags, spillovers and complementary assets allow positive research benefits alongside different income levels at similar intensity. Published studies provide stronger identification for particular settings than this cross-section does.

**“Why control R&D rather than divide the indicators by it?”** The question is about associations conditional on intensity. Residualisation removes the specified relationship with R&D from both variables. Dividing by R&D creates a different ratio, can magnify small denominators and does not solve confounding or identify efficiency.

**“Why not a panel regression?”** A panel is a valuable extension, but needs comparable historical measures, a defined estimand and credible identification. This project primarily integrates linked 2022 accounts. Its exploratory growth windows control initial income and have wide intervals; they do not identify causal returns.

**“Do government–business portfolio similarities show successful translation?”** No. Similarity is a limited composition statistic. Government and business may sensibly specialise in different missions. The estimated conditional association is weak, and intermediary effectiveness requires direct outcome evidence.

**“Are Korea and the UK matched on R&D?”** No. Their intensity gap is 2.066 pp and 54.14% relative to their mean. They illustrate similar income with different spending and production structures. None of the three requested pairs meets the strict near-intensity rule.

**“Can you say a Western or Eastern model is better?”** No. The selected pairs are not representative treatment groups. Region/city-state/national scale, institutions and industry mix differ. The analysis estimates no East–West coefficient.

**“Does a higher publication correlation mean publication subsidies outperform patent policy?”** No. The indicators differ in coverage, quality, fields and endogeneity. Common-sample checks show a descriptive ranking, not returns to alternative interventions.

**“Why does the UK lack total research types but appear in the portfolio plot?”** Total-performer and specific-performer coverage are different. Comparable UK aggregate basic/applied/development values are unavailable, while its business and government portfolios are available under the stated coverage rule. Missing total data do not imply missing every component.

**“How did you use my PDFs?”** All files were inventoried and extracted. The eight presentation texts and ifo reference were read; targeted source sections and prior audits support the main literature claims. Other documents were screened at the depth shown in the reading ledger. I do not claim all 2,975 pages were substantively read. Generated charts are not independent literature.

**“What is the contribution?”** An integrated, reproducible global diagnostic connecting R&D, income, capabilities, research outputs, funding/performers and industrial accounts. It tests slide-inspired hypotheses globally and retains findings that weaken them. The non-deterministic R&D–income relationship itself is not claimed as a new discovery.

**A sentence to finish the discussion:** “My results identify patterns and measurement problems that a spending target misses; the next stage is to test specific mechanisms with longitudinal or programme-level designs.”

<!-- PAGEBREAK -->

## 10. Reproduction and audit trail

From the **Global** directory, with uv and Python 3.13 available, run these commands in order. Script headers pin dependencies. Once dependencies are cached, add `--offline` to uv run to reproduce without downloading packages. Analysis uses the included frozen data.

> uv run --python 3.13 analyse_global.py

> uv run --python 3.13 Methods/worked_example.py

> uv run --python 3.13 Policy_Brief/analyse_brief.py

> uv run --python 3.13 Policy_Brief/render_documents.py

> uv run --python 3.13 Policy_Brief/build_documents.py

> uv run --python 3.13 Policy_Brief/validate_brief.py

The first command regenerates global numerical outputs. The next two regenerate the worked example and new evidence. Rendering fills tables from those results; building creates matching PDF and Word files. Validation checks samples, independent residual calculations, accounting identities, figures, workbook values, citations and document completeness. Original PDF inventory/extraction requires the original workspace and is not part of the portable numerical rebuild.

### Where each claim comes from

| Evidence | File relative to Global |
| --- | --- |
| Global fit and pair counts | Data/summary.json; all_near_intensity_pairs.csv |
| Partial correlations and exact samples | Data/income_correlations.csv |
| Same-sample output comparisons | Data/common_sample_correlations.csv |
| Model prediction results | Data/income_models.csv |
| Internet arithmetic | Methods/Calculation_Checks.json; Residuals.csv |
| Six cases and pair eligibility | Policy_Brief/Data/six_case_profiles_2022.csv; illustrative_pair_audit.csv |
| New hypotheses and intervals | Policy_Brief/Data/additional_global_tests.csv |
| Exact decomposition | Policy_Brief/Data/manufacturing_accounting_decomposition.csv |
| Source hashes and scope | Policy_Brief/Data/input_manifest.csv; Comparability.md |
| Document-by-document reading depth | Policy_Brief/PDF_Review/Reading_Ledger.md |

### Useful methodological sources

Kim, S. (2015). ppcor: An R package for a fast calculation to semi-partial correlation coefficients. *Communications for Statistical Applications and Methods*, 22, 665–674. The partial-correlation identity is standard and is also verified directly by the supplied code. https://doi.org/10.5351/CSAM.2015.22.6.665

Mathieu, A., and van Pottelsberghe de la Potterie, B. (2010). A Note on the Drivers of R&D Intensity. Structural benchmarking motivation. https://doi.org/10.5430/rwe.v1n1p56

OECD (2015). *Frascati Manual 2015*. Definitions of R&D, institutional performers and measurement; a definitional reference, not an additional local PDF claimed as read. https://doi.org/10.1787/9789264239012-en
