# /// script
# requires-python = ">=3.13"
# dependencies = ["pandas==3.1.1"]
# ///
"""Resolve manuscript values and tables from auditable analytical outputs."""
from pathlib import Path
import json
import re
import pandas as pd

ROOT = Path(__file__).resolve().parent
D = ROOT / "Data"
d = pd.read_csv(D / "global_countries_2022.csv").set_index("iso3")
c = pd.read_csv(D / "income_correlations.csv").set_index("metric")
m = pd.read_csv(D / "income_models.csv").set_index("model")
s = json.loads((D / "summary.json").read_text())
pairs = pd.read_csv(D / "selected_country_pairs.csv")
std = pd.read_csv(D / "manufacturing_standardisation.csv").set_index("iso3")
common = pd.read_csv(D / "common_sample_correlations.csv").set_index(["family", "metric"])
base = pd.read_csv(D / "baseline_sensitivity.csv").set_index("specification")
tables, claims = {}, []

def fmt(value, spec):
    return "—" if pd.isna(value) else format(value, spec)

def table(key, header, rows):
    tables[key] = "\n".join("| " + " | ".join(map(str, row)) + " |" for row in [header, ["---"]*len(header), *rows])

q = pairs.loc[pairs.selection.eq("largest gap per band")]
table("PAIRS", ["Mean-intensity band", "Data-selected pair", "GERD/GDP (%)", "PPP income ($)", "Income ratio"],
      [[r.band, f"{r.low_name} / {r.high_name}", f"{r.rd_low_income:.3f} / {r.rd_high_income:.3f}", f"{r.ppp_low:,.0f} / {r.ppp_high:,.0f}", f"{r.income_ratio:.2f}×"] for r in q.itertuples()])
variables = [("gov_effect", "Government effectiveness"), ("internet", "Internet users"), ("hci_2020", "Human capital (2020)"),
             ("log_publications_pm", "Articles/million (log1p)"), ("log_researchers", "Researchers/million (log1p)"), ("log_patents_pm", "Resident patents/million (log1p)"),
             ("gva_mfg", "Manufacturing GVA share"), ("gva_MHT", "MHT GVA share"), ("gva_KIS", "Custom KIS GVA share"),
             ("export_MHT", "MHT goods export share"), ("perform_BES", "Business performer share"), ("fund_BES", "Business funding share"), ("flow_BES_to_HES_recipient", "Business funding / university R&D")]
table("CORRELATIONS", ["Indicator", "n", "Partial r", "Rank partial r", "BH q"],
      [[label, int(c.loc[x,"n"]), f"{c.loc[x,'partial_rd']:.3f}", f"{c.loc[x,'partial_rank']:.3f}", "<0.001" if c.loc[x,"bh_q"]<.001 else f"{c.loc[x,'bh_q']:.3f}"] for x,label in variables])
modelnames = [("capability_0", "Capabilities: R&D only"), ("capability_3", "R&D + internet + HCI + governance"),
              ("outputs_0", "Research indicators: R&D only"), ("outputs_1", "R&D + researchers"), ("outputs_2", "R&D + articles"), ("outputs_3", "R&D + resident patents"), ("outputs_4", "R&D + all three research indicators"),
              ("joint_1", "Joint sample: R&D + capabilities"), ("joint_3", "R&D + capabilities + articles"),
              ("structure_0", "Structure/funding: R&D only"), ("structure_3", "R&D + structure + funding")]
table("MODELS", ["Model (compare within sample)", "n", "R²", "Held-out RMSE"],
      [[label, int(m.loc[x,"n"]), f"{m.loc[x,'r2']:.3f}", f"{m.loc[x,'loo_rmse']:.3f}"] for x,label in modelnames])
profiles = [("rd", "GERD / GDP (%)", ".3f"), ("ppp", "PPP GDP per person ($)", ",.0f"), ("rd_per_person_ppp_scaled", "PPP-scaled R&D per person ($)", ",.0f"),
            ("researchers", "Researchers per million", ",.0f"), ("publications_pm", "Scientific articles per million", ",.0f"), ("patents_pm", "Resident applications per million", ",.0f"),
            ("internet", "Internet users (%)", ".1f"), ("gva_mfg", "Manufacturing / GVA (%)", ".2f"), ("gva_MHT", "MHT / GVA (%)", ".2f"),
            ("gva_KIS", "Custom KIS / GVA (%)", ".2f"), ("export_MHT", "MHT / goods exports (%)", ".2f"), ("berd_gva_mfg", "Manufacturing BERD/GVA (%)", ".2f"),
            ("perform_BES", "Business performer / GERD (%)", ".2f"), ("fund_BES", "Business funding / GERD (%)", ".2f"), ("fund_ROW", "Foreign funding / GERD (%)", ".2f"),
            ("flow_BES_to_HES_recipient", "Business funding / university R&D (%)", ".2f"), ("research_ALL_BR", "Basic research / research total (%)", ".2f"),
            ("research_ALL_ED", "Development / research total (%)", ".2f"), ("field_ALL_FORD2", "Engineering / field total (%)", ".2f"), ("gni_gdp", "GNI / GDP (%)", ".2f")]
table("PROFILES", ["Measure (2022 unless specified)", "China", "Iceland", "Portugal", "Singapore"],
      [[label, *[fmt(d.loc[iso,x],spec) for iso in ["CHN","ISL","PRT","SGP"]]] for x,label,spec in profiles])
table("INDUSTRY", ["Economy", "Observed (%)", "Common mix (%)", "Change (pp)"],
      [[std.loc[iso,"economy"], *[f"{std.loc[iso,col]:.2f}" for col in ["observed","common_structure","change_pp"]]] for iso in ["TUR","FIN","USA","JPN","CHN","ISL"]])
t = pd.read_csv(D / "timing_growth_diagnostics.csv")
table("TIMING", ["Growth window", "n", "R&D coefficient", "HC3 95% interval"],
      [[f"{r.start}–{r.end}", r.n, f"{r.rd_coefficient:.3f}", f"[{r.ci_low:.3f}, {r.ci_high:.3f}]"] for r in t.itertuples()])

def resolve(match):
    key = match[1]
    if key in tables:
        return tables[key]
    parts = key.split(":")
    source = parts[0]
    if source == "summary":
        _, name, spec = parts
        value = s[name]
    else:
        _, row, col, spec = parts
        frames = {"country":d, "corr":c, "model":m, "industry":std, "baseline":base}
        if source == "common":
            family, metric = row.split("/")
            value = common.loc[(family, metric),col]
        else:
            value = frames[source].loc[row,col]
    rendered = fmt(value,spec)
    claims.append(dict(token=key, value=float(value), rendered=rendered))
    return rendered

text = re.sub(r"\{\{([^}]+)\}\}", resolve, (ROOT / "Paper.template.md").read_text(encoding="utf-8"))
assert "{{" not in text
(ROOT / "Paper.md").write_text(text, encoding="utf-8")
pd.DataFrame(claims).to_csv(D / "manuscript_numeric_claims.csv", index=False)
(D / "manuscript_tables.json").write_text(json.dumps(tables,indent=2),encoding="utf-8")
print(f"Rendered {len(text.split())} words, {len(claims)} linked prose values, {len(tables)} data tables.")
