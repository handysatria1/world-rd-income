# /// script
# requires-python = ">=3.13"
# dependencies = ["requests==2.32.5"]
# ///
"""Online bibliographic identity audit; metadata access is not a reading claim."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import re
import requests

ROOT = Path(__file__).resolve().parent
dois = sorted(set(re.findall(r"https://doi.org/([^\s]+)", (ROOT / "Literature_Review.md").read_text(encoding="utf-8"))))

def one(doi):
    try:
        r = requests.get("https://api.crossref.org/works/" + doi, timeout=60)
        r.raise_for_status()
        m = r.json()["message"]
        return dict(doi=doi, title=m.get("title"), journal=m.get("container-title"),
                    published=m.get("published"), volume=m.get("volume"), page=m.get("page"), authors=m.get("author"))
    except Exception as exc:
        return dict(doi=doi, error=str(exc))

with ThreadPoolExecutor(max_workers=5) as pool:
    records = list(pool.map(one, dois))
(ROOT / "Sources/crossref_verification.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
print(json.dumps([{k:v for k,v in row.items() if k != "authors"} for row in records], indent=2))
