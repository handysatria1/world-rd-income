# Data dictionary and reading guide

## Core and derived measures

| Field / family | Meaning and unit |
|---|---|
| `iso3`, `economy` | Economy identifiers; the unit is an economy, not necessarily a sovereign state |
| `rd` | GERD / GDP, percentage points, harmonised 2022 provider selection |
| `ppp`, `nominal` | GDP per capita: current international dollars at PPP; current US dollars |
| `log_ppp`, `log_nominal` | Natural logarithms of those income measures |
| `population` | 2022 population, separately retrieved WDI vintage |
| `researchers` | Researchers in R&D per million people, main observation year 2022 |
| `publications`, `patents`, `patentsNonresident` | Scientific/technical publications; resident and nonresident patent applications, counts |
| `*_pm` | Counts divided by population and multiplied by one million |
| `log_researchers`, `log_publications_pm`, `log_patents_pm` | Natural log of one plus the indicated density |
| `researchers_prior`, `researchers_prior_year` | Latest available within 2020–2022, separately retained; not used in principal researcher associations |
| `hci_2020` | Human Capital Index, 2020, unit interval |
| `rents_prior`, `rents_prior_year` | Latest available resource rents / GDP in 2020–2022 and actual year; 80 from 2021, two from 2020 |
| `rd_per_person_ppp_scaled` | `rd * ppp / 100`; derived arithmetic, not R&D-specific PPP or an independent income predictor |
| `researchers_implied_count` | Researchers/million × population / one million; no additional FTE convention imposed |
| `ip_payments_gdp` | IP charges paid abroad / GDP ×100, matched 2022 current-USD supplement inputs |
| `gni_gdp` | GNI / GDP ×100, matched 2022 current-USD supplement inputs |
| `boundary_flag` | Ireland, Luxembourg, or available prior rent share ≥10%; missing rents do not trigger it |
| `income_residual_*` | Deviations from the linear log-income baseline; not efficiency scores or causal effects |
| `rd_band` | Individual intensity band; pair-selection bands instead use mean pair intensity |

## Supplementary World Bank indicators

Histories requested for 2000–2023; source 2 unless specified. Null observations and aggregate records remain in raw responses.

| Metric | Indicator | Unit |
|---|---|---|
| Population | `SP.POP.TOTL` | People |
| Internet use | `IT.NET.USER.ZS` | % population |
| Tertiary enrolment | `SE.TER.ENRR` | Gross %, can exceed 100 |
| Human Capital Index | `HD.HCI.OVRL` (source 63) | Index; main analysis uses 2020 |
| Government effectiveness | `GOV_WGI_GE.EST` (source 3) | Estimate, not a percent |
| Rule of law | `GOV_WGI_RL.EST` (source 3) | Estimate, not a percent |
| Resource rents | `NY.GDP.TOTL.RT.ZS` | % GDP |
| Fixed investment | `NE.GDI.FTOT.ZS` | % GDP, a flow rather than capital stock |
| Private credit | `FS.AST.PRVT.GD.ZS` | % GDP |
| Services value added | `NV.SRV.TOTL.ZS` | % GDP |
| Agriculture value added | `NV.AGR.TOTL.ZS` | % GDP |
| Trade | `NE.TRD.GNFS.ZS` | Exports + imports, % GDP |
| IP charges paid | `BM.GSR.ROYL.CD` | Current US dollars |
| GDP | `NY.GDP.MKTP.CD` | Current US dollars |
| GNI | `NY.GNP.MKTP.CD` | Current US dollars |
| Employment / population | `SL.EMP.TOTL.SP.ZS` | % population age 15+, modelled ILO estimate |
| Real PPP GDP per person | `NY.GDP.PCAP.PP.KD` | Constant international dollars; growth diagnostic |

## Funding, research focus and industrial fields

- `fund_BES/GOV/HES/PNP/ROW`: funding from business/government/higher education/private nonprofit/rest of world, as % of GERD cube total.
- `perform_BES/GOV/HES/PNP`: performed by that sector, as % of GERD cube total.
- `flow_A_to_B_recipient`: funding from A to performer B as % of B's R&D. Suffix `_gerd` uses total GERD; `_funder` uses all R&D funded by A. These denominators are not interchangeable.
- `research_ALL/BES/GOV/HES_BR/AR/ED/CAP_EX_NEC`: basic/applied/development/capital-unclassified shares of the research cube's performer total. Suffix `_classified` uses the sum of basic, applied and development only.
- `field_ALL/BES/GOV/HES_FORD1/FORD2/FORD3`: natural sciences / engineering and technology / medical and health sciences, % of the separate field-cube total.
- `gva_mfg`, `gva_MHT`, `gva_KIS`, etc.: % of the linked complete economy-wide GVA denominator. Custom groups follow the audit's definitions.
- `berd_gva_mfg`, `berd_gva_MHT`, etc.: business R&D divided by the matching sector's GVA ×100; unavailable or comparability-excluded ratios remain missing.
- `export_MHT`, `export_LMT`, `export_electronics`, etc.: gross product exports as % of total goods exports.
- `*_gdp_scaled`: national intensity multiplied by a cube share, preserving the selected national total; not a replacement for the original source's directly reported amount.

Other retained columns in `input_linked_2022.csv` are inherited descriptive components. Only the predictor list in `income_correlations.csv` and named model specifications are used in the global analysis; retention does not imply inclusion in a regression.

## Results and samples

- `income_correlations.csv`: Pearson, Spearman, partial correlations under multiple controls, approximate intervals, primary p-values, BH q-values, leave-one-out ranges and exact country lists.
- `common_sample_correlations.csv`: same-row comparisons within each indicator family; its capability family includes tertiary enrolment and credit and therefore differs from the 79-economy capability regression family.
- `income_models.csv`, `income_model_coefficients.csv`, `income_model_samples.csv`: fixed-sample models, HC3 coefficients/intervals and exact membership. `loo_rmse` is log-income error, not a percentage-point GDP error.
- `all_near_intensity_pairs.csv`: every eligible overlapping pair. `relative_rd_gap` is a proportion, so 0.10 means 10%.
- `selected_country_pairs.csv`, `pairs_large_economy_sensitivity.csv`: selected extreme pairs under the explicit rules.
- `manufacturing_standardisation.csv`: observed/common-mix manufacturing BERD/GVA and ranks; 19 economies.
- `timing_growth_diagnostics.csv`, `timing_growth_samples.csv`: early R&D and later constant-PPP growth, distinct from the level models.
- `supplement_and_innovation_2022_long.csv`: main-year observation provenance; HCI2020 and prior-rent histories remain in `supplement_annual.csv` and raw files.
- `manuscript_numeric_claims.csv`: exact prose tokens, underlying values and formatted numbers. `manuscript_tables.json` stores the generated data-table text.

The workbook uses CSV stems truncated to Excel's 31-character sheet-name limit. It contains 17 analysis sheets; the complete CSV bundle additionally includes timing rows, manifests and validation outputs.
