# Source identity checks

Two exploratory NBER downloads had incorrectly inferred paper numbers. Their first-page titles were checked and the files are **excluded from the literature evidence**:

- `Comin_Mestieri_2013_WP.pdf/.txt` is actually García Marín and Voigtländer, *Exporting and Plant-Level Efficiency Gains: It's in the Measure*, NBER 19033.
- `Syverson_2009_WP.pdf/.txt` is actually Chetty, *The Simple Economics of Salience and Taxation*, NBER 15246.

The correct paper numbers were subsequently discovered from the published-article RePEc records: Comin–Mestieri **19010**, Syverson **15712**. Correct files contain `verified_WP` in their names. The incorrect downloads are retained only as an audit trail and are omitted from the delivery package. A download success is not a bibliographic identity check or a reading claim.

The Timmer et al. (2014) journal landing page is available; the PDF request failed. Treat it as abstract/metadata access, not full-text reading.
