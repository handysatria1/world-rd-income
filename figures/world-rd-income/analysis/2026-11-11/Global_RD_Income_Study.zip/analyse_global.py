# /// script
# requires-python = ">=3.13"
# dependencies = ["numpy==2.5.4", "pandas==3.1.1", "scipy==1.18.1", "statsmodels==0.15.0", "matplotlib==3.11.2", "openpyxl==3.1.5"]
# ///
"""Global, income-outcome analysis. All calculations use frozen local inputs.

Country/economy weights are equal. Basque and overlapping aggregates excluded.
Exploratory associations are not causal effects, returns, or mediation estimates.
"""
from pathlib import Path
import json
from itertools import combinations
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

ROOT = Path(__file__).resolve().parent
D, F = ROOT / "Data", ROOT / "Figures"
F.mkdir(exist_ok=True)
LABELS = {
    "log_researchers": "Researchers per million (log1p)",
    "log_publications_pm": "Scientific articles per million (log1p)",
    "log_patents_pm": "Resident patent applications per million (log1p)",
    "internet": "Internet users (% population)", "tertiary": "Tertiary enrolment (gross %)",
    "hci_2020": "Human Capital Index (2020)", "gov_effect": "Government effectiveness",
    "rule_law": "Rule of law", "credit": "Private credit (% GDP)",
    "fixed_investment": "Fixed investment (% GDP)", "rents": "Natural resource rents (% GDP)",
    "rents_prior": "Resource rents (latest 2020–22)", "services_gdp": "Services value added (% GDP)",
    "agriculture_gdp": "Agriculture value added (% GDP)", "trade": "Trade (% GDP)",
    "ip_payments_gdp": "IP charges paid abroad (% GDP)", "gni_gdp": "GNI / GDP (%)",
    "employment_15plus": "Employment / population age 15+ (%)",
    "gva_mfg": "Manufacturing (% total GVA)", "gva_MHT": "MHT manufacturing (% GVA)",
    "gva_KIS": "Custom KIS (% GVA)", "export_MHT": "MHT goods (% goods exports)",
    "berd_gva_mfg": "Manufacturing BERD/GVA (%)", "berd_gva_MHT": "MHT BERD/GVA (%)",
    "berd_gva_KIS": "KIS BERD/GVA (%)", "perform_BES": "Business performer (% GERD)",
    "perform_HES": "University performer (% GERD)", "perform_GOV": "Government performer (% GERD)",
    "fund_BES": "Domestic business funding (% GERD)", "fund_GOV": "Government funding (% GERD)",
    "fund_ROW": "Foreign funding (% GERD)",
    "flow_BES_to_HES_recipient": "Business funding (% university R&D)",
    "flow_GOV_to_BES_recipient": "Government funding (% business R&D)",
    "research_ALL_BR": "Basic research (% GERD cube total)",
    "research_ALL_ED": "Experimental development (% GERD cube total)",
    "field_ALL_FORD2": "Engineering (% GERD field total)",
    "field_BES_FORD2": "Engineering (% business R&D)",
}


def save(df, name):
    df.to_csv(D / f"{name}.csv", index=False)


def fit(df, xs, outcome="log_ppp"):
    return sm.OLS(df[outcome].astype(float), sm.add_constant(df[xs].astype(float), has_constant="add")).fit()


def partial(df, x, controls, outcome="log_ppp"):
    a = fit(df, controls, x).resid
    b = fit(df, controls, outcome).resid
    r = stats.pearsonr(a, b).statistic
    n, k = len(df), len(controls)
    t = r * np.sqrt((n-k-2) / max(1-r*r, 1e-15))
    p = 2 * stats.t.sf(abs(t), n-k-2)
    z = np.arctanh(np.clip(r, -.999999, .999999))
    ci = np.tanh(z + np.array([-1, 1]) * 1.96 / np.sqrt(n-k-3))
    return float(r), float(p), *map(float, ci)


def loo_rmse(q, xs, outcome="log_ppp"):
    # Explicit held-out refits, no full-sample standardisation or variable selection.
    errors = []
    for idx in q.index:
        model = fit(q.drop(index=idx), xs, outcome)
        pred = model.predict(sm.add_constant(q.loc[[idx], xs], has_constant="add")).iloc[0]
        errors.append(q.loc[idx, outcome] - pred)
    return float(np.sqrt(np.mean(np.square(errors))))


def main():
    d = pd.read_csv(D / "input_linked_2022.csv")
    assert len(d) == 83 and d.iso3.is_unique and not d.iso3.eq("ES-PV").any()
    inn = pd.read_csv(D / "input_innovation_annual.csv", low_memory=False)
    sup = pd.read_csv(D / "supplement_annual.csv", low_memory=False)
    # API 'all' includes aggregates and records with blank ISO3 codes. Keep the
    # original responses intact; joins use only the frozen core's named economies.
    sup = sup.loc[sup.iso3.isin(d.iso3)].copy()
    inn = inn.loc[inn.iso3.isin(d.iso3)].copy()
    assert not inn.duplicated(["iso3", "metric", "year"]).any()
    assert not sup.duplicated(["iso3", "metric", "year"]).any()
    s22 = sup.loc[sup.year.eq(2022)].pivot(index="iso3", columns="metric", values="value")
    d = d.merge(s22, on="iso3", how="left", validate="one_to_one")
    i22 = inn.loc[inn.year.eq(2022) & inn.metric.ne("rd")].pivot(index="iso3", columns="metric", values="value")
    d = d.merge(i22, on="iso3", how="left", validate="one_to_one")
    provenance = pd.concat([sup.loc[sup.year.eq(2022)], inn.loc[inn.year.eq(2022) & inn.metric.ne("rd")]], ignore_index=True)
    provenance = provenance.loc[provenance.iso3.isin(d.iso3)]
    save(provenance, "supplement_and_innovation_2022_long")
    hci = sup.loc[sup.metric.eq("hci") & sup.year.eq(2020), ["iso3", "value"]].rename(columns={"value": "hci_2020"})
    d = d.merge(hci, on="iso3", how="left", validate="one_to_one")
    # Explicitly labelled prior-year fallback, never mixed into same-year variables.
    for source, metric in [(sup, "rents"), (inn, "researchers")]:
        q = source.loc[source.metric.eq(metric) & source.year.between(2020, 2022) & source.value.notna()].sort_values("year").groupby("iso3").tail(1)
        q = q[["iso3", "value", "year"]].rename(columns={"value": metric+"_prior", "year": metric+"_prior_year"})
        d = d.merge(q, on="iso3", how="left", validate="one_to_one")
    d = d.copy()
    for col in ["publications", "patents", "patentsNonresident"]:
        d[col+"_pm"] = d[col] / d.population * 1e6
    for col in ["researchers", "publications_pm", "patents_pm", "researchers_prior"]:
        d["log_"+col] = np.log1p(d[col])
    d["researchers_implied_count"] = d.researchers * d.population / 1e6
    d["log_population"] = np.log(d.population)
    d["rd_per_person_ppp_scaled"] = d.rd / 100 * d.ppp
    d["ip_payments_gdp"] = 100 * d.ip_payments_usd / d.gdp_usd
    d["gni_gdp"] = 100 * d.gni_usd / d.gdp_usd
    d["log_nominal"] = np.log(d.nominal)
    d["log1p_rd"] = np.log1p(d.rd)
    d["rd_squared"] = d.rd**2
    d["boundary_flag"] = d.iso3.isin(["IRL", "LUX"]) | d.rents_prior.ge(10)
    d["rd_band"] = pd.cut(d.rd, [0, .5, 1.5, 2.5, np.inf], right=False, labels=["<0.5%", "0.5–<1.5%", "1.5–<2.5%", "2.5%+"])
    baseline = fit(d, ["rd"])
    d["income_residual_linear"] = baseline.resid
    d["income_fitted_linear"] = np.exp(baseline.fittedvalues)
    d["income_residual_factor"] = np.exp(baseline.resid)
    save(d, "global_countries_2022")
    coverage = pd.DataFrame([dict(metric=x, label=label, n=int(d[x].notna().sum()), median_rd=d.loc[d[x].notna(), "rd"].median(), median_ppp=d.loc[d[x].notna(), "ppp"].median()) for x, label in LABELS.items()])
    save(coverage, "indicator_coverage")
    bands = d.groupby("rd_band", observed=True).agg(n=("iso3", "size"), rd_min=("rd", "min"), rd_max=("rd", "max"), income_min=("ppp", "min"), income_q25=("ppp", lambda s:s.quantile(.25)), income_median=("ppp", "median"), income_q75=("ppp", lambda s:s.quantile(.75)), income_max=("ppp", "max")).reset_index()
    save(bands, "intensity_band_dispersion")

    # Data-selected near-intensity pairs. Both absolute AND relative calipers.
    rows = []
    for a, b in combinations(d.to_dict("records"), 2):
        gap = abs(a["rd"] - b["rd"])
        rel = 2*gap/(a["rd"]+b["rd"])
        if gap <= .15 and rel <= .10:
            lo, hi = sorted([a, b], key=lambda r:r["ppp"])
            meanrd = (lo["rd"]+hi["rd"])/2
            band = ["<0.5%", "0.5–<1.5%", "1.5–<2.5%", "2.5%+"][np.searchsorted([.5,1.5,2.5], meanrd, side="right")]
            rows.append(dict(low=lo["iso3"], high=hi["iso3"], low_name=lo["economy"], high_name=hi["economy"], rd_low_income=lo["rd"], rd_high_income=hi["rd"], ppp_low=lo["ppp"], ppp_high=hi["ppp"], absolute_rd_gap=gap, relative_rd_gap=rel, income_ratio=hi["ppp"]/lo["ppp"], band=band, boundary_pair=lo["boundary_flag"] or hi["boundary_flag"]))
    pairs = pd.DataFrame(rows).sort_values(["income_ratio", "low", "high"], ascending=[False, True, True])
    save(pairs, "all_near_intensity_pairs")
    selected = pd.concat([pairs.groupby("band", sort=False).head(1).assign(selection="largest gap per band"), pairs.loc[~pairs.boundary_pair].groupby("band", sort=False).head(1).assign(selection="largest gap excluding boundary cases")])
    save(selected, "selected_country_pairs")
    eligible_large = set(d.loc[d.population.ge(1e6) & ~d.boundary_flag, "iso3"])
    save(pairs.loc[pairs.low.isin(eligible_large) & pairs.high.isin(eligible_large)].groupby("band", sort=False).head(1), "pairs_large_economy_sensitivity")
    save(d.loc[d.iso3.isin(set(selected.low) | set(selected.high))], "selected_country_profiles")

    # Same-year marginal and R&D-conditional correlations. One fixed main family.
    records = []
    for x, label in LABELS.items():
        q = d[["iso3", "rd", "log1p_rd", "rd_squared", "log_ppp", "log_nominal", "log_population", "boundary_flag", x]].dropna()
        if len(q) < 10:
            continue
        r, p, l, u = partial(q, x, ["rd"])
        ranks = q[[x, "log_ppp", "rd"]].rank()
        record = dict(metric=x, label=label, n=len(q), pearson=stats.pearsonr(q[x],q.log_ppp).statistic,
                      spearman=stats.spearmanr(q[x],q.log_ppp).statistic, corr_rd=stats.pearsonr(q[x],q.rd).statistic,
                      partial_rd=r, partial_p=p, ci_low=l, ci_high=u,
                      partial_logrd=partial(q,x,["log1p_rd"])[0], partial_quadratic=partial(q,x,["rd","rd_squared"])[0],
                      partial_rank=partial(ranks,x,["rd"])[0], partial_nominal=partial(q,x,["rd"],"log_nominal")[0],
                      partial_rd_population=partial(q,x,["rd","log_population"])[0],
                      countries=";".join(q.iso3))
        qq = q.loc[~q.boundary_flag]
        record.update(n_no_boundary=len(qq), partial_no_boundary=partial(qq,x,["rd"])[0] if len(qq)>10 else np.nan)
        loo = [partial(q.drop(index=i),x,["rd"])[0] for i in q.index]
        record.update(loo_min=min(loo), loo_max=max(loo))
        records.append(record)
    corr = pd.DataFrame(records)
    corr["bh_q"] = multipletests(corr.partial_p, method="fdr_bh")[1]
    save(corr, "income_correlations")
    # Common-sample outputs prevent coverage changes from masquerading as strength.
    commonrows = []
    for family, metrics in {
        "research_outputs": ["log_researchers", "log_publications_pm", "log_patents_pm"],
        "capabilities": ["internet", "hci_2020", "gov_effect", "tertiary", "credit"],
        "structure_funding": ["gva_MHT", "gva_KIS", "export_MHT", "perform_BES", "fund_BES", "flow_BES_to_HES_recipient"],
    }.items():
        q = d.dropna(subset=metrics)
        for x in metrics:
            commonrows.append(dict(family=family, metric=x, n=len(q), partial_rd=partial(q,x,["rd"])[0], countries=";".join(q.iso3)))
    save(pd.DataFrame(commonrows), "common_sample_correlations")

    modelrows, coefrows, sample_rows = [], [], []
    specs = {
        "capability": [["rd"], ["rd","internet"], ["rd","hci_2020","gov_effect"], ["rd","internet","hci_2020","gov_effect"]],
        "outputs": [["rd"], ["rd","log_researchers"], ["rd","log_publications_pm"], ["rd","log_patents_pm"], ["rd","log_researchers","log_publications_pm","log_patents_pm"]],
        "structure": [["rd"], ["rd","gva_MHT","gva_KIS","export_MHT"], ["rd","perform_BES","fund_BES"], ["rd","gva_MHT","gva_KIS","export_MHT","perform_BES","fund_BES"]],
        "joint": [["rd"], ["rd","internet","hci_2020","gov_effect"], ["rd","log_publications_pm"], ["rd","internet","hci_2020","gov_effect","log_publications_pm"]],
    }
    for family, models in specs.items():
        needed = sorted(set(sum(models, [])))
        q = d.dropna(subset=needed)
        sample_rows.extend(dict(family=family, iso3=iso) for iso in q.iso3)
        for i, xs in enumerate(models):
            m = fit(q,xs)
            hc = m.get_robustcov_results(cov_type="HC3")
            mid = f"{family}_{i}"
            modelrows.append(dict(model=mid, family=family, predictors=" + ".join(xs), n=len(q), r2=m.rsquared, adjusted_r2=m.rsquared_adj, loo_rmse=loo_rmse(q,xs), condition_number=m.condition_number))
            for j, name in enumerate(m.params.index):
                coefrows.append(dict(model=mid, term=name, coefficient=m.params.iloc[j], hc3_se=hc.bse[j], ci_low=hc.conf_int()[j,0], ci_high=hc.conf_int()[j,1], p=hc.pvalues[j]))
    save(pd.DataFrame(modelrows), "income_models")
    save(pd.DataFrame(coefrows), "income_model_coefficients")
    save(pd.DataFrame(sample_rows), "income_model_samples")

    base_sens = []
    for name, q, xs, outcome in [
        ("PPP linear",d,["rd"],"log_ppp"), ("PPP log1p intensity",d,["log1p_rd"],"log_ppp"),
        ("PPP quadratic intensity",d,["rd","rd_squared"],"log_ppp"), ("Nominal linear",d,["rd"],"log_nominal"),
        ("PPP excluding boundary",d.loc[~d.boundary_flag],["rd"],"log_ppp"),
        ("PPP excluding Israel",d.loc[d.iso3.ne("ISR")],["rd"],"log_ppp"),
    ]:
        m=fit(q,xs,outcome)
        base_sens.append(dict(specification=name,n=len(q),r2=m.rsquared,loo_rmse=loo_rmse(q,xs,outcome),spearman=stats.spearmanr(q.rd,q[outcome]).statistic))
    save(pd.DataFrame(base_sens), "baseline_sensitivity")

    # Timing: earlier WDI research intensity and constant-PPP future growth.
    # A different source selection from the harmonised 2022 core; never relabelled.
    hist = inn.loc[inn.metric.eq("rd") & inn.value.notna() & inn.iso3.isin(d.iso3)]
    real = sup.loc[sup.metric.eq("real_ppp") & sup.iso3.isin(d.iso3)].pivot(index="iso3",columns="year",values="value")
    timing=[]
    timing_samples=[]
    for start,end in [(2010,2019),(2010,2022),(2015,2022)]:
        r=hist.loc[hist.year.eq(start),["iso3","value"]].set_index("iso3").rename(columns={"value":"rd_start"})
        q=r.join(real[[start,end]]).dropna()
        q["log_start"]=np.log(q[start])
        q["annual_log_growth"]=100*np.log(q[end]/q[start])/(end-start)
        m=fit(q,["rd_start","log_start"],"annual_log_growth")
        hc=m.get_robustcov_results(cov_type="HC3")
        timing.append(dict(start=start,end=end,n=len(q),raw_corr=stats.pearsonr(q.rd_start,q.annual_log_growth).statistic,partial_start_income=partial(q,"rd_start",["log_start"],"annual_log_growth")[0],rd_coefficient=m.params.rd_start,ci_low=hc.conf_int()[1,0],ci_high=hc.conf_int()[1,1],r2=m.rsquared))
        timing_samples.extend(q.reset_index().assign(start_year=start,end_year=end).rename(columns={start:"real_ppp_start",end:"real_ppp_end"}).to_dict("records"))
    save(pd.DataFrame(timing),"timing_growth_diagnostics")
    save(pd.DataFrame(timing_samples),"timing_growth_samples")
    # Same-year pre-pandemic comparison, fixed universe of the main 83 economies.
    archive=pd.read_csv(D/"input_rd_income_exports_annual.csv",low_memory=False)
    rdcols=["rd_percent_gdp_ons","rd_percent_gdp_oecd","rd_percent_gdp_wdi"]
    temporal=[]
    for year in [2019,2021,2022,2023]:
        q=archive.loc[archive.year.eq(year)&archive.iso3.isin(d.iso3)].copy()
        q["rd"]=q[rdcols].bfill(axis=1).iloc[:,0]
        q["log_ppp"]=np.log(q.gdp_per_capita_current_ppp)
        q=q.dropna(subset=["rd","log_ppp"])
        if year == 2022:
            q = d.copy()  # authoritative harmonised core, including its provider rules
        temporal.append(dict(year=year,n=len(q),r2=fit(q,["rd"]).rsquared,spearman=stats.spearmanr(q.rd,q.log_ppp).statistic))
    save(pd.DataFrame(temporal),"temporal_cross_sections")
    std=pd.read_csv(D/"input_manufacturing_standardised_2022.csv").merge(d[["iso3","economy","ppp"]],on="iso3",how="left")
    std["rank_observed"]=std.observed.rank(ascending=False,method="min")
    std["rank_standardised"]=std.common_structure.rank(ascending=False,method="min")
    std["change_pp"]=std.common_structure-std.observed
    save(std,"manufacturing_standardisation")

    # Compact summary used by manuscript rendering and the independent validator.
    summary=dict(n=len(d),r2=baseline.rsquared,pearson=stats.pearsonr(d.rd,d.log_ppp).statistic,spearman=stats.spearmanr(d.rd,d.log_ppp).statistic,
                 near_pairs=len(pairs),median_pair_income_ratio=pairs.income_ratio.median(),pairs_ratio_ge2=int(pairs.income_ratio.ge(2).sum()),
                 boundary_countries=d.loc[d.boundary_flag,"iso3"].tolist(),primary_correlation_tests=len(corr),
                 selected_case_codes=sorted(set(selected.low)|set(selected.high)),manufacturing_n=len(std))
    (D/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    figures(d,corr,pairs,selected,pd.DataFrame(modelrows),std)
    with pd.ExcelWriter(ROOT/"Global_Analysis.xlsx",engine="openpyxl") as writer:
        for filename in ["global_countries_2022","indicator_coverage","intensity_band_dispersion","all_near_intensity_pairs","selected_country_pairs","pairs_large_economy_sensitivity","selected_country_profiles","income_correlations","common_sample_correlations","income_models","income_model_coefficients","income_model_samples","baseline_sensitivity","timing_growth_diagnostics","temporal_cross_sections","manufacturing_standardisation","supplement_and_innovation_2022_long"]:
            pd.read_csv(D/f"{filename}.csv").to_excel(writer,sheet_name=filename[:31],index=False)
        for ws in writer.book.worksheets:
            ws.freeze_panes="B2"
            ws.auto_filter.ref=ws.dimensions
            for cells in ws.columns:
                width=min(52,max(12,max(len(str(c.value or "")) for c in list(cells)[:100])+1))
                ws.column_dimensions[cells[0].column_letter].width=width
    print(json.dumps(summary,indent=2))
    print("\nDATA-SELECTED PAIRS\n",selected.to_string(index=False))
    print("\nCORRELATIONS\n",corr[["metric","n","partial_rd","partial_logrd","partial_rank","partial_no_boundary","bh_q"]].to_string(index=False))
    print("\nMODELS\n",pd.DataFrame(modelrows).to_string(index=False))
    print("\nTIMING\n",pd.DataFrame(timing).to_string(index=False))


def figures(d,corr,pairs,selected,models,std):
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,"axes.spines.top":False,"axes.spines.right":False,"savefig.facecolor":"white"})
    teal,orange="#146B88","#C45D2A"
    fig,ax=plt.subplots(figsize=(10.8,6.0))
    missing=d.internet.isna()
    ax.scatter(d.loc[missing,"rd"],d.loc[missing,"ppp"],color="#888888",s=42,edgecolors="white",linewidths=.4,label=f"Internet data missing (n={missing.sum()})")
    points=ax.scatter(d.loc[~missing,"rd"],d.loc[~missing,"ppp"],c=d.loc[~missing,"internet"],cmap="viridis",vmin=0,vmax=100,s=42,alpha=.85,edgecolors="white",linewidths=.4)
    fig.colorbar(points,ax=ax,pad=.02,label="Internet users (% population, 2022)")
    xs=np.linspace(0,d.rd.max(),200)
    m=fit(d,["rd"])
    ax.plot(xs,np.exp(m.params.const+m.params.rd*xs),color=teal,lw=1.8,label="Linear log-income fit")
    codes=set(selected.low)|set(selected.high)|{"USA","JPN"}
    offsets={"LUX":(5,6),"SGP":(5,-12),"IRL":(5,2),"NOR":(5,-10),"SAU":(5,3),"KEN":(5,-13),"JPN":(5,-14),"USA":(5,3),"CHN":(5,-12),"ISL":(5,5)}
    for r in d.loc[d.iso3.isin(codes)].itertuples():
        ax.annotate(r.iso3,(r.rd,r.ppp),xytext=offsets.get(r.iso3,(5,4)),textcoords="offset points",fontsize=8)
    ax.set(yscale="log",xlabel="GERD / GDP, 2022 (%)",ylabel="GDP per capita, PPP current international $, 2022",title="Similar research intensity, different income levels: 83 economies")
    ax.set_yticks([5000,10000,20000,40000,80000,160000]);ax.yaxis.set_major_formatter(FuncFormatter(lambda v,p:f"{v:,.0f}"));ax.grid(axis="y",alpha=.2)
    ax.legend(loc="lower right",frameon=False)
    fig.tight_layout();fig.savefig(F/"01_global_scatter.png",dpi=200);plt.close(fig)

    show=["internet","gov_effect","hci_2020","log_publications_pm","log_researchers","log_patents_pm","gva_KIS","gva_MHT","gva_mfg","export_MHT","perform_BES","fund_BES","flow_BES_to_HES_recipient"]
    c=corr.set_index("metric").loc[show].iloc[::-1]
    fig,ax=plt.subplots(figsize=(11,6.7));y=np.arange(len(c))
    ax.errorbar(c.partial_rd,y,xerr=[c.partial_rd-c.ci_low,c.ci_high-c.partial_rd],fmt="o",color=teal,ecolor="#9BBCC9",capsize=3,label="Linear R&D control; 95% descriptive CI")
    ax.scatter(c.partial_logrd,y,marker="x",color=orange,label="log(1 + R&D) control")
    ax.axvline(0,color="#777777",lw=.8)
    ax.set_yticks(y,[f"{r.label}  [n={r.n}]" for r in c.itertuples()]);ax.set(xlim=(-.85,1),xlabel="Partial correlation with log PPP GDP per capita",title="Capabilities and outputs: associations beyond R&D intensity")
    ax.legend(loc="lower right",fontsize=8,frameon=False);fig.tight_layout();fig.savefig(F/"02_conditional_correlations.png",dpi=200);plt.close(fig)

    s=selected.loc[selected.selection.eq("largest gap per band")].sort_values("rd_low_income")
    fig,axes=plt.subplots(1,2,figsize=(11,5.5),gridspec_kw={"width_ratios":[1.8,1]})
    for j,r in enumerate(s.itertuples()):
        axes[0].plot([r.ppp_low,r.ppp_high],[j,j],color="#ADC6CD",lw=4)
        axes[0].scatter([r.ppp_low,r.ppp_high],[j,j],c=[teal,orange],s=65)
        axes[0].text(r.ppp_high+2500,j,f"{r.income_ratio:.2f}×",va="center",fontsize=9)
    axes[0].set_yticks(range(len(s)),[f"{r.low_name} → {r.high_name}\nR&D {r.rd_low_income:.2f}% / {r.rd_high_income:.2f}%" for r in s.itertuples()]);axes[0].set(xlim=(0,180000),xlabel="PPP GDP per capita ($)",title="Largest near-intensity gap in each band")
    axes[0].xaxis.set_major_formatter(FuncFormatter(lambda v,p:f"{v/1000:,.0f}k"))
    axes[1].hist(pairs.income_ratio,bins=np.arange(1,14,.5),color=teal,alpha=.85)
    axes[1].set(xlabel="Higher / lower income",ylabel="Pair count (overlapping economies)",title=f"All {len(pairs)} eligible pairs")
    fig.tight_layout();fig.savefig(F/"03_selected_pairs.png",dpi=200);plt.close(fig)

    fig,ax=plt.subplots(figsize=(11,5.6));q=models.loc[models.family.ne("joint")].copy();y=np.arange(len(q))
    ax.barh(y,q.loo_rmse,color=[teal if x.endswith("_0") else "#73A9B7" for x in q.model]);ax.invert_yaxis()
    names=["R&D only", "+ Internet", "+ Human capital + governance", "+ All three capabilities", "R&D only", "+ Researchers", "+ Publications", "+ Resident patents", "+ All three research indicators", "R&D only", "+ GVA / export structure", "+ Business performer / funding", "+ Structure and funding"]
    ax.set_yticks(y,[f"{r.family}, n={r.n}: {name}" for r,name in zip(q.itertuples(),names)],fontsize=8)
    ax.set(xlabel="Leave-one-economy-out RMSE (log income; lower is better)",title="Compare models within each fixed sample")
    fig.tight_layout();fig.savefig(F/"04_model_validation.png",dpi=200);plt.close(fig)

    q=std.sort_values("observed",ascending=False);fig,ax=plt.subplots(figsize=(11,5.8));y=np.arange(len(q))
    ax.bar(y-.18,q.observed,width=.36,label="Observed weights",color=teal);ax.bar(y+.18,q.common_structure,width=.36,label="Common manufacturing weights",color=orange)
    ax.set_xticks(y,q.iso3);ax.set(ylabel="Manufacturing BERD / manufacturing GVA (%)",title="Industry composition changes R&D benchmarks: 19 economies")
    ax.legend(frameon=False);fig.tight_layout();fig.savefig(F/"05_industry_standardisation.png",dpi=200);plt.close(fig)


if __name__=="__main__":
    main()
