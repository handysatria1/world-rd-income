# /// script
# requires-python = ">=3.13"
# dependencies = ["pymupdf==1.26.7"]
# ///
"""Integrity check and isolated offline rebuild of the exact delivered payload."""
from pathlib import Path
from zipfile import ZipFile
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import pymupdf

ROOT=Path(__file__).resolve().parent
zip_path=ROOT/"Global_RD_Income_Study.zip"
with ZipFile(zip_path) as z:
    assert z.testzip() is None
    manifest=json.loads(z.read("Delivery_Manifest.json"))
    assert set(z.namelist())=={r["path"] for r in manifest["files"]}|{"Delivery_Manifest.json"}
    for r in manifest["files"]:
        content=z.read(r["path"])
        assert len(content)==r["bytes"] and hashlib.sha256(content).hexdigest()==r["sha256"],r["path"]
    assert not any("Comin_Mestieri_2013_WP" in p or "Syverson_2009_WP" in p for p in z.namelist())
    print(f"ZIP integrity: {len(manifest['files'])} payload files verified.",flush=True)
    if "--integrity-only" in sys.argv:
        raise SystemExit(0)
    base=Path(os.environ.get("LOCALAPPDATA",tempfile.gettempdir()))/"Temp/opencode"
    base.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="global-rd-offline-",dir=base) as temp:
        stage=Path(temp)
        z.extractall(stage)
        expected={r["path"]:r["sha256"] for r in manifest["files"]
                  if ((r["path"].startswith("Data/") and not Path(r["path"]).name.startswith("input_") and "/raw_wb/" not in r["path"])
                      or r["path"].startswith("Policy_Brief/Data/") or r["path"] in ["Methods/Residuals.csv","Policy_Brief/PDF_Review/Reading_Ledger.csv"])
                  and r["path"].endswith(".csv")}
        pdf_paths=["Paper.pdf","Policy_Brief/Policy_Brief.pdf","Methods/Methods_Guide.pdf"]
        original_pdf_text={path:[p.get_text() for p in pymupdf.open(stage/path)] for path in pdf_paths}
        steps=[]
        for script in ["analyse_global.py","render_paper.py","build_deliverables.py","validate_global.py",
                       "Methods/worked_example.py","Policy_Brief/analyse_brief.py","Policy_Brief/build_reading_ledger.py",
                       "Policy_Brief/render_documents.py","Policy_Brief/build_documents.py","Policy_Brief/validate_brief.py"]:
            result=subprocess.run(["uv","run","--offline","--python","3.13",script],cwd=stage,capture_output=True,text=True,encoding="utf-8",errors="replace")
            assert result.returncode==0, f"{script}\n{result.stdout}\n{result.stderr}"
            steps.append(dict(script=script,sha256=hashlib.sha256((stage/script).read_bytes()).hexdigest(),exit_code=result.returncode))
            print(f"Offline rebuild passed: {script}",flush=True)
        for path,digest in expected.items():
            assert hashlib.sha256((stage/path).read_bytes()).hexdigest()==digest,path
        rebuilt_pdf_text={path:[p.get_text() for p in pymupdf.open(stage/path)] for path in pdf_paths}
        assert original_pdf_text==rebuilt_pdf_text
        report=dict(checked_utc=datetime.now(timezone.utc).isoformat(),
                    input_archive_sha256=hashlib.sha256(zip_path.read_bytes()).hexdigest(),
                    note="Archive hash identifies the package tested before this report is added. Final package integrity is checked separately; script and data payloads are unchanged.",
                    manifest_payload_files=len(manifest["files"]),steps=steps,
                     identical_csv_files=len(expected),pdf_pages={path:len(pages) for path,pages in rebuilt_pdf_text.items()},identical_pdf_text=True,
                    isolated_from_upstream=True,uv_offline=True,
                     validation=json.loads((stage/"Data/global_validation.json").read_text()),
                     policy_brief_validation=json.loads((stage/"Policy_Brief/Data/validation.json").read_text()))
        (ROOT/"Data/portable_reproduction.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
        print(json.dumps(report,indent=2))
